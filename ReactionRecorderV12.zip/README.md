# Reaction Recorder V12

Polished reaction recorder UI with local source video playback, draggable/free-range resizable PIP, seeking controls, front-camera preview, recording settings, HEVC/H.264 selection with encoder fallback, selectable microphone input, and mixed microphone + captured source playback audio.

## V12 focus
- Clean dark minimal interface inspired by the provided UI concept.
- Source-video empty state and status feedback.
- PIP move and independent corner-resize handles.
- Media3 playback controls plus dedicated -10/+10 controls.
- Live source position display.
- Recording status badge and saving state.
- Landscape/portrait activity rotation is no longer hard-locked to portrait.
- Existing recording engine retained from V8; runtime behavior still requires APK/device testing.

## Important
This source has been statically reviewed and packaged, but it has not been compiled and run on a physical Android device in this environment. Any runtime issue discovered on the phone should be treated as a real test result and fixed from the exact error.


## V12 bug-hardening pass
- Hardened foreground-service stop/export against duplicate stop calls and service-destroy races.
- GitHub Actions builds the debug APK as ReactionRecorderV12-debug-apk.
- Static validation completed; this environment still does not have the Android SDK/Gradle cache needed to compile or run the APK.

- Fixed the PIP empty-state overlay so it no longer covers loaded video.
- Stopping a YouTube source now pauses/stops the embedded player before switching to a local source or destroying the Activity, preventing hidden YouTube audio from continuing.
- Verified UI IDs are wired to MainActivity and all XML parses successfully.
