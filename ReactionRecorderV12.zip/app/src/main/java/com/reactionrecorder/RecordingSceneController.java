package com.reactionrecorder;

import android.graphics.Bitmap;
import android.graphics.Rect;
import android.os.Handler;
import android.os.HandlerThread;
import android.view.PixelCopy;
import android.view.TextureView;
import android.view.View;
import android.view.Window;

import androidx.media3.ui.PlayerView;

import java.lang.ref.WeakReference;

/**
 * Produces recording-only frames without capturing the Android UI.
 * Camera/local video are sampled from their own surfaces. YouTube is sampled
 * only from the exact WebView rectangle using PixelCopy.
 */
public final class RecordingSceneController {
    public static final class Frame {
        public final Bitmap camera,pip;
        public final float pipX,pipY,pipW,pipH;
        public final long capturedNs;
        Frame(Bitmap c,Bitmap p,float x,float y,float w,float h,long ns){
            camera=c;pip=p;pipX=x;pipY=y;pipW=w;pipH=h;capturedNs=ns;
        }
    }
    private static WeakReference<View> cameraRef,pipRef,rootRef;
    private static HandlerThread thread;
    private static Handler worker;
    private static volatile Frame latest;
    private static volatile boolean active;
    private static int targetW=1280,targetH=720;
    private static long lastCaptureNs;

    private RecordingSceneController(){}

    public static void prepareSource(PlayerView player){}
    public static void restoreSource(PlayerView player){}
    public static void hideHandle(View handle){if(handle!=null)handle.setVisibility(View.GONE);}
    public static void showHandle(View handle){if(handle!=null)handle.setVisibility(View.VISIBLE);}

    public static void startFramePump(View root,View camera,View pip,Handler ignoredUi,int width,int height){
        stopFramePump();
        rootRef=new WeakReference<>(root);cameraRef=new WeakReference<>(camera);pipRef=new WeakReference<>(pip);
        targetW=Math.max(2,width);targetH=Math.max(2,height);
        thread=new HandlerThread("reaction-scene-capture");thread.start();worker=new Handler(thread.getLooper());
        active=true;lastCaptureNs=0;
        final Runnable[] holder=new Runnable[1];
        holder[0]=()->{
            if(!active)return;
            capture(rootRef.get(),cameraRef.get(),pipRef.get());
            if(worker!=null)worker.postDelayed(holder[0],33);
        };
        worker.post(holder[0]);
    }

    public static void stopFramePump(){
        active=false;
        if(worker!=null)worker.removeCallbacksAndMessages(null);
        if(thread!=null)try{thread.quitSafely();}catch(Throwable ignored){}
        worker=null;thread=null;rootRef=null;cameraRef=null;pipRef=null;
        Frame f; synchronized(RecordingSceneController.class){f=latest;latest=null;}
        if(f!=null){recycle(f.camera);recycle(f.pip);}
    }

    public static synchronized Frame consumeLatestFrame(){Frame f=latest;latest=null;return f;}
    public static synchronized Frame latestFrame(){return latest;}

    private static void capture(View root,View camera,View pip){
        if(root==null||camera==null||pip==null||root.getWidth()<=0||root.getHeight()<=0)return;
        long now=System.nanoTime();
        if(now-lastCaptureNs<28_000_000L)return;
        lastCaptureNs=now;
        Bitmap cb=captureCamera(camera);
        if(cb==null)return;
        int pw=Math.max(2,pip.getWidth()),ph=Math.max(2,pip.getHeight());
        Bitmap pb=capturePip(root,pip,pw,ph);
        if(pb==null){recycle(cb);return;}
        float x=(pip.getLeft()+pip.getTranslationX())/(float)root.getWidth();
        float y=(pip.getTop()+pip.getTranslationY())/(float)root.getHeight();
        Frame fresh=new Frame(cb,pb,x,y,pw/(float)root.getWidth(),ph/(float)root.getHeight(),now);
        Frame old; synchronized(RecordingSceneController.class){old=latest;latest=fresh;}
        if(old!=null){recycle(old.camera);recycle(old.pip);}
    }

    private static Bitmap captureCamera(View camera){
        try{
            if(camera instanceof TextureView)return ((TextureView)camera).getBitmap(targetW,targetH);
            if(camera instanceof androidx.camera.view.PreviewView){
                Bitmap b=((androidx.camera.view.PreviewView)camera).getBitmap();
                if(b!=null&&(b.getWidth()!=targetW||b.getHeight()!=targetH)){
                    Bitmap x=Bitmap.createScaledBitmap(b,targetW,targetH,true);if(x!=b)recycle(b);b=x;
                }
                return b;
            }
        }catch(Throwable ignored){}
        return null;
    }

    private static Bitmap capturePip(View root,View pip,int w,int h){
        try{
            PlayerView pv=pip.findViewById(R.id.source);
            View yt=pip.findViewById(R.id.youtube_view);
            if(yt!=null&&yt.getVisibility()==View.VISIBLE)return pixelCopyView(root,yt,w,h);
            if(pv!=null){
                View surface=pv.getVideoSurfaceView();
                if(surface instanceof TextureView&&surface.getVisibility()==View.VISIBLE)
                    return ((TextureView)surface).getBitmap(w,h);
            }
        }catch(Throwable ignored){}
        return null;
    }

    private static Bitmap pixelCopyView(View root,View view,int w,int h){
        if(!(root.getContext() instanceof android.app.Activity)||worker==null)return null;
        Window win=((android.app.Activity)root.getContext()).getWindow();
        int[] loc=new int[2];view.getLocationInWindow(loc);
        Rect src=new Rect(loc[0],loc[1],loc[0]+Math.max(1,view.getWidth()),loc[1]+Math.max(1,view.getHeight()));
        Bitmap out=Bitmap.createBitmap(Math.max(1,w),Math.max(1,h),Bitmap.Config.ARGB_8888);
        final Object lock=new Object();final boolean[] done={false};final int[] result={PixelCopy.ERROR_UNKNOWN};
        try{
            PixelCopy.request(win,src,out,code->{synchronized(lock){result[0]=code;done[0]=true;lock.notifyAll();}},worker);
            synchronized(lock){
                long end=System.currentTimeMillis()+120;
                while(!done[0]&&System.currentTimeMillis()<end)lock.wait(Math.max(1,end-System.currentTimeMillis()));
            }
            if(result[0]==PixelCopy.SUCCESS)return out;
        }catch(Throwable ignored){}
        recycle(out);return null;
    }

    private static void recycle(Bitmap b){if(b!=null&&!b.isRecycled())b.recycle();}
}
