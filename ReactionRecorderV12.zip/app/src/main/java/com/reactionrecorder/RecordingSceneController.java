package com.reactionrecorder;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Handler;
import android.view.TextureView;
import android.view.View;
import android.webkit.WebView;

import androidx.media3.ui.PlayerView;

import java.lang.ref.WeakReference;

/**
 * Owns the recording scene independently from the Android display.
 * The recorder consumes snapshots of ONLY the camera and PIP scene; app chrome
 * is never used as a video source.
 */
public final class RecordingSceneController {
    public static final class Frame {
        public final Bitmap camera;
        public final Bitmap pip;
        public final float pipX, pipY, pipW, pipH;
        public final long capturedNs;
        Frame(Bitmap c, Bitmap p, float x, float y, float w, float h, long ns) {
            camera=c; pip=p; pipX=x; pipY=y; pipW=w; pipH=h; capturedNs=ns;
        }
    }

    private static final Object LOCK = new Object();
    private static WeakReference<View> cameraRef;
    private static WeakReference<View> pipRef;
    private static WeakReference<View> rootRef;
    private static Handler handler;
    private static Runnable pump;
    private static volatile Frame latest;
    private static boolean active;

    private RecordingSceneController() {}

    public static void prepareSource(PlayerView player) {
        if (player != null) player.setUseController(false);
    }

    public static void restoreSource(PlayerView player) {
        if (player != null) player.setUseController(true);
    }

    public static void hideHandle(View handle) { if (handle != null) handle.setVisibility(View.GONE); }
    public static void showHandle(View handle) { if (handle != null) handle.setVisibility(View.VISIBLE); }

    /** Starts a UI-thread snapshot pump. Only camera + PIP are copied. */
    public static void startFramePump(View root, View camera, View pip, Handler ui) {
        stopFramePump();
        rootRef=new WeakReference<>(root); cameraRef=new WeakReference<>(camera); pipRef=new WeakReference<>(pip);
        handler=ui; active=true;
        pump=new Runnable(){ @Override public void run(){
            if(!active) return;
            capture(rootRef.get(), cameraRef.get(), pipRef.get());
            if(handler!=null) handler.postDelayed(this, 33);
        }};
        handler.post(pump);
    }

    public static void stopFramePump() {
        active=false;
        if(handler!=null && pump!=null) handler.removeCallbacks(pump);
        handler=null; pump=null; rootRef=null; cameraRef=null; pipRef=null;
        Frame f=latest; latest=null;
        if(f!=null){ recycle(f.camera); recycle(f.pip); }
    }

    /** Atomically hands the newest scene frame to the encoder thread. */
    public static synchronized Frame consumeLatestFrame(){
        Frame f=latest;
        latest=null;
        return f;
    }

    public static synchronized Frame latestFrame(){ return latest; }

    private static void capture(View root, View camera, View pip){
        if(root==null || camera==null || pip==null || root.getWidth()<=0 || root.getHeight()<=0) return;
        try {
            Bitmap cb=camera instanceof android.view.TextureView ? ((TextureView)camera).getBitmap() :
                    (camera instanceof androidx.camera.view.PreviewView ? ((androidx.camera.view.PreviewView)camera).getBitmap() : null);
            if(cb==null || cb.getWidth()<=0 || cb.getHeight()<=0) return;
            Bitmap cameraCopy=cb.copy(Bitmap.Config.ARGB_8888,false);
            if(cb!=cameraCopy) recycle(cb);

            int pw=Math.max(2,pip.getWidth()), ph=Math.max(2,pip.getHeight());
            Bitmap pb=Bitmap.createBitmap(pw,ph,Bitmap.Config.ARGB_8888);
            Canvas pc=new Canvas(pb);
            pc.drawColor(android.graphics.Color.BLACK);
            // IMPORTANT: only the source surface is copied. The PIP drag/resize
            // handles, Media3 controls, borders and other app chrome are never
            // drawn into the recording bitmap.
            if(pip instanceof com.reactionrecorder.PipFrameLayout){
                PlayerView pv=pip.findViewById(com.reactionrecorder.R.id.source);
                View yt=pip.findViewById(com.reactionrecorder.R.id.youtube_view);
                if(yt!=null && yt.getVisibility()==View.VISIBLE){
                    yt.draw(pc);
                } else if(pv!=null){
                    View vs=pv.getVideoSurfaceView();
                    if(vs instanceof TextureView && vs.getVisibility()==View.VISIBLE){
                        Bitmap vb=((TextureView)vs).getBitmap();
                        if(vb!=null){
                            int l=vs.getLeft(), t=vs.getTop();
                            pc.drawBitmap(vb,null,new Rect(l,t,l+vs.getWidth(),t+vs.getHeight()),null);
                            recycle(vb);
                        }
                    }
                }
            }
            float x=pip.getLeft()+pip.getTranslationX(), y=pip.getTop()+pip.getTranslationY();
            Frame old;
            synchronized (RecordingSceneController.class) {
                old=latest;
                latest=new Frame(cameraCopy,pb,x/root.getWidth(),y/root.getHeight(),pw/(float)root.getWidth(),ph/(float)root.getHeight(),System.nanoTime());
            }
            // If the encoder has not consumed the previous frame yet, recycle it
            // now so long recordings do not accumulate bitmaps.
            if(old!=null){ recycle(old.camera); recycle(old.pip); }
        } catch(Throwable ignored) {}
    }

    private static void recycle(Bitmap b){ if(b!=null && !b.isRecycled()) b.recycle(); }
}
