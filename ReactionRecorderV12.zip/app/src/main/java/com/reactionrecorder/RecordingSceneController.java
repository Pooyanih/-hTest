package com.reactionrecorder;

import android.graphics.Bitmap;
import android.graphics.Rect;
import android.os.Handler;
import android.os.HandlerThread;
import android.view.PixelCopy;
import android.view.TextureView;
import android.view.View;
import android.view.Window;

import androidx.media3.ui.PlayerView;

import java.lang.ref.WeakReference;

/** Recording-only source pipeline. It never captures the application chrome. */
public final class RecordingSceneController {
    public static final class Frame {
        public final Bitmap camera,pip;
        public final float pipX,pipY,pipW,pipH;
        public final long capturedNs;
        Frame(Bitmap c,Bitmap p,float x,float y,float w,float h,long ns){camera=c;pip=p;pipX=x;pipY=y;pipW=w;pipH=h;capturedNs=ns;}
    }
    private static WeakReference<View> pipRef,rootRef;
    private static HandlerThread thread;
    private static Handler worker,main;
    private static volatile Frame latest;
    private static volatile Bitmap latestCamera,latestSource;
    private static volatile boolean active;
    private static int targetW=1280,targetH=720;
    private static long lastCaptureNs;

    private RecordingSceneController(){}
    public static void prepareSource(PlayerView player){}
    public static void restoreSource(PlayerView player){}
    public static void hideHandle(View handle){if(handle!=null)handle.setVisibility(View.GONE);}
    public static void showHandle(View handle){if(handle!=null)handle.setVisibility(View.VISIBLE);}

    /** Called by CameraX ImageAnalysis. The controller owns a copy and closes the ImageProxy immediately in the caller. */
    public static synchronized void setCameraFrame(Bitmap b){
        if(!active){if(b!=null&&!b.isRecycled())b.recycle();return;}
        Bitmap old=latestCamera; latestCamera=b; if(old!=null&&!old.isRecycled())old.recycle();
    }

    public static void startFramePump(View root,View camera,View pip,Handler ignoredUi,int width,int height){
        stopFramePump();
        rootRef=new WeakReference<>(root);pipRef=new WeakReference<>(pip);
        targetW=Math.max(2,width);targetH=Math.max(2,height);
        main=ignoredUi; thread=new HandlerThread("reaction-scene-capture");thread.start();worker=new Handler(thread.getLooper());
        active=true;lastCaptureNs=0;
        final Runnable[] holder=new Runnable[1];
        holder[0]=()->{
            if(!active)return;
            captureSourceAndCompose(rootRef.get(),pipRef.get());
            if(worker!=null)worker.postDelayed(holder[0],33);
        };
        worker.post(holder[0]);
    }

    public static void stopFramePump(){
        active=false;
        if(worker!=null)worker.removeCallbacksAndMessages(null);
        if(thread!=null)try{thread.quitSafely();}catch(Throwable ignored){}
        worker=null;thread=null;rootRef=null;pipRef=null;
        Bitmap c=latestCamera;latestCamera=null;if(c!=null&&!c.isRecycled())c.recycle();
        Bitmap sp=latestSource;latestSource=null;if(sp!=null&&!sp.isRecycled())sp.recycle();
        Frame f; synchronized(RecordingSceneController.class){f=latest;latest=null;}
        if(f!=null){recycle(f.camera);recycle(f.pip);}
    }

    public static synchronized Frame consumeLatestFrame(){Frame f=latest;latest=null;return f;}
    public static synchronized Frame latestFrame(){return latest;}

    private static void captureSourceAndCompose(View root,View pip){
        if(root==null||pip==null||root.getWidth()<=0||root.getHeight()<=0)return;
        long now=System.nanoTime();if(now-lastCaptureNs<30_000_000L)return;lastCaptureNs=now;
        Bitmap cameraCopy;
        synchronized(RecordingSceneController.class){
            Bitmap cb=latestCamera;
            if(cb==null||cb.isRecycled())return;
            try{cameraCopy=Bitmap.createScaledBitmap(cb,targetW,targetH,true);}catch(Throwable e){return;}
        }
        int pw=Math.max(2,pip.getWidth()),ph=Math.max(2,pip.getHeight());
        Bitmap pb=capturePip(root,pip,pw,ph);
        if(pb==null){
            Bitmap cached=latestSource;
            if(cached!=null&&!cached.isRecycled()){
                try{pb=Bitmap.createScaledBitmap(cached,pw,ph,true);}catch(Throwable ignored){}
            }
        } else {
            Bitmap oldSrc=latestSource; latestSource=pb;
            if(oldSrc!=null&&!oldSrc.isRecycled())recycle(oldSrc);
            try{pb=Bitmap.createScaledBitmap(latestSource,pw,ph,true);}catch(Throwable ignored){}
        }
        if(pb==null){
            // A source surface can take a moment to produce its first frame. Do not
            // abort the recording session; use a neutral source frame temporarily.
            pb=Bitmap.createBitmap(pw,ph,Bitmap.Config.ARGB_8888);
            pb.eraseColor(android.graphics.Color.BLACK);
        }
        float x=(pip.getLeft()+pip.getTranslationX())/(float)root.getWidth();
        float y=(pip.getTop()+pip.getTranslationY())/(float)root.getHeight();
        Frame fresh=new Frame(cameraCopy,pb,x,y,pw/(float)root.getWidth(),ph/(float)root.getHeight(),now);
        Frame old; synchronized(RecordingSceneController.class){old=latest;latest=fresh;}
        if(old!=null){recycle(old.camera);recycle(old.pip);}
    }

    private static Bitmap capturePip(View root,View pip,int w,int h){
        try{
            View yt=pip.findViewById(R.id.youtube_view);
            if(yt!=null&&yt.getVisibility()==View.VISIBLE)return pixelCopyView(root,yt,w,h);
            PlayerView pv=pip.findViewById(R.id.source);
            if(pv!=null){View surface=pv.getVideoSurfaceView();if(surface instanceof TextureView&&surface.getVisibility()==View.VISIBLE)return ((TextureView)surface).getBitmap(w,h);}
        }catch(Throwable ignored){}
        return null;
    }

    private static Bitmap pixelCopyView(View root,View view,int w,int h){
        if(!(root.getContext() instanceof android.app.Activity)||worker==null)return null;
        Window win=((android.app.Activity)root.getContext()).getWindow();int[] loc=new int[2];view.getLocationInWindow(loc);
        Rect src=new Rect(loc[0],loc[1],loc[0]+Math.max(1,view.getWidth()),loc[1]+Math.max(1,view.getHeight()));
        Bitmap out=Bitmap.createBitmap(Math.max(1,w),Math.max(1,h),Bitmap.Config.ARGB_8888);
        final Object lock=new Object();final boolean[] done={false};final int[] result={PixelCopy.ERROR_UNKNOWN};
        try{PixelCopy.request(win,src,out,code->{synchronized(lock){result[0]=code;done[0]=true;lock.notifyAll();}},worker);synchronized(lock){long end=System.currentTimeMillis()+100;while(!done[0]&&System.currentTimeMillis()<end)lock.wait(Math.max(1,end-System.currentTimeMillis()));}if(result[0]==PixelCopy.SUCCESS)return out;}catch(Throwable ignored){}
        recycle(out);return null;
    }
    private static void recycle(Bitmap b){if(b!=null&&!b.isRecycled())b.recycle();}
}
