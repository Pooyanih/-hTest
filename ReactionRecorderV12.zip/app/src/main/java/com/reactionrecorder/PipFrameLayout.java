package com.reactionrecorder;

import android.content.Context;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import android.widget.FrameLayout;

/** PIP interaction container. */
public class PipFrameLayout extends FrameLayout {
    public interface Listener{
        void onPipDragStart(float rawX,float rawY);
        void onPipDragMove(float rawX,float rawY);
        void onPipDragEnd();
        void onPipDoubleTap();
    }
    private final int touchSlop;
    private float downX,downY;
    private boolean dragging,interactiveContent;
    private Listener listener;
    private final GestureDetector detector;

    public PipFrameLayout(Context c,AttributeSet a){
        super(c,a);touchSlop=ViewConfiguration.get(c).getScaledTouchSlop();
        detector=new GestureDetector(c,new GestureDetector.SimpleOnGestureListener(){
            @Override public boolean onDown(MotionEvent e){return true;}
            @Override public boolean onDoubleTap(MotionEvent e){
                if(!interactiveContent&&listener!=null){listener.onPipDoubleTap();return true;}return false;
            }
        });setClickable(true);
    }
    public void setListener(Listener l){listener=l;}
    public void setInteractiveContent(boolean v){interactiveContent=v;}

    @Override public boolean dispatchTouchEvent(MotionEvent e){
        detector.onTouchEvent(e);
        int a=e.getActionMasked();
        if(a==MotionEvent.ACTION_DOWN){downX=e.getRawX();downY=e.getRawY();dragging=false;}
        else if(a==MotionEvent.ACTION_MOVE&&!dragging){
            boolean canDrag=!interactiveContent||e.getPointerCount()>=2;
            if(canDrag&&(Math.abs(e.getRawX()-downX)>touchSlop||Math.abs(e.getRawY()-downY)>touchSlop)){
                dragging=true;if(listener!=null)listener.onPipDragStart(downX,downY);
            }
        }
        if(dragging){
            if(a==MotionEvent.ACTION_MOVE){if(listener!=null)listener.onPipDragMove(e.getRawX(),e.getRawY());return true;}
            if(a==MotionEvent.ACTION_UP||a==MotionEvent.ACTION_CANCEL){if(listener!=null)listener.onPipDragEnd();dragging=false;return true;}
            return true;
        }
        return super.dispatchTouchEvent(e);
    }
}
