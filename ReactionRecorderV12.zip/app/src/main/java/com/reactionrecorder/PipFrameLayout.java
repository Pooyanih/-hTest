package com.reactionrecorder;

import android.content.Context;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import android.widget.FrameLayout;

public class PipFrameLayout extends FrameLayout {
    public interface Listener {
        void onPipDragStart(float rawX, float rawY);
        void onPipDragMove(float rawX, float rawY);
        void onPipDragEnd();
        void onPipDoubleTap();
    }

    private final int touchSlop;
    private float downX, downY;
    private boolean dragging;
    private Listener listener;
    private final GestureDetector gestureDetector;

    public PipFrameLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
        gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(MotionEvent e) { return true; }
            @Override public boolean onDoubleTap(MotionEvent e) {
                if (listener != null) listener.onPipDoubleTap();
                return true;
            }
        });
        setClickable(true);
    }

    public void setListener(Listener listener) { this.listener = listener; }

    @Override public boolean onInterceptTouchEvent(MotionEvent e) {
        gestureDetector.onTouchEvent(e);
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = e.getRawX();
                downY = e.getRawY();
                dragging = false;
                return false;
            case MotionEvent.ACTION_MOVE:
                if (!dragging && (Math.abs(e.getRawX() - downX) > touchSlop || Math.abs(e.getRawY() - downY) > touchSlop)) {
                    dragging = true;
                    if (listener != null) listener.onPipDragStart(downX, downY);
                    return true;
                }
                return dragging;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (dragging) {
                    if (listener != null) listener.onPipDragEnd();
                    dragging = false;
                    return true;
                }
                return false;
            default:
                return dragging;
        }
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (dragging) {
            if (e.getActionMasked() == MotionEvent.ACTION_MOVE) {
                if (listener != null) listener.onPipDragMove(e.getRawX(), e.getRawY());
                return true;
            }
            if (e.getActionMasked() == MotionEvent.ACTION_UP || e.getActionMasked() == MotionEvent.ACTION_CANCEL) {
                if (listener != null) listener.onPipDragEnd();
                dragging = false;
                return true;
            }
        }
        return true;
    }
}
