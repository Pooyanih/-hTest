package com.reactionrecorder;

import android.content.Context;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import android.widget.FrameLayout;

public class PipFrameLayout extends FrameLayout {
    public interface Listener {
        void onPipDragStart(float rawX, float rawY);
        void onPipDragMove(float rawX, float rawY);
        void onPipDragEnd();
        void onPipDoubleTap();
    }

    private final int touchSlop;
    private float downX, downY;
    private boolean dragging;
    private boolean childGesture;
    private float childDownX, childDownY;
    private Listener listener;
    private final GestureDetector gestureDetector;
    private int[] resizeHandleIds = new int[0];
    private boolean dragEnabled = true;
    private boolean doubleTapEnabled = true;
    private int childTouchBottomPx = 0;

    public PipFrameLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
        gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(MotionEvent e) { return true; }
            @Override public boolean onDoubleTap(MotionEvent e) {
                if (doubleTapEnabled && listener != null) listener.onPipDoubleTap();
                return true;
            }
        });
        setClickable(true);
    }

    public void setListener(Listener listener) { this.listener = listener; }
    public void setDragEnabled(boolean enabled) { this.dragEnabled = enabled; }
    public void setDoubleTapEnabled(boolean enabled) { this.doubleTapEnabled = enabled; }
    public void setChildTouchBottomZonePx(int px) { this.childTouchBottomPx = Math.max(0, px); }
    public void setResizeHandleId(int id) { this.resizeHandleIds = new int[]{id}; }
    public void setResizeHandleIds(int... ids) {
        if (ids == null || ids.length == 0) {
            this.resizeHandleIds = new int[0];
            return;
        }
        this.resizeHandleIds = ids.clone();
    }

    private boolean isInsideResizeHandle(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        for (int id : resizeHandleIds) {
            android.view.View handle = findViewById(id);
            if (handle == null || handle.getVisibility() != VISIBLE) continue;
            if (x >= handle.getLeft() && x <= handle.getRight() && y >= handle.getTop() && y <= handle.getBottom()) return true;
        }
        return false;
    }

    @Override public boolean dispatchTouchEvent(MotionEvent e) {
        // Observe the full gesture stream before child PlayerView/WebView controls can consume it.
        // Skip the resize handle so a resize gesture can never accidentally trigger a double-tap preset.
        boolean inResize = isInsideResizeHandle(e);
        boolean inChildZone = childTouchBottomPx > 0 && e.getY() >= getHeight() - childTouchBottomPx;
        if (!inResize && !inChildZone && doubleTapEnabled) gestureDetector.onTouchEvent(e);
        return super.dispatchTouchEvent(e);
    }

    @Override public boolean onInterceptTouchEvent(MotionEvent e) {
        if (!dragEnabled) return false;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = e.getRawX();
                downY = e.getRawY();
                childDownX = downX;
                childDownY = downY;
                dragging = false;
                childGesture = isInsideResizeHandle(e);
                // The lower control strip is allowed to receive normal taps and horizontal
                // seek-bar gestures, but a clear vertical/diagonal drag can still move the
                // entire PIP from anywhere, including over the playback controls.
                if (!childGesture && childTouchBottomPx > 0 && e.getY() >= getHeight() - childTouchBottomPx) {
                    childGesture = true;
                }
                return false;
            case MotionEvent.ACTION_MOVE:
                if (childGesture && !dragging && childTouchBottomPx > 0 && !isInsideResizeHandle(e)) {
                    float dx = e.getRawX() - childDownX;
                    float dy = e.getRawY() - childDownY;
                    if (Math.abs(dy) > touchSlop && Math.abs(dy) >= Math.abs(dx)) {
                        childGesture = false;
                    } else {
                        return false;
                    }
                }
                if (childGesture) return false;
                if (!dragging && (Math.abs(e.getRawX() - downX) > touchSlop || Math.abs(e.getRawY() - downY) > touchSlop)) {
                    dragging = true;
                    if (listener != null) listener.onPipDragStart(downX, downY);
                    return true;
                }
                return dragging;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (childGesture) { childGesture = false; return false; }
                return dragging;
            default:
                return dragging;
        }
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (dragging) {
            if (e.getActionMasked() == MotionEvent.ACTION_MOVE) {
                if (listener != null) listener.onPipDragMove(e.getRawX(), e.getRawY());
                return true;
            }
            if (e.getActionMasked() == MotionEvent.ACTION_UP || e.getActionMasked() == MotionEvent.ACTION_CANCEL) {
                if (listener != null) listener.onPipDragEnd();
                dragging = false;
                return true;
            }
        }
        return true;
    }
}
