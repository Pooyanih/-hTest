package com.reactionrecorder;

import android.content.Context;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import android.widget.FrameLayout;

/**
 * Floating PIP container.
 * Local-video mode supports one-finger drag. Interactive WebView/YouTube mode
 * leaves one-finger touches to the embedded page and reserves two-finger drag
 * for moving the whole PIP, so login/buttons remain usable.
 */
public class PipFrameLayout extends FrameLayout {
    public interface Listener {
        void onPipDragStart(float rawX, float rawY);
        void onPipDragMove(float rawX, float rawY);
        void onPipDragEnd();
        void onPipDoubleTap();
    }

    private final int touchSlop;
    private float downX, downY;
    private boolean dragging;
    private boolean interactiveContent;
    private Listener listener;
    private final GestureDetector gestureDetector;

    public PipFrameLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
        gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(MotionEvent e) { return true; }
            @Override public boolean onDoubleTap(MotionEvent e) {
                if (!interactiveContent && listener != null) listener.onPipDoubleTap();
                return !interactiveContent;
            }
        });
        setClickable(true);
        setFocusable(false);
    }

    public void setListener(Listener listener) { this.listener = listener; }
    public void setInteractiveContent(boolean value) { interactiveContent = value; }

    @Override public boolean onInterceptTouchEvent(MotionEvent e) {
        gestureDetector.onTouchEvent(e);
        final int action = e.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN) {
            downX = e.getRawX();
            downY = e.getRawY();
            dragging = false;
            return false;
        }
        if (action == MotionEvent.ACTION_MOVE) {
            boolean twoFinger = e.getPointerCount() >= 2;
            boolean allowed = !interactiveContent || twoFinger;
            if (!dragging && allowed && (Math.abs(e.getRawX() - downX) > touchSlop || Math.abs(e.getRawY() - downY) > touchSlop)) {
                dragging = true;
                if (listener != null) listener.onPipDragStart(downX, downY);
                return true;
            }
            return dragging;
        }
        if (action == MotionEvent.ACTION_POINTER_DOWN && interactiveContent && e.getPointerCount() >= 2) {
            downX = e.getRawX();
            downY = e.getRawY();
            return false;
        }
        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            if (dragging) {
                if (listener != null) listener.onPipDragEnd();
                dragging = false;
                return true;
            }
            return false;
        }
        return dragging;
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (dragging) {
            int action = e.getActionMasked();
            if (action == MotionEvent.ACTION_MOVE) {
                if (listener != null) listener.onPipDragMove(e.getRawX(), e.getRawY());
                return true;
            }
            if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                if (listener != null) listener.onPipDragEnd();
                dragging = false;
                return true;
            }
            return true;
        }
        return super.onTouchEvent(e);
    }
}
