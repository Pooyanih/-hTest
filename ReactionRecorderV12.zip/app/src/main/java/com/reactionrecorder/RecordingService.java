package com.reactionrecorder;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import java.util.concurrent.atomic.AtomicBoolean;

import androidx.core.app.ServiceCompat;
import androidx.core.app.NotificationCompat;

import java.io.File;

/** Owns MediaProjection + encoding so Android can keep the recording alive as a foreground task. */
public final class RecordingService extends Service {
    public static final String ACTION_START = "com.reactionrecorder.START";
    public static final String ACTION_STOP = "com.reactionrecorder.STOP";
    public static final String ACTION_PAUSE = "com.reactionrecorder.PAUSE";
    public static final String ACTION_RESUME = "com.reactionrecorder.RESUME";
    public static final String ACTION_PAUSED = "com.reactionrecorder.RECORDING_PAUSED";
    public static final String ACTION_RESUMED = "com.reactionrecorder.RECORDING_RESUMED";
    public static final String ACTION_STARTED = "com.reactionrecorder.RECORDING_STARTED";
    public static final String ACTION_FINISHED = "com.reactionrecorder.RECORDING_FINISHED";
    public static final String ACTION_FAILED = "com.reactionrecorder.RECORDING_FAILED";
    public static final String EXTRA_PROJECTION = "projection";
    public static final String EXTRA_DEVICE_ID = "device_id";
    public static final String EXTRA_MIC_LATENCY_MS = "mic_latency_ms";
    public static final String EXTRA_WIDTH = "width";
    public static final String EXTRA_HEIGHT = "height";
    public static final String EXTRA_FPS = "fps";
    public static final String EXTRA_BITRATE = "bitrate";
    public static final String EXTRA_CODEC = "codec";
    public static final String EXTRA_URI = "uri";
    public static final String EXTRA_ERROR = "error";
    private static final String CHANNEL = "recording";
    private static final int NOTIFICATION_ID = 4201;

    private AudioVideoRecorder recorder;
    private Thread stopThread;
    private final AtomicBoolean stopping = new AtomicBoolean(false);

    @Override public void onCreate() {
        super.onCreate();
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Recording", NotificationManager.IMPORTANCE_LOW));
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        String action = intent.getAction();
        if (ACTION_START.equals(action)) startRecording(intent);
        else if (ACTION_STOP.equals(action)) stopRecording();
        else if (ACTION_PAUSE.equals(action)) setPaused(true);
        else if (ACTION_RESUME.equals(action)) setPaused(false);
        return START_NOT_STICKY;
    }

    private Notification notification() {
        return new NotificationCompat.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("Reaction Recorder")
                .setContentText("Recording reaction video…")
                .setOngoing(true)
                .setCategory(NotificationCompat.CATEGORY_PROGRESS)
                .build();
    }

    private void startForegroundForRecording() {
        int type = 0;
        if (Build.VERSION.SDK_INT >= 29) {
            type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION | ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE;
        }
        ServiceCompat.startForeground(this, NOTIFICATION_ID, notification(), type);
    }

    private void startRecording(Intent intent) {
        if (recorder != null || stopping.get()) return;
        try {
            // Android 14+ requires projection approval before the foreground service starts.
            startForegroundForRecording();
            AudioVideoRecorder.RecordingSettings s = new AudioVideoRecorder.RecordingSettings();
            s.width = intent.getIntExtra(EXTRA_WIDTH, 1080);
            s.height = intent.getIntExtra(EXTRA_HEIGHT, 1920);
            s.fps = intent.getIntExtra(EXTRA_FPS, 30);
            s.bitrate = intent.getIntExtra(EXTRA_BITRATE, 5_000_000);
            s.codec = intent.getStringExtra(EXTRA_CODEC);
            if (s.codec == null) s.codec = "HEVC";
            int deviceId = intent.getIntExtra(EXTRA_DEVICE_ID, -1);
            Integer preferred = deviceId >= 0 ? deviceId : null;
            int micLatencyMs = intent.getIntExtra(EXTRA_MIC_LATENCY_MS, 0);
            Intent projectionData = intent.getParcelableExtra(EXTRA_PROJECTION);
            if (projectionData == null) throw new IllegalArgumentException("Screen capture permission data is missing");
            recorder = new AudioVideoRecorder(this, projectionData, preferred, micLatencyMs, s);
            recorder.start();
            sendBroadcast(new Intent(ACTION_STARTED).setPackage(getPackageName()));
        } catch (Throwable e) {
            sendFailure(e);
            stopSelf();
        }
    }

    private void setPaused(boolean value) {
        AudioVideoRecorder active = recorder;
        if (active == null || stopping.get()) return;
        boolean changed = active.setPaused(value);
        if (changed) sendBroadcast(new Intent(value ? ACTION_PAUSED : ACTION_RESUMED).setPackage(getPackageName()));
    }

    private void stopRecording() {
        if (recorder == null || !stopping.compareAndSet(false, true)) return;
        final AudioVideoRecorder activeRecorder = recorder;
        stopThread = new Thread(() -> {
            File temp = null;
            try {
                temp = activeRecorder.stopAndGetTempFile();
                if (temp == null || !temp.exists() || temp.length() == 0) throw new IllegalStateException("Recording produced no video file");
                android.net.Uri uri = AudioVideoRecorder.publishToGallery(this, temp);
                Intent done = new Intent(ACTION_FINISHED).setPackage(getPackageName());
                done.putExtra(EXTRA_URI, uri.toString());
                sendBroadcast(done);
            } catch (Throwable e) {
                sendFailure(e);
            } finally {
                recorder = null;
                stopThread = null;
                stopping.set(false);
                ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE);
                stopSelf();
            }
        }, "reaction-stop-export");
        stopThread.start();
    }

    private void sendFailure(Throwable e) {
        String msg = e.getMessage();
        if (msg == null || msg.trim().isEmpty()) msg = e.getClass().getSimpleName();
        Intent fail = new Intent(ACTION_FAILED).setPackage(getPackageName());
        fail.putExtra(EXTRA_ERROR, msg);
        sendBroadcast(fail);
    }

    @Override public void onDestroy() {
        // If Android destroys the service unexpectedly, stop the active recorder once.
        if (stopping.compareAndSet(false, true)) {
            AudioVideoRecorder active = recorder;
            if (active != null) {
                try { active.stopAndGetTempFile(); } catch (Exception ignored) {}
            }
            recorder = null;
        }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
