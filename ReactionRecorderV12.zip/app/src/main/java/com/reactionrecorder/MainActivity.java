package com.reactionrecorder;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Dialog;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.media.MediaMetadataRetriever;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.view.View;
import android.view.MotionEvent;
import android.view.KeyEvent;
import android.view.inputmethod.InputMethodManager;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ScrollView;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.MediaItem;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends ComponentActivity {
    private FrameLayout root;
    private PreviewView camera;
    private PlayerView source;
    private WebView youtubeView;
    private ExoPlayer player;
    private Button pick, youtube, play, rewind, forward, record, pauseRecord, settings, rotate;
    private PipFrameLayout pipContainer;
    private View topBar, bottomBar, recordingBadgeView, youtubeLoginBar;
    private View emptyCard, pipEmpty, pipTouchShield;
    private final int[] pipResizeHandleIds = new int[]{
            R.id.pip_resize_nw, R.id.pip_resize_n, R.id.pip_resize_ne,
            R.id.pip_resize_w, R.id.pip_resize_e,
            R.id.pip_resize_sw, R.id.pip_resize_s, R.id.pip_resize_se
    };
    private TextView sourceStatus, sourceTime, recordingBadge;
    private float dragDownX, dragDownY, startTx, startTy;
    private float resizeDownX, resizeDownY;
    private int resizeStartW, resizeStartH;
    private float pipDragStartX, pipDragStartY;
    private float pipCornerRadiusDp = 18f;
    private int pipPresetIndex = 0;
    private int seekSeconds = 10;
    private String storageTreeUri;
    private String storageDisplayName = "Movies / Reaction Recorder";
    private static final String PREF_SEEK_SECONDS = "seek_seconds";
    private Dialog activeSheet;
    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    private final Runnable progressTicker = new Runnable() { @Override public void run() { updateSourceTime(); updateRecordingIndicator(); uiHandler.postDelayed(this, 500); } };
    private Uri sourceUri;
    private String youtubeVideoId;
    private String pendingYouTubeVideoId;
    private boolean youtubeLoginMode;
    private boolean youtubeReady;
    private boolean sourceWasPlayingBeforeYoutubeLogin;
    private long sourcePositionBeforeYoutubeLoginMs;
    private boolean recording;
    private boolean recordingPreparing;
    private boolean recordingPaused;
    private boolean sourceWasPlayingBeforeRecordingPause;
    private int countdownToken;
    private long recordingIndicatorStartMs;
    private long recordingIndicatorPausedSinceMs;
    private long recordingIndicatorPausedTotalMs;
    private boolean recordingIndicatorEnabled = true;
    private boolean cameraFront = true;
    private boolean mirrorCamera = true;
    private boolean cameraReady = false;
    private OnBackPressedCallback recordingBackCallback;
    private boolean resumeCountdownActive = false;
    private int resumeCountdownValue = 0;
    private Runnable pendingRecordingStart;
    private Uri finishedUri;
    private String finishedDisplayName;
    private Integer selectedInputDeviceId;
    private String selectedInputName = "Phone microphone (default)";
    private int micLatencyMs = 0;
    private String uiTheme = "Midnight";
    private boolean compactDock = false;
    private boolean autoHideControls = true;
    private boolean fullscreenRecording = true;
    private boolean recordingBorder = false;
    private final Runnable hideControlsTask = () -> { if ((recording || recordingPreparing) && (fullscreenRecording || autoHideControls)) setChromeVisible(false); else if (!recording && !recordingPreparing && autoHideControls) setChromeVisible(false); };
    private AudioVideoRecorder.RecordingSettings recordingSettings = new AudioVideoRecorder.RecordingSettings();
    private static final int CAPTURE = 77;
    private android.content.SharedPreferences prefs;

    private final BroadcastReceiver recorderReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            String a=intent.getAction();
            if(RecordingService.ACTION_STARTED.equals(a)) {
                recording=true; recordingPreparing=false; recordingPaused=false; if(recordingBackCallback!=null) recordingBackCallback.setEnabled(true);
                recordingIndicatorStartMs=System.currentTimeMillis(); recordingIndicatorPausedSinceMs=0L; recordingIndicatorPausedTotalMs=0L;
                pauseRecord.setVisibility(View.VISIBLE); pauseRecord.setText("Ⅱ"); record.setText("■"); recordingBadge.setVisibility(View.GONE);
                if(findViewById(R.id.recording_border_overlay)!=null) findViewById(R.id.recording_border_overlay).setVisibility(recordingBorder?View.VISIBLE:View.GONE);
                if(findViewById(R.id.pip_record_border)!=null) findViewById(R.id.pip_record_border).setVisibility(recordingBorder?View.VISIBLE:View.GONE);
                setChromeVisible(false); hidePipInteractionChrome(); setPipRecordingVisuals(true); enterImmersiveRecordingMode();
                showRecordingIndicator(); updateRecordingIndicator();
            } else if(RecordingService.ACTION_PAUSED.equals(a)) {
                recordingPaused=true; recordingIndicatorPausedSinceMs=System.currentTimeMillis(); pauseRecord.setText("▶"); pauseRecord.setEnabled(true); recordingBadge.setText("⏸  PAUSED"); sourceStatus.setText("Recording paused"); updateRecordingIndicator(); pauseSource();
            } else if(RecordingService.ACTION_RESUMED.equals(a)) {
                if(recordingIndicatorPausedSinceMs>0L){ recordingIndicatorPausedTotalMs += Math.max(0L,System.currentTimeMillis()-recordingIndicatorPausedSinceMs); recordingIndicatorPausedSinceMs=0L; }
                recordingPaused=false; pauseRecord.setText("Ⅱ"); recordingBadge.setText("●  RECORDING"); updateRecordingIndicator(); if(sourceWasPlayingBeforeRecordingPause) playSource();
            } else if(RecordingService.ACTION_FINISHED.equals(a)) {
                recording=false; recordingPreparing=false; recordingPaused=false; resumeCountdownActive=false; resumeCountdownValue=0; if(recordingBackCallback!=null) recordingBackCallback.setEnabled(true); pauseRecord.setVisibility(View.GONE);
 record.setText("●"); recordingBadge.setVisibility(View.GONE); hideRecordingIndicator(); if(findViewById(R.id.recording_border_overlay)!=null) findViewById(R.id.recording_border_overlay).setVisibility(View.GONE); exitImmersiveRecordingMode(); setPipRecordingVisuals(false); setChromeVisible(true); showPipInteractionChrome(); String s=intent.getStringExtra(RecordingService.EXTRA_URI);
                if(s!=null) {
                    finishedUri=Uri.parse(s);
                    finishedDisplayName=queryDisplayName(finishedUri);
                    showRecordingComplete(finishedUri);
                } else {
                    Toast.makeText(MainActivity.this,"Recording saved",Toast.LENGTH_LONG).show();
                }
            } else if(RecordingService.ACTION_FAILED.equals(a)) {
                recording=false; recordingPreparing=false; recordingPaused=false; resumeCountdownActive=false; resumeCountdownValue=0; if(recordingBackCallback!=null) recordingBackCallback.setEnabled(true); countdownToken++; if(pendingRecordingStart!=null){uiHandler.removeCallbacks(pendingRecordingStart);pendingRecordingStart=null;} pauseRecord.setVisibility(View.GONE);
 record.setText("●"); recordingBadge.setVisibility(View.GONE); hideRecordingIndicator(); if(findViewById(R.id.recording_border_overlay)!=null) findViewById(R.id.recording_border_overlay).setVisibility(View.GONE); if(findViewById(R.id.pip_record_border)!=null) findViewById(R.id.pip_record_border).setVisibility(View.GONE); exitImmersiveRecordingMode(); setPipRecordingVisuals(false); setChromeVisible(true); showPipInteractionChrome(); if(sourceWasPlayingBeforeRecordingPause) playSource(); Toast.makeText(MainActivity.this,"Recording failed: "+intent.getStringExtra(RecordingService.EXTRA_ERROR),Toast.LENGTH_LONG).show();
            }
        }
    };

    private String queryDisplayName(Uri uri){
        try(android.database.Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){
            if(c!=null && c.moveToFirst()) return c.getString(0);
        }catch(Exception ignored){}
        String p=uri.getLastPathSegment();
        return p==null?"Reaction recording.mp4":p;
    }

    private Bitmap loadVideoThumbnail(Uri uri){
        MediaMetadataRetriever r=new MediaMetadataRetriever();
        try{ r.setDataSource(this,uri); return r.getFrameAtTime(500_000,MediaMetadataRetriever.OPTION_CLOSEST_SYNC); }
        catch(Exception ignored){return null;}
        finally{try{r.release();}catch(Exception ignored){}}
    }

    private Uri currentFinishedUri(Uri fallback){ return finishedUri!=null?finishedUri:fallback; }

    private void showRecordingComplete(Uri uri){
        finishedUri=uri;
        LinearLayout content=new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16),dp(4),dp(16),dp(4));

        ImageView thumb=new ImageView(this);
        thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
        thumb.setBackgroundResource(R.drawable.card);
        thumb.setImageResource(android.R.drawable.ic_media_play);
        thumb.setColorFilter(Color.WHITE);
        content.addView(thumb,new LinearLayout.LayoutParams(-1,dp(190)));
        new Thread(()->{ Bitmap b=loadVideoThumbnail(uri); runOnUiThread(()->{ if(b!=null){ thumb.clearColorFilter(); thumb.setImageBitmap(b); } }); },"reaction-thumbnail").start();

        TextView status=label("Recording complete",20,Color.WHITE);
        status.setTypeface(null,android.graphics.Typeface.BOLD);
        status.setPadding(dp(2),dp(14),dp(2),dp(2));
        content.addView(status,new LinearLayout.LayoutParams(-1,dp(40)));

        TextView name=label(finishedDisplayName==null?"Reaction recording.mp4":finishedDisplayName,12,Color.parseColor("#98A1B3"));
        name.setPadding(dp(2),0,dp(2),dp(2));
        content.addView(name,new LinearLayout.LayoutParams(-1,dp(28)));
        TextView savedTo=label("Saved in • "+storageDisplayName,11,Color.parseColor("#98A1B3"));
        savedTo.setPadding(dp(2),0,dp(2),dp(10));
        content.addView(savedTo,new LinearLayout.LayoutParams(-1,dp(28)));

        Button preview=sheetButton("▶  Preview",true); content.addView(preview,new LinearLayout.LayoutParams(-1,dp(48)));
        preview.setOnClickListener(v->openVideo(currentFinishedUri(uri)));
        Button rename=sheetButton("✏  Rename",false); content.addView(rename,new LinearLayout.LayoutParams(-1,dp(46)));
        rename.setOnClickListener(v->renameFinishedVideo(currentFinishedUri(uri),name));
        Button share=sheetButton("📤  Share",false); content.addView(share,new LinearLayout.LayoutParams(-1,dp(46)));
        share.setOnClickListener(v->shareVideo(currentFinishedUri(uri)));
        Button gallery=sheetButton("📁  Open in Gallery",false); content.addView(gallery,new LinearLayout.LayoutParams(-1,dp(46)));
        gallery.setOnClickListener(v->openVideo(currentFinishedUri(uri)));
        Button save=sheetButton("Save",true); content.addView(save,new LinearLayout.LayoutParams(-1,dp(48)));
        save.setOnClickListener(v->{ if(activeSheet!=null) activeSheet.dismiss(); Toast.makeText(this,"Already saved in "+storageDisplayName,Toast.LENGTH_SHORT).show(); });
        Button delete=sheetButton("🗑  Delete",false); content.addView(delete,new LinearLayout.LayoutParams(-1,dp(46)));
        delete.setOnClickListener(v->deleteFinishedVideo(currentFinishedUri(uri)));
        showSheet("Recording complete",content);
    }

    private void openVideo(Uri uri){
        try{
            Intent i=new Intent(Intent.ACTION_VIEW,uri); i.setDataAndType(uri,"video/mp4"); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); startActivity(i);
        }catch(Exception e){Toast.makeText(this,"No video app is available",Toast.LENGTH_SHORT).show();}
    }

    private void shareVideo(Uri uri){
        try{
            Intent i=new Intent(Intent.ACTION_SEND); i.setType("video/mp4"); i.putExtra(Intent.EXTRA_STREAM,uri); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); startActivity(Intent.createChooser(i,"Share recording"));
        }catch(Exception e){Toast.makeText(this,"No app is available to share this recording",Toast.LENGTH_SHORT).show();}
    }

    private void renameFinishedVideo(Uri uri,TextView nameView){
        EditText input=new EditText(this);
        input.setSingleLine(true); input.setText(finishedDisplayName==null?"Reaction recording":finishedDisplayName.replaceFirst("\\.mp4$",""));
        input.setSelectAllOnFocus(true); input.setTextColor(Color.WHITE); input.setHintTextColor(Color.parseColor("#98A1B3")); input.setBackgroundResource(R.drawable.button_secondary);
        LinearLayout box=new LinearLayout(this); box.setPadding(dp(20),0,dp(20),0); box.addView(input,new LinearLayout.LayoutParams(-1,dp(52)));
        new AlertDialog.Builder(this).setTitle("Rename recording").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{
            String n=input.getText().toString().trim(); if(n.isEmpty()) return;
            n=n.replaceAll("[\\/:*?\"<>|]","_");
            if(!n.toLowerCase(Locale.US).endsWith(".mp4")) n+=".mp4";
            try{
                Uri renamed=null;
                try{renamed=DocumentsContract.renameDocument(getContentResolver(),uri,n);}catch(Exception ignored){}
                int changed=renamed!=null?1:0;
                if(changed==0){
                    android.content.ContentValues cv=new android.content.ContentValues(); cv.put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME,n);
                    changed=getContentResolver().update(uri,cv,null,null);
                }
                if(changed>0){finishedDisplayName=n;nameView.setText(n);if(renamed!=null)finishedUri=renamed;Toast.makeText(this,"Renamed",Toast.LENGTH_SHORT).show();}
                else Toast.makeText(this,"Could not rename this recording",Toast.LENGTH_SHORT).show();
            }catch(Exception e){Toast.makeText(this,"Could not rename this recording",Toast.LENGTH_SHORT).show();}
        }).show();
    }

    private void deleteFinishedVideo(Uri uri){
        new AlertDialog.Builder(this).setTitle("Delete recording?").setMessage(finishedDisplayName==null?"This recording will be removed from the Gallery.":finishedDisplayName).setNegativeButton("Cancel",null).setPositiveButton("Delete",(d,w)->{
            try{
                int deleted=0;
                try{deleted=getContentResolver().delete(uri,null,null);}catch(Exception ignored){}
                if(deleted==0){try{if(DocumentsContract.deleteDocument(getContentResolver(),uri))deleted=1;}catch(Exception ignored){}}
                if(deleted>0){
                    if(activeSheet!=null) activeSheet.dismiss();
                    finishedUri=null; finishedDisplayName=null;
                    Toast.makeText(this,"Recording deleted",Toast.LENGTH_SHORT).show();
                } else Toast.makeText(this,"Could not delete the recording",Toast.LENGTH_SHORT).show();
            }catch(Exception e){Toast.makeText(this,"Could not delete the recording",Toast.LENGTH_SHORT).show();}
        }).show();
    }

    private final ActivityResultLauncher<String[]> perms=registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(),r->startCamera());
    private final ActivityResultLauncher<Intent> picker=registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),r->{
        if(r.getResultCode()==RESULT_OK&&r.getData()!=null){sourceUri=r.getData().getData();try{getContentResolver().takePersistableUriPermission(sourceUri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}loadSource(sourceUri);}
    });
    private final ActivityResultLauncher<Intent> storageFolderPicker=registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),r->{
        if(r.getResultCode()!=RESULT_OK||r.getData()==null||r.getData().getData()==null) return;
        Uri tree=r.getData().getData();
        try{
            int flags=r.getData().getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            if(flags!=0) getContentResolver().takePersistableUriPermission(tree,flags);
        }catch(Exception ignored){}
        boolean writable=false;
        try{
            for(android.content.UriPermission permission:getContentResolver().getPersistedUriPermissions()){
                if(permission.getUri().equals(tree)&&permission.isWritePermission()){writable=true;break;}
            }
        }catch(Exception ignored){}
        if(!writable){
            Toast.makeText(this,"The selected folder did not grant write access. Please choose a writable folder.",Toast.LENGTH_LONG).show();
            return;
        }
        try{ DocumentsContract.getTreeDocumentId(tree); }catch(Exception e){
            Toast.makeText(this,"That folder cannot be used for saving.",Toast.LENGTH_LONG).show();
            return;
        }
        Uri oldTree=storageTreeUri==null?null:Uri.parse(storageTreeUri);
        if(oldTree!=null && !oldTree.equals(tree)) releaseStoragePermission(oldTree);
        storageTreeUri=tree.toString();
        storageDisplayName=queryTreeDisplayName(tree);
        if(storageDisplayName==null||storageDisplayName.trim().isEmpty()) storageDisplayName="Custom folder";
        prefs.edit().putString("storage_tree_uri",storageTreeUri).putString("storage_display_name",storageDisplayName).apply();
        Toast.makeText(this,"Save folder: "+storageDisplayName,Toast.LENGTH_LONG).show();
    });

    @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(com.reactionrecorder.R.layout.activity_main);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        root=findViewById(R.id.root);camera=findViewById(R.id.camera);source=findViewById(R.id.source);youtubeView=findViewById(R.id.youtube_view);pick=findViewById(R.id.pick);youtube=findViewById(R.id.youtube);play=findViewById(R.id.play);rewind=findViewById(R.id.rewind);forward=findViewById(R.id.forward);record=findViewById(R.id.record);pauseRecord=findViewById(R.id.pause_record);settings=findViewById(R.id.settings);rotate=findViewById(R.id.rotate);pipContainer=findViewById(R.id.pip_container);topBar=findViewById(R.id.top);bottomBar=findViewById(R.id.bottom);recordingBadgeView=findViewById(R.id.recording_badge);youtubeLoginBar=findViewById(R.id.youtube_login_bar);emptyCard=findViewById(R.id.empty_card);pipEmpty=findViewById(R.id.pip_empty);sourceStatus=findViewById(R.id.source_status);sourceTime=findViewById(R.id.source_time);recordingBadge=findViewById(R.id.recording_badge);pipTouchShield=findViewById(R.id.pip_record_touch_shield);
        prefs=getSharedPreferences("recorder",MODE_PRIVATE);loadPrefs();sanitizeRecordingSettings();savePrefs();
        recordingBackCallback=new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed(){
                if(recording || recordingPreparing){
                    stopRecording();
                } else if(activeSheet!=null && activeSheet.isShowing()){
                    activeSheet.dismiss();
                } else {
                    setEnabled(false);
                    try { getOnBackPressedDispatcher().onBackPressed(); } finally { setEnabled(true); }
                }
            }
        };
        getOnBackPressedDispatcher().addCallback(this,recordingBackCallback);
        loadAppearancePrefs();
        applyPipAppearance();
        restorePipGeometry();
        updateSeekButtonLabels();
        player=new ExoPlayer.Builder(this).setAudioAttributes(new AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).setAllowedCapturePolicy(android.media.AudioAttributes.ALLOW_CAPTURE_BY_ALL).build(),true).build();source.setPlayer(player);
        setupYoutubeWebView();
        restoreLastSource();
        View youtubeLoginBack=findViewById(R.id.youtube_login_back);
        if(youtubeLoginBack!=null) youtubeLoginBack.setOnClickListener(v->closeYouTubeLoginInPip());
        if(Build.VERSION.SDK_INT>=29){try{((AudioManager)getSystemService(AUDIO_SERVICE)).setAllowedCapturePolicy(android.media.AudioAttributes.ALLOW_CAPTURE_BY_ALL);}catch(Exception ignored){}}
        pick.setOnClickListener(v->choose()); youtube.setOnClickListener(v->youtubeDialog()); play.setOnClickListener(v->toggleSource()); rewind.setOnClickListener(v->seekSource(-seekSeconds)); forward.setOnClickListener(v->seekSource(seekSeconds)); record.setOnClickListener(v->{if(recording)stopRecording();else if(!recordingPreparing)requestCapture();else stopRecording();}); pauseRecord.setOnClickListener(v->{if(recording&&!recordingPaused)pauseRecording();else if(recording&&recordingPaused)requestResumeRecording();}); settings.setOnClickListener(v->settingsDialog()); rotate.setOnClickListener(v->toggleOrientation());
        applySystemBarInsets();
        setupPipDragging();
        setupPipResize();
        setupRecordingIndicator();
        pipContainer.bringToFront();
        View indicatorForFront=findViewById(R.id.recording_indicator_container); if(indicatorForFront!=null) indicatorForFront.bringToFront();
        applyAppearanceTheme();
        setupAutoHide();
        setupHardwareKeyboard();
        uiHandler.post(progressTicker);
        player.addListener(new androidx.media3.common.Player.Listener(){ @Override public void onIsPlayingChanged(boolean isPlaying){ play.setText(isPlaying ? "Ⅱ" : "▶"); sourceStatus.setText(isPlaying ? "Playing source" : "Source paused"); } @Override public void onPlaybackStateChanged(int state){ updateSourceTime(); } @Override public void onPlayerError(PlaybackException error){ sourceStatus.setText("Source error • choose another video"); Toast.makeText(MainActivity.this,"Could not play source: "+(error.getMessage()==null?"unsupported or damaged video":error.getMessage()),Toast.LENGTH_LONG).show(); }});
        IntentFilter f=new IntentFilter();f.addAction(RecordingService.ACTION_STARTED);f.addAction(RecordingService.ACTION_PAUSED);f.addAction(RecordingService.ACTION_RESUMED);f.addAction(RecordingService.ACTION_FINISHED);f.addAction(RecordingService.ACTION_FAILED);ContextCompat.registerReceiver(this,recorderReceiver,f,ContextCompat.RECEIVER_NOT_EXPORTED);
        ArrayList<String> startupPermissions=new ArrayList<>();
        startupPermissions.add(Manifest.permission.CAMERA);
        startupPermissions.add(Manifest.permission.RECORD_AUDIO);
        if(Build.VERSION.SDK_INT>=31 && ContextCompat.checkSelfPermission(this,Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){
            startupPermissions.add(Manifest.permission.BLUETOOTH_CONNECT);
        }
        perms.launch(startupPermissions.toArray(new String[0]));
    }

    private void loadAppearancePrefs(){
        uiTheme=prefs.getString("ui_theme","Midnight");
        compactDock=prefs.getBoolean("compact_dock",false);
        autoHideControls=prefs.getBoolean("auto_hide_controls",true);
        fullscreenRecording=prefs.getBoolean("fullscreen_recording",true);
        recordingBorder=prefs.getBoolean("recording_border",false);
    }

    private void applyAppearanceTheme(){
        int accent=Color.parseColor("#7568FF"), bg=Color.parseColor("#080B12");
        if("Ocean".equals(uiTheme)){accent=Color.parseColor("#38BDF8");bg=Color.parseColor("#07131A");}
        else if("Emerald".equals(uiTheme)){accent=Color.parseColor("#34D399");bg=Color.parseColor("#06120E");}
        else if("Sunset".equals(uiTheme)){accent=Color.parseColor("#FB7185");bg=Color.parseColor("#160A0E");}
        root.setBackgroundColor(bg);
        for(View v:new View[]{pick,youtube,play,rewind,forward,settings,rotate}) if(v!=null) v.setBackgroundTintList(android.content.res.ColorStateList.valueOf(v==pick?accent:Color.parseColor("#181F2D")));
        if(record!=null) record.setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent));
        for(View v:new View[]{topBar,bottomBar,emptyCard}) if(v!=null) v.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.argb(225,18,24,34)));
        applyPipAppearance();
        updateDockSize();
    }

    private void updateDockSize(){
        if(bottomBar==null)return;
        bottomBar.setAlpha(compactDock ? .88f : 1f);
        View dock=bottomBar instanceof ViewGroup ? ((ViewGroup)bottomBar).getChildAt(0) : null;
        if(dock!=null){ ViewGroup.LayoutParams lp=dock.getLayoutParams(); lp.height=dp(compactDock?48:56); dock.setLayoutParams(lp); }
    }

    private void setupRecordingIndicator(){
        PipFrameLayout indicator=findViewById(R.id.recording_indicator_container);
        if(indicator==null)return;
        indicator.setResizeHandleId(R.id.recording_indicator_resize);
        indicator.setListener(new PipFrameLayout.Listener(){
            private float sx,sy,tx,ty;
            @Override public void onPipDragStart(float rawX,float rawY){sx=rawX;sy=rawY;tx=indicator.getTranslationX();ty=indicator.getTranslationY();}
            @Override public void onPipDragMove(float rawX,float rawY){setIndicatorTranslationClamped(tx+(rawX-sx),ty+(rawY-sy));}
            @Override public void onPipDragEnd(){saveRecordingIndicatorGeometry();}
            @Override public void onPipDoubleTap(){resetRecordingIndicatorGeometry();}
        });
        View resize=findViewById(R.id.recording_indicator_resize);
        if(resize!=null) resize.setOnTouchListener((v,e)->{
            switch(e.getActionMasked()){
                case MotionEvent.ACTION_DOWN:
                    resizeDownX=e.getRawX(); resizeDownY=e.getRawY(); resizeStartW=indicator.getWidth(); resizeStartH=indicator.getHeight();
                    v.getParent().requestDisallowInterceptTouchEvent(true); return true;
                case MotionEvent.ACTION_MOVE:
                    int minW=dp(64), minH=dp(26); int maxW=Math.max(minW,root.getWidth()); int maxH=Math.max(minH,root.getHeight());
                    int nw=Math.max(minW,Math.min(maxW,resizeStartW+Math.round(e.getRawX()-resizeDownX)));
                    int nh=Math.max(minH,Math.min(maxH,resizeStartH+Math.round(e.getRawY()-resizeDownY)));
                    ViewGroup.LayoutParams lp=indicator.getLayoutParams();lp.width=nw;lp.height=nh;indicator.setLayoutParams(lp);setIndicatorTextSize();setIndicatorTranslationClamped(indicator.getTranslationX(),indicator.getTranslationY());return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    v.getParent().requestDisallowInterceptTouchEvent(false);saveRecordingIndicatorGeometry();v.performClick();return true;
                default:return true;
            }
        });
        restoreRecordingIndicatorGeometry();
        indicator.setVisibility(View.GONE);
    }

    private void setIndicatorTextSize(){
        TextView t=findViewById(R.id.recording_indicator_text); if(t==null)return;
        float w=indicatorWidthDp(); float sp=Math.max(8f,Math.min(16f,w*0.105f)); t.setTextSize(sp);
    }
    private float indicatorWidthDp(){View v=findViewById(R.id.recording_indicator_container);return v==null?132f:v.getWidth()/getResources().getDisplayMetrics().density;}
    private int[] getIndicatorBounds(){return new int[]{0,0,Math.max(1,root.getWidth()),Math.max(1,root.getHeight())};}
    private void setIndicatorTranslationClamped(float tx,float ty){
        View indicator=findViewById(R.id.recording_indicator_container); if(indicator==null||root==null||root.getWidth()<=0||root.getHeight()<=0)return;
        int[] b=getIndicatorBounds();float baseLeft=indicator.getLeft(),baseTop=indicator.getTop();float minX=b[0]-baseLeft,maxX=b[2]-indicator.getWidth()-baseLeft,minY=b[1]-baseTop,maxY=b[3]-indicator.getHeight()-baseTop;
        if(maxX<minX)maxX=minX;if(maxY<minY)maxY=minY;indicator.setTranslationX(Math.max(minX,Math.min(tx,maxX)));indicator.setTranslationY(Math.max(minY,Math.min(ty,maxY)));
    }
    private void restoreRecordingIndicatorGeometry(){
        View indicator=findViewById(R.id.recording_indicator_container);if(indicator==null)return;root.post(()->{int w=prefs.getInt("indicator_width_dp",132),h=prefs.getInt("indicator_height_dp",36);ViewGroup.LayoutParams lp=indicator.getLayoutParams();lp.width=dp(Math.max(64,w));lp.height=dp(Math.max(26,h));indicator.setLayoutParams(lp);float xr=prefs.getFloat("indicator_x_ratio",.04f),yr=prefs.getFloat("indicator_y_ratio",.06f);int[] b=getIndicatorBounds();float maxX=Math.max(0,b[2]-indicator.getWidth()),maxY=Math.max(0,b[3]-indicator.getHeight());setIndicatorTranslationClamped(maxX*Math.max(0,Math.min(1,xr)),maxY*Math.max(0,Math.min(1,yr)));setIndicatorTextSize();});
    }
    private void saveRecordingIndicatorGeometry(){
        View indicator=findViewById(R.id.recording_indicator_container);if(indicator==null||root==null||root.getWidth()<=0)return;int[] b=getIndicatorBounds();float baseLeft=indicator.getLeft(),baseTop=indicator.getTop();float maxX=Math.max(1,b[2]-indicator.getWidth()),maxY=Math.max(1,b[3]-indicator.getHeight());float xr=(indicator.getTranslationX()-(b[0]-baseLeft))/maxX,yr=(indicator.getTranslationY()-(b[1]-baseTop))/maxY;prefs.edit().putInt("indicator_width_dp",Math.round(indicator.getWidth()/getResources().getDisplayMetrics().density)).putInt("indicator_height_dp",Math.round(indicator.getHeight()/getResources().getDisplayMetrics().density)).putFloat("indicator_x_ratio",Math.max(0,Math.min(1,xr))).putFloat("indicator_y_ratio",Math.max(0,Math.min(1,yr))).apply();
    }
    private void resetRecordingIndicatorGeometry(){
        View indicator=findViewById(R.id.recording_indicator_container);if(indicator==null)return;ViewGroup.LayoutParams lp=indicator.getLayoutParams();lp.width=dp(132);lp.height=dp(36);indicator.setLayoutParams(lp);int baseLeft=indicator.getLeft(),baseTop=indicator.getTop();setIndicatorTranslationClamped(dp(16)-baseLeft,dp(24)-baseTop);setIndicatorTextSize();saveRecordingIndicatorGeometry();
    }
    private void showRecordingIndicator(){View v=findViewById(R.id.recording_indicator_container);if(v==null)return;if(recordingIndicatorEnabled){v.setVisibility(View.VISIBLE);v.bringToFront();setIndicatorTextSize();}}
    private void hideRecordingIndicator(){View v=findViewById(R.id.recording_indicator_container);if(v!=null)v.setVisibility(View.GONE);}
    private void updateRecordingIndicator(){
        if(!recording||!recordingIndicatorEnabled)return;TextView t=findViewById(R.id.recording_indicator_text);if(t==null)return;if(resumeCountdownActive){t.setText("● RESUME "+resumeCountdownValue);return;}long now=System.currentTimeMillis();long paused=recordingIndicatorPausedTotalMs;if(recordingIndicatorPausedSinceMs>0)paused+=Math.max(0,now-recordingIndicatorPausedSinceMs);long elapsed=Math.max(0,now-recordingIndicatorStartMs-paused);long sec=elapsed/1000;String prefix=recordingPaused?"⏸ ":"● REC ";t.setText(prefix+String.format(Locale.US,"%02d:%02d",sec/60,sec%60));}

    private void setupAutoHide(){
        root.setOnTouchListener((v,e)->{
            if(e.getAction()==MotionEvent.ACTION_DOWN && !recording && !recordingPreparing){
                setChromeVisible(true);
                scheduleHideControls();
            }
            return false;
        });
        View.OnTouchListener touch=(v,e)->{
            if(e.getAction()==MotionEvent.ACTION_DOWN && !recording && !recordingPreparing){
                setChromeVisible(true);
                scheduleHideControls();
            }
            return false;
        };
        for(View v:new View[]{topBar,bottomBar,pipContainer,recordingBadgeView}) if(v!=null) v.setOnTouchListener(touch);
        scheduleHideControls();
    }

    private void scheduleHideControls(){
        uiHandler.removeCallbacks(hideControlsTask);
        if(recording || recordingPreparing){
            if(autoHideControls || fullscreenRecording) uiHandler.postDelayed(hideControlsTask,3500);
            return;
        }
        if(!autoHideControls)return;
        uiHandler.postDelayed(hideControlsTask,3500);
    }

    private void setChromeVisible(boolean visible){
        // During an active capture session the app chrome must never be resurrected by a touch.
        if((recording || recordingPreparing) && visible)return;
        if(topBar!=null) topBar.setVisibility(visible?View.VISIBLE:View.GONE);
        if(bottomBar!=null) bottomBar.setVisibility(visible?View.VISIBLE:View.GONE);
        if(recordingBadgeView!=null) recordingBadgeView.setVisibility(visible && recording && !fullscreenRecording ? View.VISIBLE : View.GONE);
        if(visible) scheduleHideControls();
    }

    private void showAppearanceSettings(){
        LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL);
        TextView preview=label("UI PREVIEW",10,Color.parseColor("#98A1B3")); preview.setTypeface(null,android.graphics.Typeface.BOLD); c.addView(preview,new LinearLayout.LayoutParams(-1,dp(28)));
        LinearLayout previewBox=new LinearLayout(this); previewBox.setGravity(android.view.Gravity.CENTER); previewBox.setPadding(dp(12),dp(12),dp(12),dp(12)); previewBox.setBackgroundResource(R.drawable.panel);
        TextView sample=label("  ●  Reaction Recorder     ⚙   \n\n          CAMERA PREVIEW\n\n     ─── control dock ───",13,Color.WHITE); sample.setGravity(android.view.Gravity.CENTER); previewBox.addView(sample,new LinearLayout.LayoutParams(-1,dp(150))); c.addView(previewBox,new LinearLayout.LayoutParams(-1,dp(170)));
        String[] themes={"Midnight","Ocean","Emerald","Sunset"}; for(String t:themes){Button b=sheetButton((t.equals(uiTheme)?"✓  ":"")+t,t.equals(uiTheme)); c.addView(b,new LinearLayout.LayoutParams(-1,dp(46))); b.setOnClickListener(v->{uiTheme=t;prefs.edit().putString("ui_theme",t).apply();applyAppearanceTheme();if(activeSheet!=null)activeSheet.dismiss();showAppearanceSettings();});}
        Button compact=sheetButton((compactDock?"✓  ":"")+"Transparent / compact control dock",compactDock);c.addView(compact,new LinearLayout.LayoutParams(-1,dp(46)));compact.setOnClickListener(v->{compactDock=!compactDock;prefs.edit().putBoolean("compact_dock",compactDock).apply();applyAppearanceTheme();});
        Button auto=sheetButton((autoHideControls?"✓  ":"")+"Auto-hide controls after 3.5 seconds",autoHideControls);c.addView(auto,new LinearLayout.LayoutParams(-1,dp(46)));auto.setOnClickListener(v->{autoHideControls=!autoHideControls;prefs.edit().putBoolean("auto_hide_controls",autoHideControls).apply();if(!autoHideControls)setChromeVisible(true);else scheduleHideControls();});
        Button full=sheetButton((fullscreenRecording?"✓  ":"")+"Fullscreen recording mode • hide system bars",fullscreenRecording);c.addView(full,new LinearLayout.LayoutParams(-1,dp(46)));full.setOnClickListener(v->{fullscreenRecording=!fullscreenRecording;prefs.edit().putBoolean("fullscreen_recording",fullscreenRecording).apply();});
        Button border=sheetButton((recordingBorder?"✓  ":"")+"Recording border around camera + PIP",recordingBorder);c.addView(border,new LinearLayout.LayoutParams(-1,dp(46)));border.setOnClickListener(v->{recordingBorder=!recordingBorder;prefs.edit().putBoolean("recording_border",recordingBorder).apply();});
        showSheet("Appearance",c);
    }

    private void applySystemBarInsets(){
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets bars=insets.getInsets(WindowInsetsCompat.Type.systemBars());
            ViewGroup.MarginLayoutParams topLp=(ViewGroup.MarginLayoutParams)topBar.getLayoutParams();
            topLp.topMargin=bars.top+dp(8);
            topBar.setLayoutParams(topLp);

            ViewGroup.MarginLayoutParams bottomLp=(ViewGroup.MarginLayoutParams)bottomBar.getLayoutParams();
            bottomLp.bottomMargin=bars.bottom+dp(8);
            bottomBar.setLayoutParams(bottomLp);

            ViewGroup.MarginLayoutParams badgeLp=(ViewGroup.MarginLayoutParams)recordingBadgeView.getLayoutParams();
            badgeLp.topMargin=bars.top+dp(66);
            recordingBadgeView.setLayoutParams(badgeLp);
            root.post(()->{restorePipGeometry();clampPipPosition();});
            return insets;
        });
        ViewCompat.requestApplyInsets(root);
    }

    private void setupHardwareKeyboard(){
        // Hardware shortcuts are intentionally handled at the Activity level so they keep working
        // when the visual controls are auto-hidden. They are only intercepted during recording,
        // so YouTube login/text fields retain normal keyboard behavior when not recording.
    }

    @Override public boolean dispatchTouchEvent(MotionEvent event){
        if(event.getActionMasked()==MotionEvent.ACTION_DOWN && !recording && !recordingPreparing){
            setChromeVisible(true);
            scheduleHideControls();
        }
        return super.dispatchTouchEvent(event);
    }

    @Override public boolean dispatchKeyEvent(KeyEvent event){
        if(recording && event.getAction()==KeyEvent.ACTION_DOWN && event.getRepeatCount()==0){
            int code=event.getKeyCode();
            if(code==KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE || code==KeyEvent.KEYCODE_SPACE){
                toggleSource(); scheduleHideControls(); return true;
            }
            if(code==KeyEvent.KEYCODE_MEDIA_REWIND || code==KeyEvent.KEYCODE_DPAD_LEFT || code==KeyEvent.KEYCODE_A){
                seekSource(-seekSeconds); scheduleHideControls(); return true;
            }
            if(code==KeyEvent.KEYCODE_MEDIA_FAST_FORWARD || code==KeyEvent.KEYCODE_DPAD_RIGHT || code==KeyEvent.KEYCODE_D){
                seekSource(seekSeconds); scheduleHideControls(); return true;
            }
            if(code==KeyEvent.KEYCODE_MEDIA_STOP || code==KeyEvent.KEYCODE_S || code==KeyEvent.KEYCODE_R){
                stopRecording(); return true;
            }
            if(code==KeyEvent.KEYCODE_P){
                if(recordingPaused) requestResumeRecording(); else pauseRecording();
                return true;
            }
            if(code==KeyEvent.KEYCODE_O){
                toggleOrientation();
                return true;
            }
        }
        return super.dispatchKeyEvent(event);
    }

    private void toggleOrientation(){
        int current=getResources().getConfiguration().orientation;
        int next=current==android.content.res.Configuration.ORIENTATION_LANDSCAPE
                ? ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                : ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE;
        // Orientation is allowed during recording. The encoder keeps the selected
        // recording canvas; the live app composition and PIP layout can rotate
        // without stopping the recording.
        setRequestedOrientation(next);
        root.postDelayed(()->{ restorePipGeometry(); clampPipPosition(); },250);
    }

    @Override public void onWindowFocusChanged(boolean hasFocus){
        super.onWindowFocusChanged(hasFocus);
        if(hasFocus && (recording || recordingPreparing)) enterImmersiveRecordingMode();
    }

    @Override public void onConfigurationChanged(android.content.res.Configuration newConfig){
        super.onConfigurationChanged(newConfig);
        if(root!=null){
            if(recording || recordingPreparing) enterImmersiveRecordingMode();
            root.post(()->{
                applySystemBarInsets();
                restorePipGeometry();
                clampPipPosition();
                restoreRecordingIndicatorGeometry();
            });
        }
    }

    private void loadPrefs(){recordingSettings.codec=prefs.getString("codec","HEVC");recordingSettings.width=prefs.getInt("width",1080);recordingSettings.height=prefs.getInt("height",1920);recordingSettings.fps=prefs.getInt("fps",30);recordingSettings.bitrate=prefs.getInt("bitrate",5_000_000);seekSeconds=Math.max(1,Math.min(60,prefs.getInt(PREF_SEEK_SECONDS,10)));micLatencyMs=Math.max(0,Math.min(500,prefs.getInt("mic_latency_ms",0)));selectedInputName=prefs.getString("input_name","Phone microphone (default)");selectedInputDeviceId=prefs.getInt("input_device_id",-1)>=0?prefs.getInt("input_device_id",-1):null;pipCornerRadiusDp=Math.max(0,Math.min(40,prefs.getFloat("pip_corner_radius",18f)));pipPresetIndex=Math.max(0,prefs.getInt("pip_preset",0));storageTreeUri=prefs.getString("storage_tree_uri",null);storageDisplayName=prefs.getString("storage_display_name","Movies / Reaction Recorder");recordingIndicatorEnabled=prefs.getBoolean("recording_indicator_enabled",true);cameraFront=prefs.getBoolean("camera_front",true);mirrorCamera=prefs.getBoolean("mirror_camera",true);}

    private void sanitizeRecordingSettings(){
        recordingSettings.width=even(Math.max(2,recordingSettings.width));
        recordingSettings.height=even(Math.max(2,recordingSettings.height));
        recordingSettings.fps=Math.max(15,Math.min(60,recordingSettings.fps));
        recordingSettings.bitrate=Math.max(500_000,Math.min(50_000_000,recordingSettings.bitrate));
        if(!"HEVC".equals(recordingSettings.codec) && !"H.264".equals(recordingSettings.codec)) recordingSettings.codec="HEVC";
    }
    private void saveSeekSeconds(){seekSeconds=Math.max(1,Math.min(60,seekSeconds));prefs.edit().putInt(PREF_SEEK_SECONDS,seekSeconds).apply();updateSeekButtonLabels();}
    private void updateSeekButtonLabels(){if(rewind!=null)rewind.setText("−"+seekSeconds);if(forward!=null)forward.setText("+"+seekSeconds);}
    private void savePrefs(){prefs.edit().putString("input_name",selectedInputName).putInt("input_device_id",selectedInputDeviceId==null?-1:selectedInputDeviceId).putInt("mic_latency_ms",micLatencyMs).putString("codec",recordingSettings.codec).putInt("width",recordingSettings.width).putInt("height",recordingSettings.height).putInt("fps",recordingSettings.fps).putInt("bitrate",recordingSettings.bitrate).putBoolean("recording_indicator_enabled",recordingIndicatorEnabled).putBoolean("camera_front",cameraFront).putBoolean("mirror_camera",mirrorCamera).apply();}

    private void restoreLastSource(){
        String type=prefs.getString("last_source_type","");
        if("local".equals(type)){
            String raw=prefs.getString("last_source_uri",null);
            if(raw!=null){
                try{ Uri u=Uri.parse(raw);
                    boolean ok=false;
                    for(android.content.UriPermission permission:getContentResolver().getPersistedUriPermissions()) if(permission.getUri().equals(u)&&permission.isReadPermission()){ok=true;break;}
                    if(ok){ sourceUri=u; loadSource(u); return; }
                }catch(Exception ignored){}
            }
        }else if("youtube".equals(type)){
            String id=prefs.getString("last_youtube_id",null);
            if(cleanYouTubeId(id)!=null){ loadYouTube(id); return; }
        }
        sourceUri=null; youtubeVideoId=null;
    }

    private void choose(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("video/*");i.addCategory(Intent.CATEGORY_OPENABLE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);picker.launch(i);}
    private void loadSource(Uri u){
        if(u==null)return;
        sourceUri=u;
        prefs.edit().putString("last_source_type","local").putString("last_source_uri",u.toString()).remove("last_youtube_id").apply();
        youtubeLoginMode=false; pendingYouTubeVideoId=null; if(youtubeLoginBar!=null) youtubeLoginBar.setVisibility(View.GONE);
        stopYouTubePlayback(); youtubeVideoId=null; youtubeReady=false; youtubeView.setVisibility(View.GONE); source.setVisibility(View.VISIBLE); pipEmpty.setVisibility(View.GONE);
        enforcePipMinimum();
        player.setMediaItem(MediaItem.fromUri(u));
        player.prepare();
        player.pause();
        player.seekTo(0);
        play.setText("▶");
        emptyCard.setVisibility(View.GONE);
        sourceStatus.setText("Source ready • tap ▶ to play");
        sourceTime.setText("00:00 / --:--");
        showPipInteractionChrome();
    }
    private boolean hasSource(){ return sourceUri!=null || youtubeVideoId!=null; }

    private void toggleSource(){
        if(recording && recordingPaused) return;
        if(!hasSource()){ choose(); return; }
        if(youtubeVideoId!=null){
            if(!youtubeReady) return;
            youtubeView.evaluateJavascript("(function(){ if(!player)return; var s=player.getPlayerState(); if(s===1){player.pauseVideo();}else if(s===0){player.seekTo(0,true);player.playVideo();}else{player.playVideo();} })();", null);
        } else if(player.isPlaying()) player.pause(); else { if(player.getPlaybackState()==androidx.media3.common.Player.STATE_ENDED) player.seekTo(0); player.play(); }
    }

    private void seekSource(int seconds){
        if(seconds==0)return;
        if(youtubeVideoId!=null){
            if(!youtubeReady)return;
            String js="(function(){try{var p=window.player;if(!p||typeof p.getCurrentTime!==\"function\")return;var t=Number(p.getCurrentTime())||0;var d=Number(p.getDuration())||0;var n=Math.max(0,t+("+seconds+"));if(d>0)n=Math.min(d,n);p.seekTo(n,true);}catch(e){}})();";
            youtubeView.evaluateJavascript(js,null);
        } else if(player!=null){
            long target=Math.max(0,player.getCurrentPosition()+seconds*1000L);
            long duration=player.getDuration();
            if(duration>0)target=Math.min(duration,target);
            player.seekTo(target);
        }
    }

    private void updateSourceTime(){
        if(player==null || sourceTime==null) return;
        if(youtubeVideoId!=null){
            if(!youtubeReady) return;
            youtubeView.evaluateJavascript("(function(){return JSON.stringify({p:player?player.getCurrentTime():0,d:player?player.getDuration():0,s:player?player.getPlayerState():-1});})()", value -> {
                try {
                    String v=value==null?"":value.replace("\\\"","\"").replace("\"{", "{").replace("}\"", "}");
                    org.json.JSONObject o=new org.json.JSONObject(v);
                    long pos=(long)(o.optDouble("p",0)*1000); long dur=(long)(o.optDouble("d",0)*1000);
                    sourceTime.setText(formatTime(pos)+" / "+(dur>0?formatTime(dur):"--:--"));
                    int state=o.optInt("s",-1); play.setText(state==1?"Ⅱ":"▶");
                    sourceStatus.setText(state==1?"Playing YouTube source":"YouTube source paused");
                } catch(Exception ignored) {}
            });
            return;
        }
        long pos=Math.max(0,player.getCurrentPosition()); long dur=player.getDuration();
        sourceTime.setText(formatTime(pos)+" / "+(dur>0?formatTime(dur):"--:--"));
    }

    private String formatTime(long ms){ long total=Math.max(0,ms/1000); long h=total/3600; long m=(total%3600)/60; long s=total%60; return h>0?String.format(Locale.US,"%02d:%02d:%02d",h,m,s):String.format(Locale.US,"%02d:%02d",m,s); }

    private void setupPipDragging(){
        pipContainer.setResizeHandleIds(pipResizeHandleIds);
        pipContainer.setDragEnabled(true); pipContainer.setDoubleTapEnabled(true); pipContainer.setChildTouchBottomZonePx(dp(64));
        pipContainer.setListener(new PipFrameLayout.Listener(){
            @Override public void onPipDragStart(float rawX,float rawY){
                pipDragStartX=rawX; pipDragStartY=rawY;
                startTx=pipContainer.getTranslationX(); startTy=pipContainer.getTranslationY();
            }
            @Override public void onPipDragMove(float rawX,float rawY){
                float nx=startTx+(rawX-pipDragStartX), ny=startTy+(rawY-pipDragStartY);
                setPipTranslationClamped(nx,ny);
            }
            @Override public void onPipDragEnd(){savePipGeometry(); snapPipToNearestCornerIfClose();}
            @Override public void onPipDoubleTap(){cyclePipPreset();}
        });
    }

    private int pipMinWidthPx(){ return dp((youtubeVideoId!=null || youtubeLoginMode)?200:96); }
    private int pipMinHeightPx(){ return dp((youtubeVideoId!=null || youtubeLoginMode)?200:72); }

    private void enforcePipMinimum(){
        if(pipContainer==null) return;
        int minW=pipMinWidthPx(), minH=pipMinHeightPx();
        ViewGroup.LayoutParams lp=pipContainer.getLayoutParams();
        boolean changed=false;
        if(lp.width<minW){lp.width=minW;changed=true;}
        if(lp.height<minH){lp.height=minH;changed=true;}
        if(changed){pipContainer.setLayoutParams(lp);clampPipPosition();savePipGeometry();}
    }

    private void setupPipResize(){
        final int[] directions = new int[]{
                1, 2, 3, 4, 6, 7, 8, 9
        };
        for(int i=0;i<pipResizeHandleIds.length;i++){
            View handle=findViewById(pipResizeHandleIds[i]);
            if(handle==null) continue;
            final int direction=directions[i];
            handle.setOnTouchListener((v,e)->handlePipResizeTouch(v,e,direction));
        }
    }

    /** Resize from any of the eight sides/corners while keeping the opposite edge fixed. */
    private boolean handlePipResizeTouch(View handle, MotionEvent e, int direction){
        final boolean left=(direction==1||direction==4||direction==7);
        final boolean right=(direction==3||direction==6||direction==9);
        final boolean top=(direction==1||direction==2||direction==3);
        final boolean bottom=(direction==7||direction==8||direction==9);
        switch(e.getActionMasked()){
            case MotionEvent.ACTION_DOWN:
                resizeDownX=e.getRawX(); resizeDownY=e.getRawY();
                resizeStartW=pipContainer.getWidth(); resizeStartH=pipContainer.getHeight();
                handle.setTag(new float[]{
                        pipContainer.getLeft()+pipContainer.getTranslationX(),
                        pipContainer.getTop()+pipContainer.getTranslationY()
                });
                handle.getParent().requestDisallowInterceptTouchEvent(true);
                return true;
            case MotionEvent.ACTION_MOVE:{
                float[] start=(float[])handle.getTag();
                if(start==null) return true;
                float dx=e.getRawX()-resizeDownX, dy=e.getRawY()-resizeDownY;
                float startLeft=start[0], startTop=start[1];
                float startRight=startLeft+resizeStartW, startBottom=startTop+resizeStartH;
                int minW=pipMinWidthPx(), minH=pipMinHeightPx();
                float newLeft=startLeft, newRight=startRight, newTop=startTop, newBottom=startBottom;
                if(left) newLeft=Math.min(startLeft+dx, startRight-minW);
                if(right) newRight=Math.max(startRight+dx, startLeft+minW);
                if(top) newTop=Math.min(startTop+dy, startBottom-minH);
                if(bottom) newBottom=Math.max(startBottom+dy, startTop+minH);
                newLeft=Math.max(0,newLeft); newTop=Math.max(0,newTop);
                newRight=Math.min(root.getWidth(),newRight); newBottom=Math.min(root.getHeight(),newBottom);
                if(right && !left) newLeft=startLeft;
                if(left && !right) newRight=startRight;
                if(bottom && !top) newTop=startTop;
                if(top && !bottom) newBottom=startBottom;
                if(newRight-newLeft<minW){
                    if(left && !right) newLeft=newRight-minW; else newRight=newLeft+minW;
                    newLeft=Math.max(0,newLeft); newRight=Math.min((float)root.getWidth(),newRight);
                }
                if(newBottom-newTop<minH){
                    if(top && !bottom) newTop=newBottom-minH; else newBottom=newTop+minH;
                    newTop=Math.max(0,newTop); newBottom=Math.min((float)root.getHeight(),newBottom);
                }
                int nw=Math.max(minW,Math.round(newRight-newLeft));
                int nh=Math.max(minH,Math.round(newBottom-newTop));
                ViewGroup.LayoutParams lp=pipContainer.getLayoutParams(); lp.width=nw; lp.height=nh; pipContainer.setLayoutParams(lp);
                float baseLeft=pipContainer.getLeft(), baseTop=pipContainer.getTop();
                setPipTranslationClamped(newLeft-baseLeft,newTop-baseTop);
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                handle.getParent().requestDisallowInterceptTouchEvent(false);
                savePipGeometry();
                handle.performClick();
                handle.setTag(null);
                return true;
            default:return true;
        }
    }

    /** PIP is intentionally allowed over every part of the app UI. Only the physical screen edges are bounds. */
    private int[] getPipSafeBounds(){
        int margin=0;
        int left=margin, top=margin;
        int width=Math.max(dp(96),root.getWidth());
        int height=Math.max(dp(72),root.getHeight());
        return new int[]{left,top,width,height};
    }

    private void setPipTranslationClamped(float tx,float ty){
        if(root==null||pipContainer==null||root.getWidth()<=0||root.getHeight()<=0)return;
        int[] b=getPipSafeBounds(); float baseLeft=pipContainer.getLeft(), baseTop=pipContainer.getTop();
        float minX=b[0]-baseLeft, maxX=b[0]+b[2]-pipContainer.getWidth()-baseLeft;
        float minY=b[1]-baseTop, maxY=b[1]+b[3]-pipContainer.getHeight()-baseTop;
        if(maxX<minX) maxX=minX; if(maxY<minY) maxY=minY;
        pipContainer.setTranslationX(Math.max(minX,Math.min(tx,maxX)));
        pipContainer.setTranslationY(Math.max(minY,Math.min(ty,maxY)));
    }

    private void clampPipPosition(){setPipTranslationClamped(pipContainer.getTranslationX(),pipContainer.getTranslationY());}

    private void snapPipToNearestCornerIfClose(){
        int[] b=getPipSafeBounds(); float baseLeft=pipContainer.getLeft(), baseTop=pipContainer.getTop();
        float minX=b[0]-baseLeft, maxX=b[0]+b[2]-pipContainer.getWidth()-baseLeft;
        float minY=b[1]-baseTop, maxY=b[1]+b[3]-pipContainer.getHeight()-baseTop;
        float x=pipContainer.getTranslationX(), y=pipContainer.getTranslationY();
        float threshold=dp(28);
        float sx=Math.abs(x-minX)<threshold?minX:Math.abs(x-maxX)<threshold?maxX:x;
        float sy=Math.abs(y-minY)<threshold?minY:Math.abs(y-maxY)<threshold?maxY:y;
        pipContainer.setTranslationX(sx); pipContainer.setTranslationY(sy); savePipGeometry();
    }

    private void cyclePipPreset(){
        int[] b=getPipSafeBounds(); int[] widths={Math.round(b[2]*.28f),Math.round(b[2]*.38f),Math.round(b[2]*.50f),Math.round(b[2]*.62f)};
        pipPresetIndex=(pipPresetIndex+1)%widths.length;
        int nw=Math.max(dp(140),widths[pipPresetIndex]); int nh=Math.max(dp(100),Math.round(nw*(pipContainer.getHeight()/(float)Math.max(1,pipContainer.getWidth()))));
        nh=Math.min(nh,b[3]);
        float cx=pipContainer.getLeft()+pipContainer.getTranslationX()+pipContainer.getWidth()/2f;
        float cy=pipContainer.getTop()+pipContainer.getTranslationY()+pipContainer.getHeight()/2f;
        ViewGroup.LayoutParams lp=pipContainer.getLayoutParams();lp.width=nw;lp.height=nh;pipContainer.setLayoutParams(lp);
        float tx=cx-(pipContainer.getLeft()+nw/2f),ty=cy-(pipContainer.getTop()+nh/2f);setPipTranslationClamped(tx,ty);snapPipToNearestCornerIfClose();
        prefs.edit().putInt("pip_preset",pipPresetIndex).apply();
    }

    private void restorePipGeometry(){
        if(pipContainer==null)return;
        root.post(()->{
            int w=prefs.getInt("pip_width_dp",240), h=prefs.getInt("pip_height_dp",200);
            ViewGroup.LayoutParams lp=pipContainer.getLayoutParams();lp.width=dp(w);lp.height=dp(h);pipContainer.setLayoutParams(lp);
            float xr=prefs.getFloat("pip_x_ratio",1f), yr=prefs.getFloat("pip_y_ratio",0f);
            int[] b=getPipSafeBounds(); float baseLeft=pipContainer.getLeft(),baseTop=pipContainer.getTop();
            float maxX=Math.max(0,b[2]-pipContainer.getWidth()),maxY=Math.max(0,b[3]-pipContainer.getHeight());
            setPipTranslationClamped(b[0]-baseLeft+maxX*xr,b[1]-baseTop+maxY*yr);
        });
    }

    private void savePipGeometry(){
        if(pipContainer==null||root==null||root.getWidth()<=0)return;
        int[] b=getPipSafeBounds(); float baseLeft=pipContainer.getLeft(),baseTop=pipContainer.getTop();
        float maxX=Math.max(1,b[2]-pipContainer.getWidth()),maxY=Math.max(1,b[3]-pipContainer.getHeight());
        float x=(pipContainer.getTranslationX()-(b[0]-baseLeft))/maxX, y=(pipContainer.getTranslationY()-(b[1]-baseTop))/maxY;
        prefs.edit().putInt("pip_width_dp",Math.round(pipContainer.getWidth()/getResources().getDisplayMetrics().density)).putInt("pip_height_dp",Math.round(pipContainer.getHeight()/getResources().getDisplayMetrics().density)).putFloat("pip_x_ratio",Math.max(0,Math.min(1,x))).putFloat("pip_y_ratio",Math.max(0,Math.min(1,y))).putFloat("pip_corner_radius",pipCornerRadiusDp).apply();
    }

    private void applyPipAppearance(){
        if(pipContainer==null)return;
        GradientDrawable g=new GradientDrawable(); g.setColor(Color.rgb(9,12,18)); g.setStroke(dp(2),Color.parseColor("#7568FF")); g.setCornerRadius(dp(pipCornerRadiusDp));
        pipContainer.setBackground(g); pipContainer.setClipToOutline(pipCornerRadiusDp>0);
    }

    private void youtubeDialog(){
        EditText e=new EditText(this);
        e.setHint("https://www.youtube.com/watch?v=...");
        new AlertDialog.Builder(this)
                .setTitle("YouTube source")
                .setMessage("Paste a YouTube video link. It will play inside the reaction recorder; the app does not download the YouTube video.")
                .setView(e)
                .setNegativeButton("Cancel",null)
                .setPositiveButton("Load in app",(d,w)->{
                    String id=extractYouTubeId(e.getText().toString().trim());
                    if(id==null) Toast.makeText(this,"That doesn't look like a supported YouTube video link.",Toast.LENGTH_LONG).show();
                    else loadYouTube(id);
                })
                .setNeutralButton("Sign in / Manage YouTube",(d,w)->openYouTubeLoginInPip())
                .show();
    }

    private void openYouTubeLoginInPip(){
        pendingYouTubeVideoId = youtubeVideoId;
        sourceWasPlayingBeforeYoutubeLogin = youtubeVideoId==null && player!=null && player.isPlaying();
        sourcePositionBeforeYoutubeLoginMs = youtubeVideoId==null && player!=null ? Math.max(0,player.getCurrentPosition()) : 0;
        if(youtubeVideoId==null && player!=null) player.pause();
        youtubeLoginMode=true;
        youtubeReady=false;
        showPipInteractionChrome();
        youtubeView.setVisibility(View.VISIBLE);
        source.setVisibility(View.GONE);
        pipEmpty.setVisibility(View.GONE);
        emptyCard.setVisibility(View.GONE);
        if(youtubeLoginBar!=null) youtubeLoginBar.setVisibility(View.VISIBLE);
        enforcePipMinimum();
        sourceStatus.setText("YouTube account • sign in inside PIP");
        sourceTime.setText("Sign in, then tap Back to video");
        play.setText("▶");
        stopYouTubePlayback();
        try {
            android.webkit.CookieManager.getInstance().flush();
        } catch(Exception ignored) {}
        youtubeView.loadUrl("https://www.youtube.com/");
    }

    private void closeYouTubeLoginInPip(){
        youtubeLoginMode=false;
        if(youtubeLoginBar!=null) youtubeLoginBar.setVisibility(View.GONE);
        String id=pendingYouTubeVideoId;
        pendingYouTubeVideoId=null;
        if(id!=null) loadYouTube(id);
        else if(sourceUri!=null){
            youtubeView.setVisibility(View.GONE);
            source.setVisibility(View.VISIBLE);
            pipEmpty.setVisibility(View.GONE);
            emptyCard.setVisibility(View.GONE);
            sourceStatus.setText("Source ready • tap ▶ to play");
            if(player!=null && sourcePositionBeforeYoutubeLoginMs>0) player.seekTo(sourcePositionBeforeYoutubeLoginMs);
            updateSourceTime();
            play.setText("▶");
            showPipInteractionChrome();
            if(sourceWasPlayingBeforeYoutubeLogin) playSource();
            sourceWasPlayingBeforeYoutubeLogin=false;
            sourcePositionBeforeYoutubeLoginMs=0;
        } else {
            youtubeView.setVisibility(View.GONE);
            source.setVisibility(View.VISIBLE);
            pipEmpty.setVisibility(View.VISIBLE);
            sourceStatus.setText("No YouTube video selected");
            sourceWasPlayingBeforeYoutubeLogin=false;
            sourcePositionBeforeYoutubeLoginMs=0;
        }
    }

    private String extractYouTubeId(String raw){
        if(raw==null||raw.isEmpty()) return null;
        try{
            String s=raw.trim();
            if(!s.matches("https?://.*")) return null;
            Uri u=Uri.parse(s);
            String host=u.getHost()==null?"":u.getHost().toLowerCase(Locale.US);
            if(host.equals("youtu.be")){ String p=u.getPath(); return cleanYouTubeId(p==null?null:p.substring(p.startsWith("/")?1:0)); }
            if(host.equals("youtube.com")||host.endsWith(".youtube.com")){
                String v=u.getQueryParameter("v");
                if(v!=null) return cleanYouTubeId(v);
                String p=u.getPath();
                if(p!=null){
                    String[] a=p.split("/");
                    if(a.length>=3 && ("shorts".equals(a[1])||"embed".equals(a[1])||"live".equals(a[1]))) return cleanYouTubeId(a[2]);
                }
            }
        }catch(Exception ignored){}
        return null;
    }

    private String cleanYouTubeId(String id){
        if(id==null) return null;
        id=id.trim();
        if(id.length()!=11) return null;
        return id.matches("[A-Za-z0-9_-]{11}")?id:null;
    }

    private void loadYouTube(String id){
        if(id==null)return;
        prefs.edit().putString("last_source_type","youtube").putString("last_youtube_id",id).remove("last_source_uri").apply();
        youtubeLoginMode=false; pendingYouTubeVideoId=null; if(youtubeLoginBar!=null) youtubeLoginBar.setVisibility(View.GONE);
        stopYouTubePlayback(); youtubeVideoId=id; sourceUri=null; youtubeReady=false;
        player.pause(); source.setVisibility(View.GONE); youtubeView.setVisibility(View.VISIBLE); pipEmpty.setVisibility(View.GONE); emptyCard.setVisibility(View.GONE);
        enforcePipMinimum();
        sourceStatus.setText("Loading YouTube source…"); sourceTime.setText("00:00 / --:--"); play.setText("▶");
        String html="<!doctype html><html><head><meta name=\"viewport\" content=\"width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no\"></head><body style=\"margin:0;background:#090C12;overflow:hidden\"><div id=\"player\" style=\"width:100vw;height:100vh\"></div><script>var player;function onYouTubeIframeAPIReady(){player=new YT.Player('player',{width:'100%',height:'100%',videoId:'"+id+"',playerVars:{playsinline:1,controls:0,disablekb:1,rel:0,enablejsapi:1,origin:'https://reactionrecorder.app'},events:{onReady:function(){AndroidYT.ready();},onStateChange:function(e){AndroidYT.state(e.data);},onError:function(e){AndroidYT.error(e.data);}}});}var t=document.createElement('script');t.src='https://www.youtube.com/iframe_api';document.head.appendChild(t);</script></body></html>";
        youtubeView.loadDataWithBaseURL("https://reactionrecorder.app/",html,"text/html","UTF-8",null);
        showPipInteractionChrome();
    }

    private void stopYouTubePlayback(){
        if(youtubeView==null) return;
        try {
            youtubeView.evaluateJavascript("(function(){try{if(player){player.stopVideo();}}catch(e){}})();", null);
        } catch(Exception ignored) {}
        try { youtubeView.loadUrl("about:blank"); } catch(Exception ignored) {}
        youtubeReady=false;
    }

    private void setPipRecordingVisuals(boolean active){
        if(pipContainer==null) return;
        if(active){
            // Capture composition: keep the PIP fill transparent, but preserve its configured
            // rounded outline so the video remains clipped to the chosen shape.
            GradientDrawable transparentPip=new GradientDrawable();
            transparentPip.setColor(Color.TRANSPARENT);
            transparentPip.setCornerRadius(dp(pipCornerRadiusDp));
            pipContainer.setBackground(transparentPip);
            pipContainer.setClipToOutline(pipCornerRadiusDp>0);
            if(source!=null){ source.setUseController(false); source.setShowBuffering(PlayerView.SHOW_BUFFERING_NEVER); }
            if(pipTouchShield!=null) pipTouchShield.setVisibility(View.GONE);
        } else {
            if(pipTouchShield!=null) pipTouchShield.setVisibility(View.GONE);
            if(source!=null) source.setUseController(true);
            applyPipAppearance();
        }
    }

    private void hidePipInteractionChrome(){
        if(pipContainer!=null){ pipContainer.setDragEnabled(!youtubeLoginMode || recording || recordingPreparing); pipContainer.setDoubleTapEnabled(!youtubeLoginMode || recording || recordingPreparing); pipContainer.setChildTouchBottomZonePx((recording||recordingPreparing||youtubeLoginMode||youtubeVideoId!=null)?0:dp(64)); }
        View drag=findViewById(R.id.pip_drag_hint);
        if(drag!=null) drag.setVisibility(View.GONE);
        for(int id:pipResizeHandleIds){
            View resize=findViewById(id);
            if(resize!=null){
                if(recording || recordingPreparing){
                    resize.setVisibility(View.VISIBLE);
                    resize.setAlpha(0f);
                } else {
                    resize.setVisibility(View.GONE);
                    resize.setAlpha(1f);
                }
            }
        }
        if(pipTouchShield!=null) pipTouchShield.setVisibility(View.GONE);
        if(youtubeLoginBar!=null) youtubeLoginBar.setVisibility((recording || recordingPreparing || !youtubeLoginMode)?View.GONE:View.VISIBLE);
        if(source!=null) source.setUseController(!(recording || recordingPreparing));
    }

    private void showPipInteractionChrome(){
        if(pipContainer!=null){ pipContainer.setDragEnabled(!youtubeLoginMode); pipContainer.setDoubleTapEnabled(!youtubeLoginMode); pipContainer.setChildTouchBottomZonePx(youtubeLoginMode||youtubeVideoId!=null?0:dp(64)); }
        View drag=findViewById(R.id.pip_drag_hint);
        if(drag!=null) drag.setVisibility(youtubeLoginMode?View.GONE:View.VISIBLE);
        for(int id:pipResizeHandleIds){
            View resize=findViewById(id);
            if(resize!=null){ resize.setVisibility(youtubeLoginMode?View.GONE:View.VISIBLE); resize.setAlpha(1f); }
        }
        if(pipTouchShield!=null) pipTouchShield.setVisibility(View.GONE);
        if(youtubeLoginBar!=null) youtubeLoginBar.setVisibility(youtubeLoginMode?View.VISIBLE:View.GONE);
        if(source!=null){ source.setUseController(true); source.setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING); }
    }

    private void enterImmersiveRecordingMode(){
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        WindowInsetsControllerCompat c=WindowCompat.getInsetsController(getWindow(), root);
        if(c!=null){
            c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            if(fullscreenRecording) c.hide(WindowInsetsCompat.Type.systemBars());
            else c.show(WindowInsetsCompat.Type.systemBars());
        }
    }

    private void exitImmersiveRecordingMode(){
        WindowInsetsControllerCompat c=WindowCompat.getInsetsController(getWindow(), root);
        if(c!=null) c.show(WindowInsetsCompat.Type.systemBars());
        root.postDelayed(()->ViewCompat.requestApplyInsets(root),120);
    }

    private void setupYoutubeWebView(){
        youtubeView.setVisibility(View.GONE);
        WebSettings ws=youtubeView.getSettings(); ws.setJavaScriptEnabled(true); ws.setDomStorageEnabled(true); ws.setMediaPlaybackRequiresUserGesture(false); ws.setBuiltInZoomControls(false); ws.setDisplayZoomControls(false); ws.setSupportMultipleWindows(false);
        android.webkit.CookieManager cm=android.webkit.CookieManager.getInstance(); cm.setAcceptCookie(true); if(Build.VERSION.SDK_INT>=21) cm.setAcceptThirdPartyCookies(youtubeView,true);
        youtubeView.setBackgroundColor(android.graphics.Color.rgb(9,12,18));
        youtubeView.setWebChromeClient(new WebChromeClient());
        youtubeView.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request){ return false; }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url){ return false; }
            @Override public void onPageFinished(WebView view, String url){
                if(youtubeLoginMode){
                    try { android.webkit.CookieManager.getInstance().flush(); } catch(Exception ignored) {}
                }
            }
        });
        youtubeView.addJavascriptInterface(new Object(){
            @android.webkit.JavascriptInterface public void ready(){ runOnUiThread(()->{youtubeReady=true; sourceStatus.setText("YouTube ready • tap ▶ to play");}); }
            @android.webkit.JavascriptInterface public void state(int state){ runOnUiThread(()->{ if(state==1) sourceStatus.setText("Playing YouTube source"); else if(state==2) sourceStatus.setText("YouTube source paused"); play.setText(state==1?"Ⅱ":"▶"); }); }
            @android.webkit.JavascriptInterface public void error(int code){ runOnUiThread(()->Toast.makeText(MainActivity.this,"YouTube player error: "+code,Toast.LENGTH_LONG).show()); }
        },"AndroidYT");
    }

    private int dp(float v){return Math.round(v*getResources().getDisplayMetrics().density);}
    private TextView label(String text,float size,int color){TextView t=new TextView(this);t.setText(text);t.setTextColor(color);t.setTextSize(size);t.setGravity(android.view.Gravity.CENTER_VERTICAL);return t;}
    private Button sheetButton(String text,boolean accent){Button b=new Button(this);b.setText(text);b.setTextColor(Color.WHITE);b.setTextSize(12);b.setAllCaps(false);b.setMinHeight(dp(46));b.setMinWidth(0);b.setPadding(dp(14),0,dp(14),0);b.setBackgroundResource(accent?R.drawable.button_accent:R.drawable.button_secondary);return b;}
    private LinearLayout section(String title){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(16),dp(10),dp(16),dp(6));TextView t=label(title,10,Color.parseColor("#98A1B3"));t.setTypeface(null,android.graphics.Typeface.BOLD);box.addView(t,new LinearLayout.LayoutParams(-1,dp(28)));return box;}
    private void showSheet(String title,LinearLayout content){
        if(activeSheet!=null && activeSheet.isShowing()) activeSheet.dismiss();
        Dialog dialog=new Dialog(this);dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);LinearLayout shell=new LinearLayout(this);shell.setOrientation(LinearLayout.VERTICAL);shell.setPadding(dp(18),dp(14),dp(18),dp(18));shell.setBackgroundResource(R.drawable.panel);
        TextView titleView=label(title,20,Color.WHITE);titleView.setTypeface(null,android.graphics.Typeface.BOLD);shell.addView(titleView,new LinearLayout.LayoutParams(-1,dp(42)));
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.addView(content);shell.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        Button close=sheetButton("Close",false);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(46));cp.topMargin=dp(10);shell.addView(close,cp);close.setOnClickListener(v->dialog.dismiss());
        dialog.setContentView(shell);activeSheet=dialog;android.view.Window w=dialog.getWindow();if(w!=null){w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));w.setDimAmount(.65f);w.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);w.setLayout(-1,-2);w.setGravity(android.view.Gravity.BOTTOM);}dialog.setOnDismissListener(x->{if(activeSheet==dialog)activeSheet=null;});dialog.show();if(w!=null)w.setLayout(-1,(int)(getResources().getDisplayMetrics().heightPixels*.82f));
    }
    private View settingRow(LinearLayout parent,String title,String value,View.OnClickListener click){LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.VERTICAL);row.setPadding(dp(14),dp(8),dp(14),dp(8));row.setBackgroundResource(R.drawable.button_secondary);TextView a=label(title,13,Color.WHITE);TextView b=label(value,11,Color.parseColor("#98A1B3"));row.addView(a,new LinearLayout.LayoutParams(-1,dp(26)));row.addView(b,new LinearLayout.LayoutParams(-1,dp(22)));if(click!=null)row.setOnClickListener(click);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(64));rp.bottomMargin=dp(8);parent.addView(row,rp);return row;}

    private void showCameraSettings(){
        LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);
        TextView info=label("Choose which camera to use and whether the preview should be mirrored. Compatible preview mode is used for broader Samsung/device support.",13,Color.parseColor("#98A1B3")); info.setPadding(dp(8),dp(4),dp(8),dp(12)); c.addView(info);
        Button front=sheetButton((cameraFront?"✓  ":"")+"Front camera",cameraFront); c.addView(front,new LinearLayout.LayoutParams(-1,dp(46)));
        Button back=sheetButton((!cameraFront?"✓  ":"")+"Back camera",!cameraFront); c.addView(back,new LinearLayout.LayoutParams(-1,dp(46)));
        Button mirror=sheetButton((mirrorCamera?"✓  ":"")+"Mirror preview",mirrorCamera); c.addView(mirror,new LinearLayout.LayoutParams(-1,dp(46)));
        front.setOnClickListener(v->{cameraFront=true;savePrefs();front.setText("✓  Front camera");back.setText("Back camera");startCamera();});
        back.setOnClickListener(v->{cameraFront=false;savePrefs();front.setText("Front camera");back.setText("✓  Back camera");startCamera();});
        mirror.setOnClickListener(v->{mirrorCamera=!mirrorCamera;savePrefs();mirror.setText((mirrorCamera?"✓  ":"")+"Mirror preview");startCamera();});
        TextView note=label("Camera mirroring affects the preview and the captured composition. It does not change the source-video PIP.",12,Color.parseColor("#98A1B3")); note.setPadding(dp(8),dp(12),dp(8),0); c.addView(note);
        showSheet("Camera",c);
    }

    private void showRecordingSettings(){
        LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);
        TextView info=label("App controls are always hidden while recording so they are not burned into the capture. Fullscreen mode controls whether Android system bars are hidden too.",13,Color.parseColor("#98A1B3"));info.setPadding(dp(8),dp(4),dp(8),dp(12));c.addView(info);
        Button border=sheetButton((recordingBorder?"✓  ":"")+"Recording border around camera + PIP",recordingBorder);c.addView(border,new LinearLayout.LayoutParams(-1,dp(46)));border.setOnClickListener(v->{recordingBorder=!recordingBorder;prefs.edit().putBoolean("recording_border",recordingBorder).apply();border.setText((recordingBorder?"✓  ":"")+"Recording border around camera + PIP");});
        Button full=sheetButton((fullscreenRecording?"✓  ":"")+"Fullscreen recording • hide system bars",fullscreenRecording);c.addView(full,new LinearLayout.LayoutParams(-1,dp(46)));full.setOnClickListener(v->{fullscreenRecording=!fullscreenRecording;prefs.edit().putBoolean("fullscreen_recording",fullscreenRecording).apply();full.setText((fullscreenRecording?"✓  ":"")+"Fullscreen recording • hide system bars");});
        TextView keys=label("Hardware keyboard\n\nSpace / Media Play-Pause: play or pause source\n← / A / Media Rewind: rewind\n→ / D / Media Fast Forward: forward\nP: pause or resume recording\nR / S / Media Stop: stop recording\nO: rotate portrait / landscape\n\nShortcuts work while the on-screen controls are hidden, so you can control a recording without bringing the app chrome into the captured screen.",13,Color.WHITE);keys.setPadding(dp(8),dp(12),dp(8),dp(8));c.addView(keys);
        showSheet("Recording",c);
    }

    private String queryTreeDisplayName(Uri tree){
        try{
            Uri doc=DocumentsContract.buildDocumentUriUsingTree(tree,DocumentsContract.getTreeDocumentId(tree));
            try(android.database.Cursor c=getContentResolver().query(doc,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){
                if(c!=null&&c.moveToFirst()){String n=c.getString(0);if(n!=null&&!n.trim().isEmpty())return n;}
            }
        }catch(Exception ignored){}
        return "Custom folder";
    }

    private void showStorageSettings(){
        LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);
        TextView info=label("Choose the exact folder where completed MP4 files should be saved. Android's system folder picker remembers the permission so the app can keep saving there on future recordings.\n\nCurrent folder\n"+storageDisplayName+"\n\nEstimated size\n"+estimate10Min()+" per 10 minutes at the current video bitrate.",14,Color.WHITE);info.setPadding(dp(8),dp(8),dp(8),dp(8));c.addView(info);
        Button chooseFolder=sheetButton("Choose folder…",true);c.addView(chooseFolder,new LinearLayout.LayoutParams(-1,dp(48)));chooseFolder.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION|Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);if(Build.VERSION.SDK_INT>=26&&storageTreeUri!=null){try{i.putExtra(DocumentsContract.EXTRA_INITIAL_URI,Uri.parse(storageTreeUri));}catch(Exception ignored){}}storageFolderPicker.launch(i);if(activeSheet!=null)activeSheet.dismiss();});
        Button reset=sheetButton("Reset to default • Movies / Reaction Recorder",false);c.addView(reset,new LinearLayout.LayoutParams(-1,dp(46)));reset.setOnClickListener(v->{releaseStoragePermission(storageTreeUri==null?null:Uri.parse(storageTreeUri));storageTreeUri=null;storageDisplayName="Movies / Reaction Recorder";prefs.edit().remove("storage_tree_uri").putString("storage_display_name",storageDisplayName).apply();Toast.makeText(this,"Using Movies / Reaction Recorder",Toast.LENGTH_SHORT).show();if(activeSheet!=null)activeSheet.dismiss();});
        TextView note=label("Default mode uses Android MediaStore in Movies/Reaction Recorder and is intended to appear in Gallery/Photos. A custom folder uses Android's document provider and saves directly into the folder you choose.",12,Color.parseColor("#98A1B3"));note.setPadding(dp(8),dp(12),dp(8),0);c.addView(note);
        Button size=sheetButton("View file size estimate",false);c.addView(size,new LinearLayout.LayoutParams(-1,dp(46)));size.setOnClickListener(v->showSizeInfo());
        showSheet("Storage",c);
    }

    private void showRecordingIndicatorSettings(){
        LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);
        TextView info=label("The recording indicator stays visible during recording even when the normal controls are hidden. Drag it anywhere on screen and use its invisible lower-right resize grip to change its size. Its position and size are remembered. Double-tap it to reset.",13,Color.parseColor("#98A1B3"));info.setPadding(dp(8),dp(4),dp(8),dp(12));c.addView(info);
        Button enabled=sheetButton((recordingIndicatorEnabled?"✓  ":"")+"Show tiny recording indicator",recordingIndicatorEnabled);c.addView(enabled,new LinearLayout.LayoutParams(-1,dp(46)));enabled.setOnClickListener(v->{recordingIndicatorEnabled=!recordingIndicatorEnabled;prefs.edit().putBoolean("recording_indicator_enabled",recordingIndicatorEnabled).apply();enabled.setText((recordingIndicatorEnabled?"✓  ":"")+"Show tiny recording indicator");if(!recordingIndicatorEnabled)hideRecordingIndicator();});
        Button reset=sheetButton("Reset position and size",false);c.addView(reset,new LinearLayout.LayoutParams(-1,dp(46)));reset.setOnClickListener(v->{resetRecordingIndicatorGeometry();Toast.makeText(this,"Indicator reset",Toast.LENGTH_SHORT).show();});
        showSheet("Recording indicator",c);
    }

    private void showAboutSettings(){
        LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);
        TextView info=label("Reaction Recorder\n\nVersion 12.0.0\n\nRecord your camera reaction and source video together into one MP4.\n\nRequires Android 10 or newer.\n\nSource playback uses Media3. YouTube playback uses the official YouTube IFrame player; the app does not download YouTube videos.",14,Color.WHITE);info.setPadding(dp(8),dp(8),dp(8),dp(8));c.addView(info);
        showSheet("About",c);
    }

    private void settingsDialog(){
        LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);

        LinearLayout video=section("VIDEO");content.addView(video);
        settingRow(video,"Video quality",recordingSettings.summary(),v->chooseVideoQuality());
        settingRow(video,"Resolution",recordingSettings.width+" × "+recordingSettings.height,v->chooseResolution());
        settingRow(video,"Aspect ratio",aspectRatioName(),v->chooseAspectRatio());
        settingRow(video,"Estimated file size","About "+estimate10Min()+" per 10 minutes",v->showSizeInfo());

        LinearLayout audio=section("AUDIO");content.addView(audio);
        settingRow(audio,"Microphone input",selectedInputName,v->chooseAudioInput());
        settingRow(audio,"Microphone latency compensation",micLatencyMs==0?"Off • Android timestamp alignment":micLatencyMs+" ms earlier",v->chooseMicLatency());
        settingRow(audio,"Audio synchronization","Timestamp-aligned mic + source audio with drift protection",v->showAudioInfo());

        LinearLayout playback=section("PLAYBACK");content.addView(playback);
        settingRow(playback,"Rewind / forward amount",seekSeconds+" seconds",v->chooseSeekAmount());

        LinearLayout layout=section("LAYOUT");content.addView(layout);
        settingRow(layout,"PIP layout","Position, free-range size, corners and preview",v->pipSettingsDialog());

        LinearLayout cameraSection=section("CAMERA");content.addView(cameraSection);
        settingRow(cameraSection,"Camera",(cameraFront?"Front":"Back")+" camera • "+(mirrorCamera?"Mirrored":"Normal"),v->showCameraSettings());

        LinearLayout recordingSection=section("RECORDING");content.addView(recordingSection);
        settingRow(recordingSection,"Recording behavior","Border: "+(recordingBorder?"On":"Off")+" • System bars: "+(fullscreenRecording?"Hidden":"Visible"),v->showRecordingSettings());
        settingRow(recordingSection,"Recording indicator","Tiny REC timer • movable and resizable",v->showRecordingIndicatorSettings());
        settingRow(recordingSection,"Hardware keyboard","Control playback and recording while UI is hidden",v->showRecordingSettings());

        LinearLayout storage=section("STORAGE");content.addView(storage);
        settingRow(storage,"Save location",storageDisplayName,v->showStorageSettings());
        settingRow(storage,"Space estimate",estimate10Min()+" per 10 minutes",v->showSizeInfo());

        LinearLayout appearance=section("APPEARANCE");content.addView(appearance);
        settingRow(appearance,"Appearance","Theme: "+uiTheme+" • "+(compactDock?"Compact":"Standard")+" dock",v->showAppearanceSettings());

        LinearLayout about=section("ABOUT");content.addView(about);
        settingRow(about,"Reaction Recorder","Version 12.0.0 • Android 10+",v->showAboutSettings());

        showSheet("Settings",content);
    }
    private void chooseMicLatency(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);TextView info=label("Bluetooth and USB microphones can add device-specific input delay. Android does not expose one universal latency value, so this setting lets you compensate without pretending the delay is known. 0 ms uses timestamp alignment only.",13,Color.parseColor("#98A1B3"));info.setPadding(dp(8),dp(4),dp(8),dp(12));c.addView(info);int[] vals={0,20,50,100,150,200,300,500};for(int v:vals){Button b=sheetButton((micLatencyMs==v?"✓  ":"")+(v==0?"Off (0 ms)":v+" ms earlier"),micLatencyMs==v);c.addView(b,new LinearLayout.LayoutParams(-1,dp(44)));b.setOnClickListener(x->{micLatencyMs=v;savePrefs();Toast.makeText(this,"Mic latency: "+(v==0?"off":v+" ms"),Toast.LENGTH_SHORT).show();if(activeSheet!=null)activeSheet.dismiss();});}showSheet("Microphone latency",c);}
    private void showAudioInfo(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(2),0,dp(2),0);TextView t=label("Selected input: "+selectedInputName+"\n\nThe recorder timestamps microphone and source-playback PCM on Android\'s monotonic clock instead of pairing chunks by queue position. This reduces long-recording drift and prevents one delayed input from permanently shifting the other.\n\nMicrophone latency compensation: "+(micLatencyMs==0?"Off (timestamp alignment only)":micLatencyMs+" ms earlier")+". Bluetooth latency varies by device and codec, so there is no universal Android value to assume.",14,Color.WHITE);t.setPadding(dp(8),dp(8),dp(8),dp(8));c.addView(t);showSheet("Audio synchronization",c);}
    private void pipSettingsDialog(){
        LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL);
        TextView info=label("Preview the PIP style and choose its corner shape. Eight resize handles let you freely resize from any side or corner with independent width and height.",13,Color.parseColor("#98A1B3")); info.setPadding(0,0,0,dp(10)); c.addView(info);
        FrameLayout preview=new FrameLayout(this); preview.setBackgroundColor(Color.rgb(7,9,14)); LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,dp(190)); pp.bottomMargin=dp(12); c.addView(preview,pp);
        TextView fake=new TextView(this); fake.setText("SOURCE VIDEO"); fake.setTextColor(Color.WHITE); fake.setTextSize(12); fake.setGravity(android.view.Gravity.CENTER); fake.setBackgroundColor(Color.rgb(35,43,58));
        FrameLayout.LayoutParams fp=new FrameLayout.LayoutParams(dp(150),dp(105),android.view.Gravity.CENTER); preview.addView(fake,fp); applyPreviewRadius(fake,pipCornerRadiusDp);
        TextView size=label("Current PIP: "+Math.round(pipContainer.getWidth()/getResources().getDisplayMetrics().density)+" × "+Math.round(pipContainer.getHeight()/getResources().getDisplayMetrics().density)+" dp",12,Color.WHITE); c.addView(size,new LinearLayout.LayoutParams(-1,dp(28)));
        TextView shapeLabel=label("Corner radius",12,Color.parseColor("#98A1B3")); c.addView(shapeLabel,new LinearLayout.LayoutParams(-1,dp(28)));
        float[] radii={0,4,8,12,18,24,32}; for(float r:radii){ Button b=sheetButton((Math.abs(r-pipCornerRadiusDp)<.5?"✓  ":"")+((int)r==0?"Square":((int)r+" dp")),Math.abs(r-pipCornerRadiusDp)<.5); c.addView(b,new LinearLayout.LayoutParams(-1,dp(42))); b.setOnClickListener(v->{pipCornerRadiusDp=r;applyPipAppearance();prefs.edit().putFloat("pip_corner_radius",r).apply();applyPreviewRadius(fake,r);size.setText("Current PIP: "+Math.round(pipContainer.getWidth()/getResources().getDisplayMetrics().density)+" × "+Math.round(pipContainer.getHeight()/getResources().getDisplayMetrics().density)+" dp");}); }
        Button presets=sheetButton("Reset to default size",false); c.addView(presets,new LinearLayout.LayoutParams(-1,dp(44))); presets.setOnClickListener(v->{ViewGroup.LayoutParams lp=pipContainer.getLayoutParams();lp.width=dp(240);lp.height=dp(200);pipContainer.setLayoutParams(lp);setPipTranslationClamped(pipContainer.getTranslationX(),pipContainer.getTranslationY());savePipGeometry();size.setText("Current PIP: 240 × 200 dp");});
        showSheet("PIP layout",c);
    }
    private void applyPreviewRadius(View v,float radius){GradientDrawable g=new GradientDrawable();g.setColor(Color.rgb(35,43,58));g.setStroke(dp(2),Color.parseColor("#7568FF"));g.setCornerRadius(dp(radius));v.setBackground(g);v.setClipToOutline(radius>0);}

    private void chooseSeekAmount(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);TextView info=label("Choose how far the bottom buttons jump backward and forward. The same value is used for both.",13,Color.parseColor("#98A1B3"));info.setPadding(0,0,0,dp(12));c.addView(info);int[] vals={1,3,5,10,15,30,45,60};for(int v:vals){Button b=sheetButton((v==seekSeconds?"✓  ":"")+v+" seconds",v==seekSeconds);c.addView(b,new LinearLayout.LayoutParams(-1,dp(44)));b.setOnClickListener(x->{seekSeconds=v;saveSeekSeconds();Toast.makeText(this,"Seek amount: "+seekSeconds+" seconds",Toast.LENGTH_SHORT).show();});}showSheet("Rewind / forward",c);}
    private void chooseResolution(){
        LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL);
        int[] longSides={480,720,1080,1440};
        for(int longSide:longSides){
            final int target=longSide;
            boolean selected=Math.max(recordingSettings.width,recordingSettings.height)==target;
            Button b=sheetButton((selected?"✓  ":"")+target+"p",selected);
            c.addView(b,new LinearLayout.LayoutParams(-1,dp(46)));
            b.setOnClickListener(v->{
                float ratio=recordingSettings.width/(float)Math.max(1,recordingSettings.height);
                if(Math.abs(ratio-1f)<.03f){
                    recordingSettings.width=even(target); recordingSettings.height=even(target);
                }else if(recordingSettings.width>=recordingSettings.height){
                    recordingSettings.width=even(target);
                    recordingSettings.height=even(Math.round(target/Math.max(.01f,ratio)));
                }else{
                    recordingSettings.height=even(target);
                    recordingSettings.width=even(Math.round(target*ratio));
                }
                savePrefs();
                Toast.makeText(this,"Resolution: "+recordingSettings.width+" × "+recordingSettings.height,Toast.LENGTH_SHORT).show();
                if(activeSheet!=null)activeSheet.dismiss();
            });
        }
        TextView note=label("The value sets the long edge of the encoded video while keeping your selected aspect ratio.",12,Color.parseColor("#98A1B3"));
        note.setPadding(dp(8),dp(10),dp(8),0); c.addView(note);
        showSheet("Resolution",c);
    }

    private void chooseAspectRatio(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);String[] names={"9:16 vertical","16:9 landscape","1:1 square","4:3 landscape"};float r=recordingSettings.width/(float)recordingSettings.height;int checked=Math.abs(r-9f/16f)<.03f?0:Math.abs(r-16f/9f)<.03f?1:Math.abs(r-1)<.03f?2:3;for(int i=0;i<names.length;i++){final int w=i;Button b=sheetButton((i==checked?"✓  ":"")+names[i],i==checked);c.addView(b,new LinearLayout.LayoutParams(-1,dp(46)));b.setOnClickListener(v->{int longSide=Math.max(recordingSettings.width,recordingSettings.height);if(w==0){recordingSettings.width=even(Math.round(longSide*9f/16f));recordingSettings.height=even(longSide);}else if(w==1){recordingSettings.width=even(longSide);recordingSettings.height=even(Math.round(longSide*9f/16f));}else if(w==2){recordingSettings.width=even(longSide);recordingSettings.height=even(longSide);}else{recordingSettings.width=even(longSide);recordingSettings.height=even(Math.round(longSide*3f/4f));}savePrefs();updateSeekButtonLabels();Toast.makeText(this,"Aspect ratio: "+aspectRatioName(),Toast.LENGTH_SHORT).show();if(activeSheet!=null)activeSheet.dismiss();});b.setTag(null);}showSheet("Aspect ratio",c);}
    private void chooseVideoQuality(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);String[] names={"HEVC • 1080p • 30 • 5 Mbps","HEVC • 1080p • 30 • 8 Mbps","H.264 • 1080p • 30 • 8 Mbps","HEVC • 720p • 30 • 3 Mbps","Custom"};for(int i=0;i<names.length;i++){final int w=i;Button b=sheetButton(names[i],false);c.addView(b,new LinearLayout.LayoutParams(-1,dp(46)));b.setOnClickListener(v->{if(w==0)applyPreset("HEVC",1080,30,5_000_000);else if(w==1)applyPreset("HEVC",1080,30,8_000_000);else if(w==2)applyPreset("H.264",1080,30,8_000_000);else if(w==3)applyPreset("HEVC",720,30,3_000_000);else {if(activeSheet!=null)activeSheet.dismiss();customQualityDialog();} if(w<4&&activeSheet!=null)activeSheet.dismiss();});}showSheet("Video quality",c);}
    private void applyPreset(String codec,int longSide,int fps,int bitrate){recordingSettings.codec=codec;recordingSettings.fps=fps;recordingSettings.bitrate=bitrate;boolean vert=recordingSettings.height>recordingSettings.width;float r=recordingSettings.width/(float)recordingSettings.height;if(Math.abs(r-1)<.03f){recordingSettings.width=longSide;recordingSettings.height=longSide;}else if(Math.abs(r-4f/3f)<.08f){recordingSettings.width=longSide;recordingSettings.height=Math.round(longSide*3f/4f);}else if(vert){recordingSettings.height=longSide;recordingSettings.width=Math.round(longSide*9f/16f);}else{recordingSettings.width=longSide;recordingSettings.height=Math.round(longSide*9f/16f);}recordingSettings.width=even(recordingSettings.width);recordingSettings.height=even(recordingSettings.height);savePrefs();Toast.makeText(this,"Quality: "+recordingSettings.summary()+"\nEstimated 10 min: "+estimate10Min(),Toast.LENGTH_LONG).show();}
    private void customQualityDialog(){
        final int[] draftFps={Math.max(15,Math.min(60,recordingSettings.fps))};
        final int[] draftBitrate={Math.max(1_000_000,Math.min(30_000_000,recordingSettings.bitrate))};
        final String[] draftCodec={recordingSettings.codec};
        LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);
        TextView info=label("Set frame rate, bitrate, and codec. Changes are applied only when you press Apply.",13,Color.parseColor("#98A1B3"));c.addView(info,new LinearLayout.LayoutParams(-1,dp(42)));
        EditText fps=new EditText(this);fps.setText(String.valueOf(draftFps[0]));fps.setInputType(2);fps.setHint("FPS 15–60");fps.setTextColor(Color.WHITE);fps.setHintTextColor(Color.parseColor("#98A1B3"));fps.setBackgroundResource(R.drawable.button_secondary);c.addView(fps,new LinearLayout.LayoutParams(-1,dp(52)));
        EditText mbps=new EditText(this);mbps.setText(String.valueOf(draftBitrate[0]/1_000_000));mbps.setHint("Bitrate Mbps 1–30");mbps.setInputType(2);mbps.setTextColor(Color.WHITE);mbps.setHintTextColor(Color.parseColor("#98A1B3"));mbps.setBackgroundResource(R.drawable.button_secondary);LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,dp(52));mp.topMargin=dp(8);c.addView(mbps,mp);
        String[] codecs={"HEVC (H.265)","H.264 (AVC)"};
        Button[] codecButtons=new Button[2];
        for(int i=0;i<2;i++){final int w=i;codecButtons[i]=sheetButton((draftCodec[0].equals(i==0?"HEVC":"H.264")?"✓  ":"")+codecs[i],draftCodec[0].equals(i==0?"HEVC":"H.264"));c.addView(codecButtons[i],new LinearLayout.LayoutParams(-1,dp(44)));codecButtons[i].setOnClickListener(v->{draftCodec[0]=w==0?"HEVC":"H.264";for(int j=0;j<2;j++)codecButtons[j].setText((draftCodec[0].equals(j==0?"HEVC":"H.264")?"✓  ":"")+codecs[j]);});}
        Button apply=sheetButton("Apply",true);c.addView(apply,new LinearLayout.LayoutParams(-1,dp(48)));
        apply.setOnClickListener(v->{try{int f=Math.max(15,Math.min(60,Integer.parseInt(fps.getText().toString().trim())));int mb=Integer.parseInt(mbps.getText().toString().trim());if(mb<1||mb>30)throw new IllegalArgumentException();recordingSettings.fps=f;recordingSettings.bitrate=mb*1_000_000;recordingSettings.codec=draftCodec[0];savePrefs();Toast.makeText(this,"Saved • "+recordingSettings.summary()+"\n~"+estimate10Min()+" / 10 min",Toast.LENGTH_LONG).show();if(activeSheet!=null)activeSheet.dismiss();}catch(Exception e){Toast.makeText(this,"Enter FPS 15–60 and bitrate 1–30 Mbps.",Toast.LENGTH_SHORT).show();}});
        showSheet("Custom video",c);
    }

    private static int even(int value){
        if(value<2) return 2;
        return (value % 2 == 0) ? value : value - 1;
    }

    private String aspectRatioName(){
        float r=recordingSettings.height==0?1f:recordingSettings.width/(float)recordingSettings.height;
        if(Math.abs(r-9f/16f)<.03f) return "9:16 vertical";
        if(Math.abs(r-16f/9f)<.03f) return "16:9 landscape";
        if(Math.abs(r-1f)<.03f) return "1:1 square";
        if(Math.abs(r-4f/3f)<.08f) return "4:3 landscape";
        return String.format(Locale.US,"%.2f:1",r);
    }

    private String estimate10Min(){long bytes=(long)((recordingSettings.bitrate+192_000)*600/8.0);if(bytes>=1_000_000_000L)return String.format(Locale.US,"%.2f GB",bytes/1_000_000_000d);return String.format(Locale.US,"%.0f MB",bytes/1_000_000d);}
    private void showSizeInfo(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);TextView t=label("About "+estimate10Min()+" for 10 minutes at the selected bitrate.\n\nActual size can differ slightly because MP4 overhead and audio are included. Bitrate is the main control for file size.",14,Color.WHITE);c.addView(t);showSheet("File size estimate",c);}
    private void chooseAudioInput(){AudioManager am=(AudioManager)getSystemService(Context.AUDIO_SERVICE);AudioDeviceInfo[] ds=am.getDevices(AudioManager.GET_DEVICES_INPUTS);List<AudioDeviceInfo> usable=new ArrayList<>();List<String> labels=new ArrayList<>();labels.add("Phone microphone (default)");for(AudioDeviceInfo d:ds){String n=d.getProductName()==null?"Audio input":d.getProductName().toString();labels.add(n+" — "+typeName(d.getType()));usable.add(d);}LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);for(int i=0;i<labels.size();i++){final int w=i;boolean sel=i==0?selectedInputDeviceId==null:(selectedInputDeviceId!=null&&usable.get(i-1).getId()==selectedInputDeviceId);Button b=sheetButton((sel?"✓  ":"")+labels.get(i),sel);c.addView(b,new LinearLayout.LayoutParams(-1,dp(46)));b.setOnClickListener(v->{if(w==0){selectedInputDeviceId=null;selectedInputName="Phone microphone (default)";}else{AudioDeviceInfo x=usable.get(w-1);selectedInputDeviceId=x.getId();selectedInputName=x.getProductName().toString();}savePrefs();Toast.makeText(this,"Input: "+selectedInputName,Toast.LENGTH_SHORT).show();if(activeSheet!=null)activeSheet.dismiss();});}showSheet("Microphone input",c);}
    private String typeName(int t){switch(t){case AudioDeviceInfo.TYPE_BUILTIN_MIC:return"phone mic";case AudioDeviceInfo.TYPE_BLUETOOTH_SCO:return"Bluetooth headset mic";case AudioDeviceInfo.TYPE_BLE_HEADSET:return"Bluetooth LE headset mic";case AudioDeviceInfo.TYPE_WIRED_HEADSET:return"wired headset mic";case AudioDeviceInfo.TYPE_USB_HEADSET:return"USB headset mic";default:return"input";}}

    private void startCamera(){
        cameraReady=false;
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)return;
        ProcessCameraProvider.getInstance(this).addListener(()->{try{ProcessCameraProvider p=ProcessCameraProvider.getInstance(this).get();p.unbindAll();camera.setImplementationMode(PreviewView.ImplementationMode.COMPATIBLE);
                Preview prev=new Preview.Builder().build();prev.setSurfaceProvider(camera.getSurfaceProvider());CameraSelector selector=cameraFront?CameraSelector.DEFAULT_FRONT_CAMERA:CameraSelector.DEFAULT_BACK_CAMERA; p.bindToLifecycle(this,selector,prev); camera.setScaleX(mirrorCamera?-1f:1f); cameraReady=true;}catch(Exception e){cameraReady=false;Toast.makeText(this,"Camera error: "+e.getMessage(),Toast.LENGTH_LONG).show();}},ContextCompat.getMainExecutor(this));
    }

    private void validateSelectedInputDevice(){
        if(selectedInputDeviceId==null) return;
        try{
            AudioManager am=(AudioManager)getSystemService(AUDIO_SERVICE);
            boolean found=false;
            for(AudioDeviceInfo d:am.getDevices(AudioManager.GET_DEVICES_INPUTS)){
                if(d.getId()==selectedInputDeviceId){found=true;break;}
            }
            if(!found){
                selectedInputDeviceId=null;
                selectedInputName="Phone microphone (default)";
                savePrefs();
                Toast.makeText(this,"Selected microphone is no longer connected; using phone microphone.",Toast.LENGTH_LONG).show();
            }
        }catch(Exception ignored){}
    }

    private void releaseStoragePermission(Uri uri){
        if(uri==null)return;
        try{ getContentResolver().releasePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION); }catch(Exception ignored){}
    }

    private boolean isStorageFolderWritable(){
        if(storageTreeUri==null||storageTreeUri.trim().isEmpty()) return true;
        try{
            Uri u=Uri.parse(storageTreeUri);
            DocumentsContract.getTreeDocumentId(u);
            for(android.content.UriPermission permission:getContentResolver().getPersistedUriPermissions()){
                if(permission.getUri().equals(u)&&permission.isWritePermission()) return true;
            }
        }catch(Exception ignored){}
        return false;
    }

    private void requestCapture(){if(youtubeLoginMode){Toast.makeText(this,"Finish YouTube sign-in and return to the video first.",Toast.LENGTH_LONG).show();return;}if(!hasSource()){Toast.makeText(this,"Choose a source video first.",Toast.LENGTH_LONG).show();return;}if(Build.VERSION.SDK_INT<29){Toast.makeText(this,"Android 10+ is required.",Toast.LENGTH_LONG).show();return;}if(recording||recordingPreparing)return;
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
            perms.launch(new String[]{Manifest.permission.CAMERA,Manifest.permission.RECORD_AUDIO});
            Toast.makeText(this,"Camera and microphone permission are required to record a reaction.",Toast.LENGTH_LONG).show();
            return;
        }
        if(!cameraReady){Toast.makeText(this,"Camera preview is not ready yet. Please wait a moment and try again.",Toast.LENGTH_LONG).show();return;}
        validateSelectedInputDevice();
        if(!isStorageFolderWritable()){
            releaseStoragePermission(storageTreeUri==null?null:Uri.parse(storageTreeUri)); storageTreeUri=null; storageDisplayName="Movies / Reaction Recorder";
            prefs.edit().remove("storage_tree_uri").putString("storage_display_name",storageDisplayName).apply();
            Toast.makeText(this,"The selected save folder is no longer available. Using Movies / Reaction Recorder.",Toast.LENGTH_LONG).show();
        }
        // Do not force the Activity into portrait/landscape when recording starts.
        // The user controls orientation, including while recording.
        android.media.projection.MediaProjectionManager m=(android.media.projection.MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(m.createScreenCaptureIntent(),CAPTURE);}


    @Override protected void onActivityResult(int r,int c,Intent d){
        super.onActivityResult(r,c,d);
        if(r==CAPTURE && c==RESULT_OK && d!=null){
            // Hide app/system chrome BEFORE the service creates the VirtualDisplay so the first captured frame
            // cannot contain the recording controls or system bars.
            recordingPreparing=true;
            setChromeVisible(false);
            hidePipInteractionChrome();
            setPipRecordingVisuals(true);
            enterImmersiveRecordingMode();
            final Intent s=new Intent(this,RecordingService.class);
            s.setAction(RecordingService.ACTION_START);
            s.putExtra(RecordingService.EXTRA_PROJECTION,d);
            if(selectedInputDeviceId!=null)s.putExtra(RecordingService.EXTRA_DEVICE_ID,selectedInputDeviceId);
            s.putExtra(RecordingService.EXTRA_MIC_LATENCY_MS,micLatencyMs);
            s.putExtra(RecordingService.EXTRA_WIDTH,recordingSettings.width);
            s.putExtra(RecordingService.EXTRA_HEIGHT,recordingSettings.height);
            s.putExtra(RecordingService.EXTRA_FPS,recordingSettings.fps);
            s.putExtra(RecordingService.EXTRA_BITRATE,recordingSettings.bitrate);
            s.putExtra(RecordingService.EXTRA_CODEC,recordingSettings.codec);
            if(storageTreeUri!=null && !storageTreeUri.isEmpty()) s.putExtra(RecordingService.EXTRA_STORAGE_TREE_URI,storageTreeUri);
            // Give Android one UI frame to commit the hidden chrome/immersive state before
            // the foreground service creates the VirtualDisplay.
            pendingRecordingStart=()->{
                pendingRecordingStart=null;
                if(!recordingPreparing || isFinishing()) return;
                try {
                    ContextCompat.startForegroundService(this,s);
                } catch(Throwable e){
                    recording=false; recordingPreparing=false;
                    setPipRecordingVisuals(false); showPipInteractionChrome(); setChromeVisible(true); exitImmersiveRecordingMode();
                    Toast.makeText(this,"Could not start recording: "+e.getMessage(),Toast.LENGTH_LONG).show();
                }
            };
            root.postDelayed(pendingRecordingStart,100);
        }
    }
    private void pauseRecording(){
        if(!recording || recordingPaused) return;
        sourceWasPlayingBeforeRecordingPause = isSourcePlaying();
        Intent s=new Intent(this,RecordingService.class);
        s.setAction(RecordingService.ACTION_PAUSE);
        startService(s);
        pauseRecord.setEnabled(false);
        pauseRecord.setText("…");
        recordingBadge.setText("⏸  PAUSING…");
    }

    private void requestResumeRecording(){
        if(!recording || !recordingPaused || resumeCountdownActive) return;
        pauseRecord.setEnabled(false);
        int token=++countdownToken;
        showResumeCountdown(3,token);
    }

    private void showResumeCountdown(int n,int token){
        TextView c=findViewById(R.id.resume_countdown);
        if(c!=null)c.setVisibility(View.GONE);
        resumeCountdownActive=true; resumeCountdownValue=n; updateRecordingIndicator();
        uiHandler.postDelayed(()->{
            if(token!=countdownToken || !recording || !recordingPaused){ resumeCountdownActive=false; resumeCountdownValue=0; updateRecordingIndicator(); pauseRecord.setEnabled(true); return; }
            if(n>1) showResumeCountdown(n-1,token);
            else { resumeCountdownActive=false; resumeCountdownValue=0; updateRecordingIndicator(); beginResumeRecording(); }
        },1000);
    }

    private void beginResumeRecording(){
        Intent s=new Intent(this,RecordingService.class);
        s.setAction(RecordingService.ACTION_RESUME);
        startService(s);
        pauseRecord.setEnabled(true);
    }

    private boolean isSourcePlaying(){
        if(youtubeVideoId!=null) return youtubeReady && play.getText().toString().contains("Ⅱ");
        return player!=null && player.isPlaying();
    }

    private void pauseSource(){
        if(youtubeVideoId!=null){
            if(youtubeReady) youtubeView.evaluateJavascript("(function(){if(player){player.pauseVideo();}})();",null);
        } else if(player!=null) player.pause();
    }

    private void playSource(){
        if(youtubeVideoId!=null){
            if(youtubeReady) youtubeView.evaluateJavascript("(function(){if(player){player.playVideo();}})();",null);
        } else if(player!=null) player.play();
    }

    private void stopRecording(){
        countdownToken++; resumeCountdownActive=false; resumeCountdownValue=0; TextView c=findViewById(R.id.resume_countdown); if(c!=null)c.setVisibility(View.GONE); pauseRecord.setEnabled(true);
        if(recordingPreparing && !recording){
            if(pendingRecordingStart!=null){uiHandler.removeCallbacks(pendingRecordingStart);pendingRecordingStart=null;}
            recordingPreparing=false; setPipRecordingVisuals(false); showPipInteractionChrome(); setChromeVisible(true); exitImmersiveRecordingMode(); record.setText("●");
            return;
        }
        if(!recording)return;
        Intent s=new Intent(this,RecordingService.class);s.setAction(RecordingService.ACTION_STOP);startService(s);record.setText("…"); recordingBadge.setText("●  SAVING…");
    }

    @Override protected void onDestroy(){uiHandler.removeCallbacks(progressTicker); if(recording || recordingPreparing) exitImmersiveRecordingMode();try{unregisterReceiver(recorderReceiver);}catch(Exception ignored){}if(player!=null)player.release(); if(youtubeView!=null){stopYouTubePlayback(); youtubeView.removeJavascriptInterface("AndroidYT"); youtubeView.destroy();} super.onDestroy();}
}
