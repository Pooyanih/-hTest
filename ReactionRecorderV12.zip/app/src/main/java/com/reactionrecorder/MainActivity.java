package com.reactionrecorder;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Dialog;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.media.MediaMetadataRetriever;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.MotionEvent;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ScrollView;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends ComponentActivity {
    private FrameLayout root;
    private PreviewView camera;
    private PlayerView source;
    private WebView youtubeView;
    private ExoPlayer player;
    private Button pick, youtube, play, rewind, forward, record, pauseRecord, settings, rotate;
    private PipFrameLayout pipContainer;
    private View topBar, bottomBar, recordingBadgeView;
    private View emptyCard, pipEmpty, resizeHandle;
    private TextView sourceStatus, sourceTime, recordingBadge;
    private float dragDownX, dragDownY, startTx, startTy;
    private float resizeDownX, resizeDownY;
    private int resizeStartW, resizeStartH;
    private float pipDragStartX, pipDragStartY;
    private float pipCornerRadiusDp = 18f;
    private int pipPresetIndex = 0;
    private int seekSeconds = 10;
    private static final String PREF_SEEK_SECONDS = "seek_seconds";
    private Dialog activeSheet;
    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    private final Runnable progressTicker = new Runnable() { @Override public void run() { updateSourceTime(); uiHandler.postDelayed(this, 500); } };
    private Uri sourceUri;
    private String youtubeVideoId;
    private boolean youtubeReady;
    private boolean recording;
    private boolean recordingPaused;
    private boolean sourceWasPlayingBeforeRecordingPause;
    private int countdownToken;
    private Uri finishedUri;
    private String finishedDisplayName;
    private Integer selectedInputDeviceId;
    private String selectedInputName = "Phone microphone (default)";
    private int micLatencyMs = 0;
    private String uiTheme = "Midnight";
    private boolean compactDock = false;
    private boolean autoHideControls = true;
    private boolean fullscreenRecording = false;
    private boolean recordingBorder = false;
    private final Runnable hideControlsTask = () -> { if (!recording || fullscreenRecording || autoHideControls) setChromeVisible(false); };
    private AudioVideoRecorder.RecordingSettings recordingSettings = new AudioVideoRecorder.RecordingSettings();
    private boolean recordingSceneActive = false;
    private long lastSceneTapMs = 0L;
    private android.content.SharedPreferences prefs;

    private final BroadcastReceiver recorderReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            String a=intent.getAction();
            if(RecordingService.ACTION_STARTED.equals(a)) {
                recording=true; recordingPaused=false; pauseRecord.setVisibility(View.GONE); pauseRecord.setText("Ⅱ"); record.setText("■"); recordingBadge.setVisibility(View.GONE); if(findViewById(R.id.recording_border_overlay)!=null) findViewById(R.id.recording_border_overlay).setVisibility(recordingBorder?View.VISIBLE:View.GONE); if(findViewById(R.id.pip_record_border)!=null) findViewById(R.id.pip_record_border).setVisibility(recordingBorder?View.VISIBLE:View.GONE); enterRecordingScene(); Toast.makeText(MainActivity.this,"Recording started",Toast.LENGTH_SHORT).show();
            } else if(RecordingService.ACTION_PAUSED.equals(a)) {
                recordingPaused=true; pauseRecord.setText("▶"); recordingBadge.setText("⏸  PAUSED"); sourceStatus.setText("Recording paused"); pauseSource();
            } else if(RecordingService.ACTION_RESUMED.equals(a)) {
                recordingPaused=false; pauseRecord.setText("Ⅱ"); recordingBadge.setText("●  RECORDING"); if(sourceWasPlayingBeforeRecordingPause) playSource();
            } else if(RecordingService.ACTION_FINISHED.equals(a)) {
                recording=false; recordingPaused=false; pauseRecord.setVisibility(View.GONE);
 record.setText("●"); recordingBadge.setVisibility(View.GONE); if(findViewById(R.id.recording_border_overlay)!=null) findViewById(R.id.recording_border_overlay).setVisibility(View.GONE); if(findViewById(R.id.pip_record_border)!=null) findViewById(R.id.pip_record_border).setVisibility(View.GONE); exitRecordingScene(); RecordingSceneController.stopFramePump(); String s=intent.getStringExtra(RecordingService.EXTRA_URI);
                if(s!=null) {
                    finishedUri=Uri.parse(s);
                    finishedDisplayName=queryDisplayName(finishedUri);
                    showRecordingComplete(finishedUri);
                } else {
                    Toast.makeText(MainActivity.this,"Recording saved",Toast.LENGTH_LONG).show();
                }
            } else if(RecordingService.ACTION_FAILED.equals(a)) {
                recording=false; recordingPaused=false; pauseRecord.setVisibility(View.GONE); countdownToken++;
 record.setText("●"); recordingBadge.setVisibility(View.GONE); if(findViewById(R.id.recording_border_overlay)!=null) findViewById(R.id.recording_border_overlay).setVisibility(View.GONE); if(findViewById(R.id.pip_record_border)!=null) findViewById(R.id.pip_record_border).setVisibility(View.GONE); exitRecordingScene(); RecordingSceneController.stopFramePump(); if(sourceWasPlayingBeforeRecordingPause) playSource(); Toast.makeText(MainActivity.this,"Recording failed: "+intent.getStringExtra(RecordingService.EXTRA_ERROR),Toast.LENGTH_LONG).show();
            }
        }
    };

    private String queryDisplayName(Uri uri){
        try(android.database.Cursor c=getContentResolver().query(uri,new String[]{android.provider.MediaStore.MediaColumns.DISPLAY_NAME},null,null,null)){
            if(c!=null && c.moveToFirst()) return c.getString(0);
        }catch(Exception ignored){}
        String p=uri.getLastPathSegment();
        return p==null?"Reaction recording.mp4":p;
    }

    private Bitmap loadVideoThumbnail(Uri uri){
        MediaMetadataRetriever r=new MediaMetadataRetriever();
        try{
            r.setDataSource(this,uri);
            return r.getFrameAtTime(500_000,MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
        }catch(Exception ignored){return null;}
        finally{try{r.release();}catch(Exception ignored){}}
    }

    private void showRecordingComplete(Uri uri){
        LinearLayout content=new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16),dp(4),dp(16),dp(4));

        ImageView thumb=new ImageView(this);
        thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
        thumb.setBackgroundResource(R.drawable.card);
        Bitmap b=loadVideoThumbnail(uri);
        if(b!=null) thumb.setImageBitmap(b);
        else { thumb.setImageResource(android.R.drawable.ic_media_play); thumb.setColorFilter(Color.WHITE); }
        content.addView(thumb,new LinearLayout.LayoutParams(-1,dp(190)));

        TextView status=label("Recording complete",20,Color.WHITE);
        status.setTypeface(null,android.graphics.Typeface.BOLD);
        status.setPadding(dp(2),dp(14),dp(2),dp(2));
        content.addView(status,new LinearLayout.LayoutParams(-1,dp(40)));

        TextView name=label(finishedDisplayName==null?"Reaction recording.mp4":finishedDisplayName,12,Color.parseColor("#98A1B3"));
        name.setPadding(dp(2),0,dp(2),dp(10));
        content.addView(name,new LinearLayout.LayoutParams(-1,dp(30)));

        Button preview=sheetButton("▶  Preview",true); content.addView(preview,new LinearLayout.LayoutParams(-1,dp(48)));
        preview.setOnClickListener(v->openVideo(uri));
        Button rename=sheetButton("✏  Rename",false); content.addView(rename,new LinearLayout.LayoutParams(-1,dp(46)));
        rename.setOnClickListener(v->renameFinishedVideo(uri,name));
        Button share=sheetButton("📤  Share",false); content.addView(share,new LinearLayout.LayoutParams(-1,dp(46)));
        share.setOnClickListener(v->shareVideo(uri));
        Button gallery=sheetButton("📁  Open in Gallery",false); content.addView(gallery,new LinearLayout.LayoutParams(-1,dp(46)));
        gallery.setOnClickListener(v->openVideo(uri));
        Button save=sheetButton("Save",true); content.addView(save,new LinearLayout.LayoutParams(-1,dp(48)));
        save.setOnClickListener(v->{ if(activeSheet!=null) activeSheet.dismiss(); Toast.makeText(this,"Saved to Movies / Reaction Recorder",Toast.LENGTH_SHORT).show(); });
        Button delete=sheetButton("🗑  Delete",false); content.addView(delete,new LinearLayout.LayoutParams(-1,dp(46)));
        delete.setOnClickListener(v->deleteFinishedVideo(uri));
        showSheet("Recording complete",content);
    }

    private void openVideo(Uri uri){
        try{
            Intent i=new Intent(Intent.ACTION_VIEW,uri); i.setDataAndType(uri,"video/mp4"); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); startActivity(i);
        }catch(Exception e){Toast.makeText(this,"No video app is available",Toast.LENGTH_SHORT).show();}
    }

    private void shareVideo(Uri uri){
        Intent i=new Intent(Intent.ACTION_SEND); i.setType("video/mp4"); i.putExtra(Intent.EXTRA_STREAM,uri); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); startActivity(Intent.createChooser(i,"Share recording"));
    }

    private void renameFinishedVideo(Uri uri,TextView nameView){
        EditText input=new EditText(this);
        input.setSingleLine(true); input.setText(finishedDisplayName==null?"Reaction recording":finishedDisplayName.replaceFirst("\\.mp4$",""));
        input.setSelectAllOnFocus(true); input.setTextColor(Color.WHITE); input.setHintTextColor(Color.parseColor("#98A1B3")); input.setBackgroundResource(R.drawable.button_secondary);
        LinearLayout box=new LinearLayout(this); box.setPadding(dp(20),0,dp(20),0); box.addView(input,new LinearLayout.LayoutParams(-1,dp(52)));
        new AlertDialog.Builder(this).setTitle("Rename recording").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{
            String n=input.getText().toString().trim(); if(n.isEmpty()) return;
            if(!n.toLowerCase(Locale.US).endsWith(".mp4")) n+=".mp4";
            try{
                android.content.ContentValues cv=new android.content.ContentValues(); cv.put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME,n);
                int changed=getContentResolver().update(uri,cv,null,null);
                if(changed>0){finishedDisplayName=n;nameView.setText(n);Toast.makeText(this,"Renamed",Toast.LENGTH_SHORT).show();}
                else Toast.makeText(this,"Could not rename this recording",Toast.LENGTH_SHORT).show();
            }catch(Exception e){Toast.makeText(this,"Could not rename this recording",Toast.LENGTH_SHORT).show();}
        }).show();
    }

    private void deleteFinishedVideo(Uri uri){
        new AlertDialog.Builder(this).setTitle("Delete recording?").setMessage(finishedDisplayName==null?"This recording will be removed from the Gallery.":finishedDisplayName).setNegativeButton("Cancel",null).setPositiveButton("Delete",(d,w)->{
            try{
                int deleted=getContentResolver().delete(uri,null,null);
                if(deleted>0){
                    if(activeSheet!=null) activeSheet.dismiss();
                    finishedUri=null; finishedDisplayName=null;
                    Toast.makeText(this,"Recording deleted",Toast.LENGTH_SHORT).show();
                } else Toast.makeText(this,"Could not delete the recording",Toast.LENGTH_SHORT).show();
            }catch(Exception e){Toast.makeText(this,"Could not delete the recording",Toast.LENGTH_SHORT).show();}
        }).show();
    }

    private final ActivityResultLauncher<String[]> perms=registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(),r->startCamera());
    private final ActivityResultLauncher<Intent> picker=registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),r->{
        if(r.getResultCode()==RESULT_OK&&r.getData()!=null){sourceUri=r.getData().getData();try{getContentResolver().takePersistableUriPermission(sourceUri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}loadSource(sourceUri);}
    });

    @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(com.reactionrecorder.R.layout.activity_main);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        root=findViewById(R.id.root);camera=findViewById(R.id.camera);source=findViewById(R.id.source);youtubeView=findViewById(R.id.youtube_view);pick=findViewById(R.id.pick);youtube=findViewById(R.id.youtube);play=findViewById(R.id.play);rewind=findViewById(R.id.rewind);forward=findViewById(R.id.forward);record=findViewById(R.id.record);pauseRecord=findViewById(R.id.pause_record);settings=findViewById(R.id.settings);rotate=findViewById(R.id.rotate);pipContainer=findViewById(R.id.pip_container);topBar=findViewById(R.id.top);bottomBar=findViewById(R.id.bottom);recordingBadgeView=findViewById(R.id.recording_badge);emptyCard=findViewById(R.id.empty_card);pipEmpty=findViewById(R.id.pip_empty);sourceStatus=findViewById(R.id.source_status);sourceTime=findViewById(R.id.source_time);recordingBadge=findViewById(R.id.recording_badge);resizeHandle=findViewById(R.id.pip_resize_hint);
        prefs=getSharedPreferences("recorder",MODE_PRIVATE);loadPrefs();
        loadAppearancePrefs();
        applyPipAppearance();
        restorePipGeometry();
        updateSeekButtonLabels();
        player=new ExoPlayer.Builder(this).setAudioAttributes(new AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).setAllowedCapturePolicy(android.media.AudioAttributes.ALLOW_CAPTURE_BY_ALL).build(),true).build();source.setPlayer(player);
        setupYoutubeWebView();
        if(Build.VERSION.SDK_INT>=29){try{((AudioManager)getSystemService(AUDIO_SERVICE)).setAllowedCapturePolicy(android.media.AudioAttributes.ALLOW_CAPTURE_BY_ALL);}catch(Exception ignored){}}
        pick.setOnClickListener(v->choose()); youtube.setOnClickListener(v->youtubeDialog()); play.setOnClickListener(v->toggleSource()); rewind.setOnClickListener(v->seekSource(-seekSeconds)); forward.setOnClickListener(v->seekSource(seekSeconds)); record.setOnClickListener(v->{if(!recording)requestCapture();else stopRecording();}); pauseRecord.setOnClickListener(v->{if(recording&&!recordingPaused)pauseRecording();else if(recording&&recordingPaused)requestResumeRecording();}); settings.setOnClickListener(v->settingsDialog()); rotate.setOnClickListener(v->toggleOrientation());
        applySystemBarInsets();
        setupPipDragging();
        setupPipResize();
        pipContainer.bringToFront();
        applyAppearanceTheme();
        setupAutoHide();
        uiHandler.post(progressTicker);
        player.addListener(new androidx.media3.common.Player.Listener(){ @Override public void onIsPlayingChanged(boolean isPlaying){ play.setText(isPlaying ? "Ⅱ" : "▶"); sourceStatus.setText(isPlaying ? "Playing source" : "Source paused"); } @Override public void onPlaybackStateChanged(int state){ updateSourceTime(); }});
        IntentFilter f=new IntentFilter();f.addAction(RecordingService.ACTION_STARTED);f.addAction(RecordingService.ACTION_PAUSED);f.addAction(RecordingService.ACTION_RESUMED);f.addAction(RecordingService.ACTION_FINISHED);f.addAction(RecordingService.ACTION_FAILED);ContextCompat.registerReceiver(this,recorderReceiver,f,ContextCompat.RECEIVER_NOT_EXPORTED);
        perms.launch(new String[]{Manifest.permission.CAMERA,Manifest.permission.RECORD_AUDIO});
    }

    private void loadAppearancePrefs(){
        uiTheme=prefs.getString("ui_theme","Midnight");
        compactDock=prefs.getBoolean("compact_dock",false);
        autoHideControls=prefs.getBoolean("auto_hide_controls",true);
        fullscreenRecording=prefs.getBoolean("fullscreen_recording",false);
        recordingBorder=prefs.getBoolean("recording_border",false);
    }

    private void applyAppearanceTheme(){
        int accent=Color.parseColor("#7568FF"), accentPressed=Color.parseColor("#6256E8"), bg=Color.parseColor("#080B12");
        if("Ocean".equals(uiTheme)){accent=Color.parseColor("#38BDF8");accentPressed=Color.parseColor("#0284C7");bg=Color.parseColor("#07131A");}
        else if("Emerald".equals(uiTheme)){accent=Color.parseColor("#34D399");accentPressed=Color.parseColor("#059669");bg=Color.parseColor("#06120E");}
        else if("Sunset".equals(uiTheme)){accent=Color.parseColor("#FB7185");accentPressed=Color.parseColor("#E11D48");bg=Color.parseColor("#160A0E");}
        root.setBackgroundColor(bg);
        for(View v:new View[]{pick,youtube,play,rewind,forward,settings,rotate}) if(v!=null) v.setBackgroundTintList(android.content.res.ColorStateList.valueOf(v==pick?accent:Color.parseColor("#181F2D")));
        if(record!=null) record.setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent));
        for(View v:new View[]{topBar,bottomBar,emptyCard}) if(v!=null) v.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.argb(225,18,24,34)));
        applyPipAppearance();
        updateDockSize();
    }

    private void updateDockSize(){
        if(bottomBar==null)return;
        bottomBar.setAlpha(compactDock ? .88f : 1f);
        View dock=bottomBar instanceof ViewGroup ? ((ViewGroup)bottomBar).getChildAt(0) : null;
        if(dock!=null){ ViewGroup.LayoutParams lp=dock.getLayoutParams(); lp.height=dp(compactDock?48:56); dock.setLayoutParams(lp); }
    }

    private void setupAutoHide(){
        root.setOnTouchListener((v,e)->{
            if(e.getAction()==MotionEvent.ACTION_DOWN){
                if(!recordingSceneActive){ setChromeVisible(true); scheduleHideControls(); }
                else {
                    long now=System.currentTimeMillis();
                    if(now-lastSceneTapMs<350){ stopRecording(); lastSceneTapMs=0; } else lastSceneTapMs=now;
                }
            }
            return false;
        });
        View.OnTouchListener touch=(v,e)->{ if(e.getAction()==MotionEvent.ACTION_DOWN) {setChromeVisible(true); scheduleHideControls();} return false; };
        for(View v:new View[]{topBar,bottomBar,pipContainer,recordingBadgeView}) if(v!=null) v.setOnTouchListener(touch);
        scheduleHideControls();
    }

    private void scheduleHideControls(){
        uiHandler.removeCallbacks(hideControlsTask);
        if(!autoHideControls && !fullscreenRecording)return;
        uiHandler.postDelayed(hideControlsTask,3500);
    }

    private void setChromeVisible(boolean visible){
        if(topBar!=null) topBar.setVisibility(visible?View.VISIBLE:View.GONE);
        if(bottomBar!=null) bottomBar.setVisibility(visible?View.VISIBLE:View.GONE);
        if(recordingBadgeView!=null) recordingBadgeView.setVisibility(visible && recording && !fullscreenRecording ? View.VISIBLE : View.GONE);
        if(pipContainer!=null) pipContainer.bringToFront();
        if(visible) scheduleHideControls();
    }

    private void showAppearanceSettings(){
        LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL);
        TextView preview=label("LIVE PREVIEW",10,Color.parseColor("#98A1B3")); preview.setTypeface(null,android.graphics.Typeface.BOLD); c.addView(preview,new LinearLayout.LayoutParams(-1,dp(28)));
        LinearLayout previewBox=new LinearLayout(this); previewBox.setGravity(android.view.Gravity.CENTER); previewBox.setPadding(dp(12),dp(12),dp(12),dp(12)); previewBox.setBackgroundResource(R.drawable.panel);
        TextView sample=label("  ●  Reaction Recorder     ⚙   \n\n          CAMERA PREVIEW\n\n     ─── control dock ───",13,Color.WHITE); sample.setGravity(android.view.Gravity.CENTER); previewBox.addView(sample,new LinearLayout.LayoutParams(-1,dp(150))); c.addView(previewBox,new LinearLayout.LayoutParams(-1,dp(170)));
        String[] themes={"Midnight","Ocean","Emerald","Sunset"}; for(String t:themes){Button b=sheetButton((t.equals(uiTheme)?"✓  ":"")+t,t.equals(uiTheme)); c.addView(b,new LinearLayout.LayoutParams(-1,dp(46))); b.setOnClickListener(v->{uiTheme=t;prefs.edit().putString("ui_theme",t).apply();applyAppearanceTheme();showAppearanceSettings();if(activeSheet!=null)activeSheet.dismiss();});}
        Button compact=sheetButton((compactDock?"✓  ":"")+"Transparent / compact control dock",compactDock);c.addView(compact,new LinearLayout.LayoutParams(-1,dp(46)));compact.setOnClickListener(v->{compactDock=!compactDock;prefs.edit().putBoolean("compact_dock",compactDock).apply();applyAppearanceTheme();});
        Button auto=sheetButton((autoHideControls?"✓  ":"")+"Auto-hide controls after 3 seconds",autoHideControls);c.addView(auto,new LinearLayout.LayoutParams(-1,dp(46)));auto.setOnClickListener(v->{autoHideControls=!autoHideControls;prefs.edit().putBoolean("auto_hide_controls",autoHideControls).apply();if(!autoHideControls)setChromeVisible(true);else scheduleHideControls();});
        Button full=sheetButton((fullscreenRecording?"✓  ":"")+"Fullscreen recording mode",fullscreenRecording);c.addView(full,new LinearLayout.LayoutParams(-1,dp(46)));full.setOnClickListener(v->{fullscreenRecording=!fullscreenRecording;prefs.edit().putBoolean("fullscreen_recording",fullscreenRecording).apply();});
        Button border=sheetButton((recordingBorder?"✓  ":"")+"Recording border around camera + PIP",recordingBorder);c.addView(border,new LinearLayout.LayoutParams(-1,dp(46)));border.setOnClickListener(v->{recordingBorder=!recordingBorder;prefs.edit().putBoolean("recording_border",recordingBorder).apply();});
        showSheet("Appearance",c);
    }

    private void applySystemBarInsets(){
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets bars=insets.getInsets(WindowInsetsCompat.Type.systemBars());
            ViewGroup.MarginLayoutParams topLp=(ViewGroup.MarginLayoutParams)topBar.getLayoutParams();
            topLp.topMargin=bars.top+dp(8);
            topBar.setLayoutParams(topLp);

            ViewGroup.MarginLayoutParams bottomLp=(ViewGroup.MarginLayoutParams)bottomBar.getLayoutParams();
            bottomLp.bottomMargin=bars.bottom+dp(8);
            bottomBar.setLayoutParams(bottomLp);

            ViewGroup.MarginLayoutParams pipLp=(ViewGroup.MarginLayoutParams)pipContainer.getLayoutParams();
            pipLp.topMargin=bars.top+dp(66);
            pipLp.bottomMargin=bars.bottom+dp(8);
            pipContainer.setLayoutParams(pipLp);

            ViewGroup.MarginLayoutParams badgeLp=(ViewGroup.MarginLayoutParams)recordingBadgeView.getLayoutParams();
            badgeLp.topMargin=bars.top+dp(66);
            recordingBadgeView.setLayoutParams(badgeLp);
            root.post(()->{restorePipGeometry();clampPipToScreen();});
            return insets;
        });
        ViewCompat.requestApplyInsets(root);
    }

    private void toggleOrientation(){
        if(recording){
            Toast.makeText(this,"Stop recording before rotating the app.",Toast.LENGTH_SHORT).show();
            return;
        }
        int current=getResources().getConfiguration().orientation;
        setRequestedOrientation(current==android.content.res.Configuration.ORIENTATION_LANDSCAPE
                ? ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                : ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
    }

    private void loadPrefs(){recordingSettings.codec=prefs.getString("codec","HEVC");recordingSettings.width=prefs.getInt("width",1080);recordingSettings.height=prefs.getInt("height",1920);recordingSettings.fps=prefs.getInt("fps",30);recordingSettings.bitrate=prefs.getInt("bitrate",5_000_000);seekSeconds=Math.max(1,Math.min(60,prefs.getInt(PREF_SEEK_SECONDS,10)));micLatencyMs=Math.max(0,Math.min(500,prefs.getInt("mic_latency_ms",0)));selectedInputName=prefs.getString("input_name","Phone microphone (default)");selectedInputDeviceId=prefs.getInt("input_device_id",-1)>=0?prefs.getInt("input_device_id",-1):null;pipCornerRadiusDp=Math.max(0,Math.min(40,prefs.getFloat("pip_corner_radius",18f)));pipPresetIndex=Math.max(0,prefs.getInt("pip_preset",0));}
    private void saveSeekSeconds(){seekSeconds=Math.max(1,Math.min(60,seekSeconds));prefs.edit().putInt(PREF_SEEK_SECONDS,seekSeconds).apply();updateSeekButtonLabels();}
    private void updateSeekButtonLabels(){if(rewind!=null)rewind.setText("−"+seekSeconds);if(forward!=null)forward.setText("+"+seekSeconds);}
    private void savePrefs(){prefs.edit().putString("input_name",selectedInputName).putInt("input_device_id",selectedInputDeviceId==null?-1:selectedInputDeviceId).putInt("mic_latency_ms",micLatencyMs).putString("codec",recordingSettings.codec).putInt("width",recordingSettings.width).putInt("height",recordingSettings.height).putInt("fps",recordingSettings.fps).putInt("bitrate",recordingSettings.bitrate).apply();}

    private void choose(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("video/*");i.addCategory(Intent.CATEGORY_OPENABLE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);picker.launch(i);}
    private void loadSource(Uri u){
        pipContainer.setInteractiveContent(false);
        pipContainer.bringToFront();
        stopYouTubePlayback(); youtubeVideoId=null; youtubeReady=false; youtubeView.setVisibility(View.GONE); source.setVisibility(View.VISIBLE); pipEmpty.setVisibility(View.GONE);
        player.setMediaItem(MediaItem.fromUri(u));
        player.prepare();
        player.pause();
        player.seekTo(0);
        play.setText("▶");
        emptyCard.setVisibility(View.GONE);
        sourceStatus.setText("Source ready • tap ▶ to play");
        sourceTime.setText("00:00 / --:--");
    }
    private boolean hasSource(){ return sourceUri!=null || youtubeVideoId!=null; }

    private void toggleSource(){
        if(!hasSource()){ choose(); return; }
        if(youtubeVideoId!=null){
            if(!youtubeReady) return;
            youtubeView.evaluateJavascript("(function(){ if(player && player.getPlayerState()===1){player.pauseVideo();}else if(player){player.playVideo();} })();", null);
        } else if(player.isPlaying()) player.pause(); else player.play();
    }

    private void seekSource(int seconds){
        if(seconds==0)return;
        if(youtubeVideoId!=null){
            if(!youtubeReady)return;
            String js="(function(){try{var p=window.player;if(!p||typeof p.getCurrentTime!==\"function\")return;var t=Number(p.getCurrentTime())||0;var d=Number(p.getDuration())||0;var n=Math.max(0,t+("+seconds+"));if(d>0)n=Math.min(d,n);p.seekTo(n,true);}catch(e){}})();";
            youtubeView.evaluateJavascript(js,null);
        } else if(player!=null){
            long target=Math.max(0,player.getCurrentPosition()+seconds*1000L);
            long duration=player.getDuration();
            if(duration>0)target=Math.min(duration,target);
            player.seekTo(target);
        }
    }

    private void updateSourceTime(){
        if(player==null || sourceTime==null) return;
        if(youtubeVideoId!=null){
            if(!youtubeReady) return;
            youtubeView.evaluateJavascript("(function(){return JSON.stringify({p:player?player.getCurrentTime():0,d:player?player.getDuration():0,s:player?player.getPlayerState():-1});})()", value -> {
                try {
                    String v=value==null?"":value.replace("\\\"","\"").replace("\"{", "{").replace("}\"", "}");
                    org.json.JSONObject o=new org.json.JSONObject(v);
                    long pos=(long)(o.optDouble("p",0)*1000); long dur=(long)(o.optDouble("d",0)*1000);
                    sourceTime.setText(formatTime(pos)+" / "+(dur>0?formatTime(dur):"--:--"));
                    int state=o.optInt("s",-1); play.setText(state==1?"Ⅱ":"▶");
                    sourceStatus.setText(state==1?"Playing YouTube source":"YouTube source paused");
                } catch(Exception ignored) {}
            });
            return;
        }
        long pos=Math.max(0,player.getCurrentPosition()); long dur=player.getDuration();
        sourceTime.setText(formatTime(pos)+" / "+(dur>0?formatTime(dur):"--:--"));
        if(recording && recordingBadge!=null){ long t=System.currentTimeMillis(); sourceTime.invalidate(); }
    }

    private String formatTime(long ms){ long total=ms/1000; return String.format(Locale.US,"%02d:%02d",total/60,total%60); }

    private void setupPipDragging(){
        pipContainer.setInteractiveContent(youtubeVideoId != null);
        pipContainer.setListener(new PipFrameLayout.Listener(){
            @Override public void onPipDragStart(float rawX,float rawY){
                pipDragStartX=rawX; pipDragStartY=rawY;
                startTx=pipContainer.getTranslationX(); startTy=pipContainer.getTranslationY();
            }
            @Override public void onPipDragMove(float rawX,float rawY){
                float nx=startTx+(rawX-pipDragStartX), ny=startTy+(rawY-pipDragStartY);
                setPipTranslationFree(nx,ny);
            }
            @Override public void onPipDragEnd(){savePipGeometry();}
            @Override public void onPipDoubleTap(){cyclePipPreset();}
        });
    }

    private void setupPipResize(){
        resizeHandle.setOnTouchListener((v,e)->{
            switch(e.getActionMasked()){
                case MotionEvent.ACTION_DOWN:
                    resizeDownX=e.getRawX(); resizeDownY=e.getRawY();
                    resizeStartW=pipContainer.getWidth(); resizeStartH=pipContainer.getHeight();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    int minW=dp(140), minH=dp(100);
                    int[] bounds=getPipFreeBounds();
                    int maxW=Math.max(minW,root.getWidth());
                    int maxH=Math.max(minH,root.getHeight());
                    int nw=Math.max(minW,Math.min(maxW,resizeStartW+Math.round(e.getRawX()-resizeDownX)));
                    int nh=Math.max(minH,Math.min(maxH,resizeStartH+Math.round(e.getRawY()-resizeDownY)));
                    ViewGroup.LayoutParams lp=pipContainer.getLayoutParams(); lp.width=nw; lp.height=nh; pipContainer.setLayoutParams(lp);
                    clampPipToScreen();
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    savePipGeometry(); v.performClick(); return true;
                default:return true;
            }
        });
    }

    private int[] getPipFreeBounds(){
        if(root==null) return new int[]{0,0,1,1};
        return new int[]{0,0,Math.max(1,root.getWidth()),Math.max(1,root.getHeight())};
    }

    private void setPipTranslationFree(float tx,float ty){
        if(root==null||pipContainer==null||root.getWidth()<=0||root.getHeight()<=0)return;
        float baseLeft=pipContainer.getLeft(), baseTop=pipContainer.getTop();
        float minX=-baseLeft;
        float maxX=root.getWidth()-pipContainer.getWidth()-baseLeft;
        float minY=-baseTop;
        float maxY=root.getHeight()-pipContainer.getHeight()-baseTop;
        if(maxX<minX) maxX=minX;
        if(maxY<minY) maxY=minY;
        pipContainer.setTranslationX(Math.max(minX,Math.min(tx,maxX)));
        pipContainer.setTranslationY(Math.max(minY,Math.min(ty,maxY)));
    }

    private void clampPipToScreen(){setPipTranslationFree(pipContainer.getTranslationX(),pipContainer.getTranslationY());}

    private void cyclePipPreset(){
        int[] b=getPipFreeBounds(); int[] widths={Math.round(b[2]*.28f),Math.round(b[2]*.38f),Math.round(b[2]*.50f),Math.round(b[2]*.62f)};
        pipPresetIndex=(pipPresetIndex+1)%widths.length;
        int nw=Math.max(dp(140),Math.min(b[2],widths[pipPresetIndex])); int nh=Math.max(dp(100),Math.min(b[3],Math.round(nw*(pipContainer.getHeight()/(float)Math.max(1,pipContainer.getWidth())))));
        float cx=pipContainer.getLeft()+pipContainer.getTranslationX()+pipContainer.getWidth()/2f;
        float cy=pipContainer.getTop()+pipContainer.getTranslationY()+pipContainer.getHeight()/2f;
        ViewGroup.LayoutParams lp=pipContainer.getLayoutParams();lp.width=nw;lp.height=nh;pipContainer.setLayoutParams(lp);
        float tx=cx-(pipContainer.getLeft()+nw/2f),ty=cy-(pipContainer.getTop()+nh/2f);setPipTranslationFree(tx,ty);
        prefs.edit().putInt("pip_preset",pipPresetIndex).apply();
        savePipGeometry();
    }

    private void restorePipGeometry(){
        if(pipContainer==null)return;
        root.post(()->{
            int w=prefs.getInt("pip_width_dp",240), h=prefs.getInt("pip_height_dp",200);
            ViewGroup.LayoutParams lp=pipContainer.getLayoutParams();lp.width=Math.max(dp(140),Math.min(dp(w),Math.max(dp(140),root.getWidth())));lp.height=Math.max(dp(100),Math.min(dp(h),Math.max(dp(100),root.getHeight())));pipContainer.setLayoutParams(lp);
            float xr=prefs.getFloat("pip_x_ratio",1f), yr=prefs.getFloat("pip_y_ratio",0f);
            float maxX=Math.max(0,root.getWidth()-pipContainer.getWidth()),maxY=Math.max(0,root.getHeight()-pipContainer.getHeight());
            setPipTranslationFree(-pipContainer.getLeft()+maxX*Math.max(0,Math.min(1,xr)),-pipContainer.getTop()+maxY*Math.max(0,Math.min(1,yr)));
            pipContainer.bringToFront();
        });
    }

    private void savePipGeometry(){
        if(pipContainer==null||root==null||root.getWidth()<=0)return;
        float maxX=Math.max(1,root.getWidth()-pipContainer.getWidth()),maxY=Math.max(1,root.getHeight()-pipContainer.getHeight());
        float x=(pipContainer.getTranslationX()+pipContainer.getLeft())/maxX, y=(pipContainer.getTranslationY()+pipContainer.getTop())/maxY;
        prefs.edit().putInt("pip_width_dp",Math.round(pipContainer.getWidth()/getResources().getDisplayMetrics().density)).putInt("pip_height_dp",Math.round(pipContainer.getHeight()/getResources().getDisplayMetrics().density)).putFloat("pip_x_ratio",Math.max(0,Math.min(1,x))).putFloat("pip_y_ratio",Math.max(0,Math.min(1,y))).putFloat("pip_corner_radius",pipCornerRadiusDp).apply();
    }

    private void applyPipAppearance(){
        if(pipContainer==null)return;
        GradientDrawable g=new GradientDrawable(); g.setColor(Color.rgb(9,12,18)); g.setStroke(dp(2),Color.parseColor("#7568FF")); g.setCornerRadius(dp(pipCornerRadiusDp));
        pipContainer.setBackground(g); pipContainer.setClipToOutline(pipCornerRadiusDp>0);
    }

    private void youtubeDialog(){
        EditText e=new EditText(this);
        e.setHint("https://www.youtube.com/watch?v=...");
        new AlertDialog.Builder(this)
                .setTitle("YouTube source")
                .setMessage("Paste a YouTube video link. It will play inside the reaction recorder; the app does not download the YouTube video.")
                .setView(e)
                .setNegativeButton("Cancel",null)
                .setPositiveButton("Load in app",(d,w)->{
                    String id=extractYouTubeId(e.getText().toString().trim());
                    if(id==null) Toast.makeText(this,"That doesn't look like a supported YouTube video link.",Toast.LENGTH_LONG).show();
                    else loadYouTube(id);
                }).show();
    }

    private String extractYouTubeId(String raw){
        if(raw==null||raw.isEmpty()) return null;
        try{
            String s=raw.trim();
            if(!s.matches("https?://.*")) return null;
            Uri u=Uri.parse(s);
            String host=u.getHost()==null?"":u.getHost().toLowerCase(Locale.US);
            if(host.equals("youtu.be")){ String p=u.getPath(); return cleanYouTubeId(p==null?null:p.substring(p.startsWith("/")?1:0)); }
            if(host.equals("youtube.com")||host.endsWith(".youtube.com")){
                String v=u.getQueryParameter("v");
                if(v!=null) return cleanYouTubeId(v);
                String p=u.getPath();
                if(p!=null){
                    String[] a=p.split("/");
                    if(a.length>=3 && ("shorts".equals(a[1])||"embed".equals(a[1])||"live".equals(a[1]))) return cleanYouTubeId(a[2]);
                }
            }
        }catch(Exception ignored){}
        return null;
    }

    private String cleanYouTubeId(String id){
        if(id==null) return null;
        id=id.trim();
        if(id.length()!=11) return null;
        return id.matches("[A-Za-z0-9_-]{11}")?id:null;
    }

    private void loadYouTube(String id){
        stopYouTubePlayback(); youtubeVideoId=id; sourceUri=null; youtubeReady=false;
        pipContainer.setInteractiveContent(true);
        pipContainer.bringToFront();
        player.pause(); source.setVisibility(View.GONE); youtubeView.setVisibility(View.VISIBLE); pipEmpty.setVisibility(View.GONE); emptyCard.setVisibility(View.GONE);
        sourceStatus.setText("Loading YouTube source…"); sourceTime.setText("00:00 / --:--"); play.setText("▶");
        String html="<!doctype html><html><head><meta name=\"viewport\" content=\"width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no\"></head><body style=\"margin:0;background:#090C12;overflow:hidden\"><div id=\"player\" style=\"width:100vw;height:100vh\"></div><script>var player;function onYouTubeIframeAPIReady(){player=new YT.Player('player',{width:'100%',height:'100%',videoId:'"+id+"',playerVars:{playsinline:1,controls:1,rel:0,enablejsapi:1,origin:'https://reactionrecorder.app'},events:{onReady:function(){AndroidYT.ready();},onStateChange:function(e){AndroidYT.state(e.data);},onError:function(e){AndroidYT.error(e.data);}}});}var t=document.createElement('script');t.src='https://www.youtube.com/iframe_api';document.head.appendChild(t);</script></body></html>";
        youtubeView.loadDataWithBaseURL("https://reactionrecorder.app/",html,"text/html","UTF-8",null);
    }

    private void stopYouTubePlayback(){
        if(youtubeView==null) return;
        try {
            youtubeView.evaluateJavascript("(function(){try{if(player){player.stopVideo();}}catch(e){}})();", null);
        } catch(Exception ignored) {}
        try { youtubeView.loadUrl("about:blank"); } catch(Exception ignored) {}
        youtubeReady=false;
    }

    private void setupYoutubeWebView(){
        youtubeView.setVisibility(View.GONE);
        WebSettings ws=youtubeView.getSettings(); ws.setJavaScriptEnabled(true); ws.setDomStorageEnabled(true); ws.setMediaPlaybackRequiresUserGesture(true); ws.setBuiltInZoomControls(false); ws.setDisplayZoomControls(false); ws.setSupportMultipleWindows(true); ws.setJavaScriptCanOpenWindowsAutomatically(true); ws.setUserAgentString(ws.getUserAgentString()+" Chrome/140.0.0.0 Mobile"); android.webkit.CookieManager.getInstance().setAcceptCookie(true); if(Build.VERSION.SDK_INT>=21) android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(youtubeView,true);
        youtubeView.setBackgroundColor(android.graphics.Color.rgb(9,12,18));
        youtubeView.setWebChromeClient(new WebChromeClient());
        youtubeView.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request){ return false; }
        });
        youtubeView.addJavascriptInterface(new Object(){
            @android.webkit.JavascriptInterface public void ready(){ runOnUiThread(()->{youtubeReady=true; sourceStatus.setText("YouTube ready • tap ▶ to play");}); }
            @android.webkit.JavascriptInterface public void state(int state){ runOnUiThread(()->{ if(state==1) sourceStatus.setText("Playing YouTube source"); else if(state==2) sourceStatus.setText("YouTube source paused"); play.setText(state==1?"Ⅱ":"▶"); }); }
            @android.webkit.JavascriptInterface public void error(int code){ runOnUiThread(()->Toast.makeText(MainActivity.this,"YouTube player error: "+code,Toast.LENGTH_LONG).show()); }
        },"AndroidYT");
    }

    private int dp(float v){return Math.round(v*getResources().getDisplayMetrics().density);}
    private TextView label(String text,float size,int color){TextView t=new TextView(this);t.setText(text);t.setTextColor(color);t.setTextSize(size);t.setGravity(android.view.Gravity.CENTER_VERTICAL);return t;}
    private Button sheetButton(String text,boolean accent){Button b=new Button(this);b.setText(text);b.setTextColor(Color.WHITE);b.setTextSize(12);b.setAllCaps(false);b.setMinHeight(dp(46));b.setMinWidth(0);b.setPadding(dp(14),0,dp(14),0);b.setBackgroundResource(accent?R.drawable.button_accent:R.drawable.button_secondary);return b;}
    private LinearLayout section(String title){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(16),dp(10),dp(16),dp(6));TextView t=label(title,10,Color.parseColor("#98A1B3"));t.setTypeface(null,android.graphics.Typeface.BOLD);box.addView(t,new LinearLayout.LayoutParams(-1,dp(28)));return box;}
    private void showSheet(String title,LinearLayout content){
        Dialog dialog=new Dialog(this);dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);LinearLayout shell=new LinearLayout(this);shell.setOrientation(LinearLayout.VERTICAL);shell.setPadding(dp(18),dp(14),dp(18),dp(18));shell.setBackgroundResource(R.drawable.panel);
        TextView titleView=label(title,20,Color.WHITE);titleView.setTypeface(null,android.graphics.Typeface.BOLD);shell.addView(titleView,new LinearLayout.LayoutParams(-1,dp(42)));
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.addView(content);shell.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        Button close=sheetButton("Close",false);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(46));cp.topMargin=dp(10);shell.addView(close,cp);close.setOnClickListener(v->dialog.dismiss());
        dialog.setContentView(shell);activeSheet=dialog;android.view.Window w=dialog.getWindow();if(w!=null){w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));w.setDimAmount(.65f);w.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);w.setLayout(-1,-2);w.setGravity(android.view.Gravity.BOTTOM);}dialog.setOnDismissListener(x->{if(activeSheet==dialog)activeSheet=null;});dialog.show();if(w!=null)w.setLayout(-1,(int)(getResources().getDisplayMetrics().heightPixels*.82f));
    }
    private Button settingRow(LinearLayout parent,String title,String value,View.OnClickListener click){LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.VERTICAL);row.setPadding(dp(14),dp(8),dp(14),dp(8));row.setBackgroundResource(R.drawable.button_secondary);TextView a=label(title,13,Color.WHITE);TextView b=label(value,11,Color.parseColor("#98A1B3"));row.addView(a,new LinearLayout.LayoutParams(-1,dp(26)));row.addView(b,new LinearLayout.LayoutParams(-1,dp(22)));if(click!=null)row.setOnClickListener(click);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(64));rp.bottomMargin=dp(8);parent.addView(row,rp);return null;}

    private void showCameraSettings(){
        LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);
        TextView info=label("Camera: Front camera\n\nPreview implementation: Compatible mode for broader Samsung/device support.\n\nThe camera preview is composed into the recording through the screen-capture pipeline.",14,Color.WHITE);
        info.setPadding(dp(8),dp(8),dp(8),dp(8));c.addView(info);
        showSheet("Camera",c);
    }

    private void showRecordingSettings(){
        LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);
        TextView info=label("Recording behavior is controlled here. Video format, resolution, frame rate and bitrate remain in Video.",13,Color.parseColor("#98A1B3"));info.setPadding(dp(8),dp(4),dp(8),dp(12));c.addView(info);
        Button border=sheetButton((recordingBorder?"✓  ":"")+"Recording border around camera + PIP",recordingBorder);c.addView(border,new LinearLayout.LayoutParams(-1,dp(46)));border.setOnClickListener(v->{recordingBorder=!recordingBorder;prefs.edit().putBoolean("recording_border",recordingBorder).apply();border.setText((recordingBorder?"✓  ":"")+"Recording border around camera + PIP");});
        Button full=sheetButton((fullscreenRecording?"✓  ":"")+"Fullscreen recording",fullscreenRecording);c.addView(full,new LinearLayout.LayoutParams(-1,dp(46)));full.setOnClickListener(v->{fullscreenRecording=!fullscreenRecording;prefs.edit().putBoolean("fullscreen_recording",fullscreenRecording).apply();full.setText((fullscreenRecording?"✓  ":"")+"Fullscreen recording");});
        showSheet("Recording",c);
    }

    private void showStorageSettings(){
        LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);
        TextView info=label("Save location\nMovies / Reaction Recorder\n\nEstimated size\n"+estimate10Min()+" per 10 minutes at the current video bitrate.\n\nFinished recordings are published to Android MediaStore so they appear in the Gallery/Photos apps.",14,Color.WHITE);info.setPadding(dp(8),dp(8),dp(8),dp(8));c.addView(info);
        Button size=sheetButton("View file size estimate",false);c.addView(size,new LinearLayout.LayoutParams(-1,dp(46)));size.setOnClickListener(v->showSizeInfo());
        showSheet("Storage",c);
    }

    private void showAboutSettings(){
        LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);
        TextView info=label("Reaction Recorder\n\nVersion 12.0.0\n\nRecord your camera reaction and source video together into one MP4.\n\nRequires Android 10 or newer.\n\nSource playback uses Media3. YouTube playback uses the official YouTube IFrame player; the app does not download YouTube videos.",14,Color.WHITE);info.setPadding(dp(8),dp(8),dp(8),dp(8));c.addView(info);
        showSheet("About",c);
    }

    private void settingsDialog(){
        LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);

        LinearLayout video=section("VIDEO");content.addView(video);
        settingRow(video,"Video quality",recordingSettings.summary(),v->chooseVideoQuality());
        settingRow(video,"Aspect ratio",aspectRatioName(),v->chooseAspectRatio());
        settingRow(video,"Estimated file size","About "+estimate10Min()+" per 10 minutes",v->showSizeInfo());

        LinearLayout audio=section("AUDIO");content.addView(audio);
        settingRow(audio,"Microphone input",selectedInputName,v->chooseAudioInput());
        settingRow(audio,"Microphone latency compensation",micLatencyMs==0?"Off • Android timestamp alignment":micLatencyMs+" ms earlier",v->chooseMicLatency());
        settingRow(audio,"Audio synchronization","Timestamp-aligned mic + source audio with drift protection",v->showAudioInfo());

        LinearLayout playback=section("PLAYBACK");content.addView(playback);
        settingRow(playback,"Rewind / forward amount",seekSeconds+" seconds",v->chooseSeekAmount());

        LinearLayout layout=section("LAYOUT");content.addView(layout);
        settingRow(layout,"PIP layout","Position, free-range size, corners and preview",v->pipSettingsDialog());

        LinearLayout cameraSection=section("CAMERA");content.addView(cameraSection);
        settingRow(cameraSection,"Camera","Front camera • compatible preview mode",v->showCameraSettings());

        LinearLayout recordingSection=section("RECORDING");content.addView(recordingSection);
        settingRow(recordingSection,"Recording behavior","Border: "+(recordingBorder?"On":"Off")+" • Fullscreen: "+(fullscreenRecording?"On":"Off"),v->showRecordingSettings());

        LinearLayout storage=section("STORAGE");content.addView(storage);
        settingRow(storage,"Save location","Movies / Reaction Recorder",v->showStorageSettings());
        settingRow(storage,"Space estimate",estimate10Min()+" per 10 minutes",v->showSizeInfo());

        LinearLayout appearance=section("APPEARANCE");content.addView(appearance);
        settingRow(appearance,"Appearance","Theme: "+uiTheme+" • "+(compactDock?"Compact":"Standard")+" dock",v->showAppearanceSettings());

        LinearLayout about=section("ABOUT");content.addView(about);
        settingRow(about,"Reaction Recorder","Version 12.0.0 • Android 10+",v->showAboutSettings());

        showSheet("Settings",content);
    }
    private void chooseMicLatency(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);TextView info=label("Bluetooth and USB microphones can add device-specific input delay. Android does not expose one universal latency value, so this setting lets you compensate without pretending the delay is known. 0 ms uses timestamp alignment only.",13,Color.parseColor("#98A1B3"));info.setPadding(dp(8),dp(4),dp(8),dp(12));c.addView(info);int[] vals={0,20,50,100,150,200,300,500};for(int v:vals){Button b=sheetButton((micLatencyMs==v?"✓  ":"")+(v==0?"Off (0 ms)":v+" ms earlier"),micLatencyMs==v);c.addView(b,new LinearLayout.LayoutParams(-1,dp(44)));b.setOnClickListener(x->{micLatencyMs=v;savePrefs();Toast.makeText(this,"Mic latency: "+(v==0?"off":v+" ms"),Toast.LENGTH_SHORT).show();if(activeSheet!=null)activeSheet.dismiss();});}showSheet("Microphone latency",c);}
    private void showAudioInfo(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(2),0,dp(2),0);TextView t=label("Selected input: "+selectedInputName+"\n\nThe recorder timestamps microphone and source-playback PCM on Android\'s monotonic clock instead of pairing chunks by queue position. This reduces long-recording drift and prevents one delayed input from permanently shifting the other.\n\nMicrophone latency compensation: "+(micLatencyMs==0?"Off (timestamp alignment only)":micLatencyMs+" ms earlier")+". Bluetooth latency varies by device and codec, so there is no universal Android value to assume.",14,Color.WHITE);t.setPadding(dp(8),dp(8),dp(8),dp(8));c.addView(t);showSheet("Audio synchronization",c);}
    private void pipSettingsDialog(){
        LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL);
        TextView info=label("Preview the PIP style and choose its corner shape. The on-screen resize handle gives you a free-range width and height.",13,Color.parseColor("#98A1B3")); info.setPadding(0,0,0,dp(10)); c.addView(info);
        FrameLayout preview=new FrameLayout(this); preview.setBackgroundColor(Color.rgb(7,9,14)); LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,dp(190)); pp.bottomMargin=dp(12); c.addView(preview,pp);
        TextView fake=new TextView(this); fake.setText("SOURCE VIDEO"); fake.setTextColor(Color.WHITE); fake.setTextSize(12); fake.setGravity(android.view.Gravity.CENTER); fake.setBackgroundColor(Color.rgb(35,43,58));
        FrameLayout.LayoutParams fp=new FrameLayout.LayoutParams(dp(150),dp(105),android.view.Gravity.CENTER); preview.addView(fake,fp); applyPreviewRadius(fake,pipCornerRadiusDp);
        TextView size=label("Current PIP: "+Math.round(pipContainer.getWidth()/getResources().getDisplayMetrics().density)+" × "+Math.round(pipContainer.getHeight()/getResources().getDisplayMetrics().density)+" dp",12,Color.WHITE); c.addView(size,new LinearLayout.LayoutParams(-1,dp(28)));
        TextView shapeLabel=label("Corner radius",12,Color.parseColor("#98A1B3")); c.addView(shapeLabel,new LinearLayout.LayoutParams(-1,dp(28)));
        float[] radii={0,4,8,12,18,24,32}; for(float r:radii){ Button b=sheetButton((Math.abs(r-pipCornerRadiusDp)<.5?"✓  ":"")+((int)r==0?"Square":((int)r+" dp")),Math.abs(r-pipCornerRadiusDp)<.5); c.addView(b,new LinearLayout.LayoutParams(-1,dp(42))); b.setOnClickListener(v->{pipCornerRadiusDp=r;applyPipAppearance();prefs.edit().putFloat("pip_corner_radius",r).apply();applyPreviewRadius(fake,r);size.setText("Current PIP: "+Math.round(pipContainer.getWidth()/getResources().getDisplayMetrics().density)+" × "+Math.round(pipContainer.getHeight()/getResources().getDisplayMetrics().density)+" dp");}); }
        Button presets=sheetButton("Reset to default size",false); c.addView(presets,new LinearLayout.LayoutParams(-1,dp(44))); presets.setOnClickListener(v->{ViewGroup.LayoutParams lp=pipContainer.getLayoutParams();lp.width=dp(240);lp.height=dp(200);pipContainer.setLayoutParams(lp);setPipTranslationFree(pipContainer.getTranslationX(),pipContainer.getTranslationY());savePipGeometry();size.setText("Current PIP: 240 × 200 dp");});
        showSheet("PIP layout",c);
    }
    private void applyPreviewRadius(View v,float radius){GradientDrawable g=new GradientDrawable();g.setColor(Color.rgb(35,43,58));g.setStroke(dp(2),Color.parseColor("#7568FF"));g.setCornerRadius(dp(radius));v.setBackground(g);v.setClipToOutline(radius>0);}

    private void chooseSeekAmount(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);TextView info=label("Choose how far the bottom buttons jump backward and forward. The same value is used for both.",13,Color.parseColor("#98A1B3"));info.setPadding(0,0,0,dp(12));c.addView(info);int[] vals={1,3,5,10,15,30,45,60};for(int v:vals){Button b=sheetButton((v==seekSeconds?"✓  ":"")+v+" seconds",v==seekSeconds);c.addView(b,new LinearLayout.LayoutParams(-1,dp(44)));b.setOnClickListener(x->{seekSeconds=v;saveSeekSeconds();Toast.makeText(this,"Seek amount: "+seekSeconds+" seconds",Toast.LENGTH_SHORT).show();});}showSheet("Rewind / forward",c);}
    private void chooseAspectRatio(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);String[] names={"9:16 vertical","16:9 landscape","1:1 square","4:3 landscape"};float r=recordingSettings.width/(float)recordingSettings.height;int checked=Math.abs(r-9f/16f)<.03f?0:Math.abs(r-16f/9f)<.03f?1:Math.abs(r-1)<.03f?2:3;for(int i=0;i<names.length;i++){final int w=i;Button b=sheetButton((i==checked?"✓  ":"")+names[i],i==checked);c.addView(b,new LinearLayout.LayoutParams(-1,dp(46)));b.setOnClickListener(v->{int longSide=Math.max(recordingSettings.width,recordingSettings.height);if(w==0){recordingSettings.width=even(Math.round(longSide*9f/16f));recordingSettings.height=even(longSide);}else if(w==1){recordingSettings.width=even(longSide);recordingSettings.height=even(Math.round(longSide*9f/16f));}else if(w==2){recordingSettings.width=even(longSide);recordingSettings.height=even(longSide);}else{recordingSettings.width=even(longSide);recordingSettings.height=even(Math.round(longSide*3f/4f));}savePrefs();updateSeekButtonLabels();Toast.makeText(this,"Aspect ratio: "+aspectRatioName(),Toast.LENGTH_SHORT).show();if(activeSheet!=null)activeSheet.dismiss();});b.setTag(null);}showSheet("Aspect ratio",c);}
    private void chooseVideoQuality(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);String[] names={"HEVC • 1080p • 30 • 5 Mbps","HEVC • 1080p • 30 • 8 Mbps","H.264 • 1080p • 30 • 8 Mbps","HEVC • 720p • 30 • 3 Mbps","Custom"};for(int i=0;i<names.length;i++){final int w=i;Button b=sheetButton(names[i],false);c.addView(b,new LinearLayout.LayoutParams(-1,dp(46)));b.setOnClickListener(v->{if(w==0)applyPreset("HEVC",1080,30,5_000_000);else if(w==1)applyPreset("HEVC",1080,30,8_000_000);else if(w==2)applyPreset("H.264",1080,30,8_000_000);else if(w==3)applyPreset("HEVC",720,30,3_000_000);else {if(activeSheet!=null)activeSheet.dismiss();customQualityDialog();} if(w<4&&activeSheet!=null)activeSheet.dismiss();});}showSheet("Video quality",c);}
    private void applyPreset(String codec,int longSide,int fps,int bitrate){recordingSettings.codec=codec;recordingSettings.fps=fps;recordingSettings.bitrate=bitrate;boolean vert=recordingSettings.height>recordingSettings.width;float r=recordingSettings.width/(float)recordingSettings.height;if(Math.abs(r-1)<.03f){recordingSettings.width=longSide;recordingSettings.height=longSide;}else if(Math.abs(r-4f/3f)<.08f){recordingSettings.width=longSide;recordingSettings.height=Math.round(longSide*3f/4f);}else if(vert){recordingSettings.height=longSide;recordingSettings.width=Math.round(longSide*9f/16f);}else{recordingSettings.width=longSide;recordingSettings.height=Math.round(longSide*9f/16f);}recordingSettings.width=even(recordingSettings.width);recordingSettings.height=even(recordingSettings.height);savePrefs();Toast.makeText(this,"Quality: "+recordingSettings.summary()+"\nEstimated 10 min: "+estimate10Min(),Toast.LENGTH_LONG).show();}
    private void customQualityDialog(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);TextView info=label("Set frame rate, bitrate, and codec.",13,Color.parseColor("#98A1B3"));c.addView(info,new LinearLayout.LayoutParams(-1,dp(42)));EditText fps=new EditText(this);fps.setText(String.valueOf(recordingSettings.fps));fps.setHint("FPS 15–60");fps.setTextColor(Color.WHITE);fps.setHintTextColor(Color.parseColor("#98A1B3"));fps.setBackgroundResource(R.drawable.button_secondary);c.addView(fps,new LinearLayout.LayoutParams(-1,dp(52)));EditText mbps=new EditText(this);mbps.setText(String.valueOf(Math.max(1,recordingSettings.bitrate/1_000_000)));mbps.setHint("Bitrate Mbps 1–30");mbps.setInputType(2);mbps.setTextColor(Color.WHITE);mbps.setHintTextColor(Color.parseColor("#98A1B3"));mbps.setBackgroundResource(R.drawable.button_secondary);LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,dp(52));mp.topMargin=dp(8);c.addView(mbps,mp);String[] codecs={"HEVC (H.265)","H.264 (AVC)"};for(int i=0;i<2;i++){final int w=i;Button b=sheetButton((recordingSettings.codec.equals(i==0?"HEVC":"H.264")?"✓  ":"")+codecs[i],false);c.addView(b,new LinearLayout.LayoutParams(-1,dp(44)));b.setOnClickListener(v->{recordingSettings.codec=w==0?"HEVC":"H.264";Toast.makeText(this,"Codec: "+recordingSettings.codec,Toast.LENGTH_SHORT).show();});}Button apply=sheetButton("Apply",true);c.addView(apply,new LinearLayout.LayoutParams(-1,dp(48)));apply.setOnClickListener(v->{try{recordingSettings.fps=Math.max(15,Math.min(60,Integer.parseInt(fps.getText().toString())));recordingSettings.bitrate=Math.max(1_000_000,Math.min(30_000_000,Integer.parseInt(mbps.getText().toString())*1_000_000));savePrefs();Toast.makeText(this,"Saved • "+recordingSettings.summary()+"\n~"+estimate10Min()+" / 10 min",Toast.LENGTH_LONG).show();if(activeSheet!=null)activeSheet.dismiss();}catch(Exception e){Toast.makeText(this,"Invalid values",Toast.LENGTH_SHORT).show();}});showSheet("Custom video",c);}
    private static int even(int value){
        if(value<2) return 2;
        return (value % 2 == 0) ? value : value - 1;
    }

    private String aspectRatioName(){
        float r=recordingSettings.height==0?1f:recordingSettings.width/(float)recordingSettings.height;
        if(Math.abs(r-9f/16f)<.03f) return "9:16 vertical";
        if(Math.abs(r-16f/9f)<.03f) return "16:9 landscape";
        if(Math.abs(r-1f)<.03f) return "1:1 square";
        if(Math.abs(r-4f/3f)<.08f) return "4:3 landscape";
        return String.format(Locale.US,"%.2f:1",r);
    }

    private String estimate10Min(){long bytes=(long)((recordingSettings.bitrate+192_000)*600/8.0);if(bytes>=1_000_000_000L)return String.format(Locale.US,"%.2f GB",bytes/1_000_000_000d);return String.format(Locale.US,"%.0f MB",bytes/1_000_000d);}
    private void showSizeInfo(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);TextView t=label("About "+estimate10Min()+" for 10 minutes at the selected bitrate.\n\nActual size can differ slightly because MP4 overhead and audio are included. Bitrate is the main control for file size.",14,Color.WHITE);c.addView(t);showSheet("File size estimate",c);}
    private void chooseAudioInput(){AudioManager am=(AudioManager)getSystemService(Context.AUDIO_SERVICE);AudioDeviceInfo[] ds=am.getDevices(AudioManager.GET_DEVICES_INPUTS);List<AudioDeviceInfo> usable=new ArrayList<>();List<String> labels=new ArrayList<>();labels.add("Phone microphone (default)");for(AudioDeviceInfo d:ds){String n=d.getProductName()==null?"Audio input":d.getProductName().toString();labels.add(n+" — "+typeName(d.getType()));usable.add(d);}LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);for(int i=0;i<labels.size();i++){final int w=i;boolean sel=i==0?selectedInputDeviceId==null:(selectedInputDeviceId!=null&&usable.get(i-1).getId()==selectedInputDeviceId);Button b=sheetButton((sel?"✓  ":"")+labels.get(i),sel);c.addView(b,new LinearLayout.LayoutParams(-1,dp(46)));b.setOnClickListener(v->{if(w==0){selectedInputDeviceId=null;selectedInputName="Phone microphone (default)";selectedInputDeviceId=null;}else{AudioDeviceInfo x=usable.get(w-1);selectedInputDeviceId=x.getId();selectedInputName=x.getProductName().toString();}savePrefs();Toast.makeText(this,"Input: "+selectedInputName,Toast.LENGTH_SHORT).show();if(activeSheet!=null)activeSheet.dismiss();});}showSheet("Microphone input",c);}
    private String typeName(int t){switch(t){case AudioDeviceInfo.TYPE_BUILTIN_MIC:return"phone mic";case AudioDeviceInfo.TYPE_BLUETOOTH_SCO:return"Bluetooth headset mic";case AudioDeviceInfo.TYPE_BLE_HEADSET:return"Bluetooth LE headset mic";case AudioDeviceInfo.TYPE_WIRED_HEADSET:return"wired headset mic";case AudioDeviceInfo.TYPE_USB_HEADSET:return"USB headset mic";default:return"input";}}

    private void startCamera(){if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)return;ProcessCameraProvider.getInstance(this).addListener(()->{try{ProcessCameraProvider p=ProcessCameraProvider.getInstance(this).get();p.unbindAll();camera.setImplementationMode(PreviewView.ImplementationMode.COMPATIBLE);
                Preview prev=new Preview.Builder().build();prev.setSurfaceProvider(camera.getSurfaceProvider());p.bindToLifecycle(this,CameraSelector.DEFAULT_FRONT_CAMERA,prev);}catch(Exception e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}},ContextCompat.getMainExecutor(this));}

    /**
     * Separates the recording scene from the normal application chrome.
     * The recorder consumes only camera/source frames from this scene; it never
     * captures the Android display.
     */
    private void enterRecordingScene(){
        recordingSceneActive = true;
        // The recorder no longer captures the Android display. UI chrome can
        // remain fully visible and interactive; only the camera and source PIP
        // are sampled by RecordingSceneController for the encoder.
        RecordingSceneController.prepareSource(source);
        if(pipContainer!=null) pipContainer.bringToFront();
    }

    private void exitRecordingScene(){
        recordingSceneActive = false;
        RecordingSceneController.restoreSource(source);
        setChromeVisible(true);
    }

    private void requestCapture(){
        if(!hasSource()){Toast.makeText(this,"Choose a source video first.",Toast.LENGTH_LONG).show();return;}
        if(recording)return;
        applyOrientationForAspect();
        enterRecordingScene();
        // Start sampling only the camera + source scene. There is deliberately no
        // MediaProjection request here, so Android never presents a screen-sharing
        // permission dialog for video recording.
        RecordingSceneController.startFramePump(root, camera, pipContainer, uiHandler);
        uiHandler.postDelayed(()->{
            if(!recordingSceneActive)return;
            Intent s=new Intent(this,RecordingService.class);
            s.setAction(RecordingService.ACTION_START);
            if(selectedInputDeviceId!=null)s.putExtra(RecordingService.EXTRA_DEVICE_ID,selectedInputDeviceId);
            s.putExtra(RecordingService.EXTRA_MIC_LATENCY_MS,micLatencyMs);
            s.putExtra(RecordingService.EXTRA_WIDTH,recordingSettings.width);
            s.putExtra(RecordingService.EXTRA_HEIGHT,recordingSettings.height);
            s.putExtra(RecordingService.EXTRA_FPS,recordingSettings.fps);
            s.putExtra(RecordingService.EXTRA_BITRATE,recordingSettings.bitrate);
            s.putExtra(RecordingService.EXTRA_CODEC,recordingSettings.codec);
            ContextCompat.startForegroundService(this,s);
        },120);
    }
    private void applyOrientationForAspect(){if(recordingSettings.width>recordingSettings.height)setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);else setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);}

    private void pauseRecording(){
        if(!recording || recordingPaused) return;
        sourceWasPlayingBeforeRecordingPause = isSourcePlaying();
        Intent s=new Intent(this,RecordingService.class);
        s.setAction(RecordingService.ACTION_PAUSE);
        startService(s);
        pauseRecord.setText("▶");
        recordingBadge.setText("⏸  PAUSING…");
    }

    private void requestResumeRecording(){
        if(!recording || !recordingPaused) return;
        pauseRecord.setEnabled(false);
        int token=++countdownToken;
        showResumeCountdown(3,token);
    }

    private void showResumeCountdown(int n,int token){
        TextView c=findViewById(R.id.resume_countdown);
        c.setText(String.valueOf(n)); c.setVisibility(View.VISIBLE);
        uiHandler.postDelayed(()->{
            if(token!=countdownToken || !recording || !recordingPaused){c.setVisibility(View.GONE); pauseRecord.setEnabled(true); return;}
            if(n>1) showResumeCountdown(n-1,token);
            else { c.setVisibility(View.GONE); beginResumeRecording(); }
        },1000);
    }

    private void beginResumeRecording(){
        Intent s=new Intent(this,RecordingService.class);
        s.setAction(RecordingService.ACTION_RESUME);
        startService(s);
        pauseRecord.setEnabled(true);
    }

    private boolean isSourcePlaying(){
        if(youtubeVideoId!=null) return youtubeReady && play.getText().toString().contains("Ⅱ");
        return player!=null && player.isPlaying();
    }

    private void pauseSource(){
        if(youtubeVideoId!=null){
            if(youtubeReady) youtubeView.evaluateJavascript("(function(){if(player){player.pauseVideo();}})();",null);
        } else if(player!=null) player.pause();
    }

    private void playSource(){
        if(youtubeVideoId!=null){
            if(youtubeReady) youtubeView.evaluateJavascript("(function(){if(player){player.playVideo();}})();",null);
        } else if(player!=null) player.play();
    }

    private void stopRecording(){countdownToken++; TextView c=findViewById(R.id.resume_countdown); if(c!=null)c.setVisibility(View.GONE); pauseRecord.setEnabled(true); Intent s=new Intent(this,RecordingService.class);s.setAction(RecordingService.ACTION_STOP);startService(s);record.setText("…"); recordingBadge.setText("●  SAVING…");}

    @Override protected void onDestroy(){uiHandler.removeCallbacks(progressTicker);try{unregisterReceiver(recorderReceiver);}catch(Exception ignored){}if(player!=null)player.release(); if(youtubeView!=null){stopYouTubePlayback(); youtubeView.removeJavascriptInterface("AndroidYT"); youtubeView.destroy();} super.onDestroy();}
}
