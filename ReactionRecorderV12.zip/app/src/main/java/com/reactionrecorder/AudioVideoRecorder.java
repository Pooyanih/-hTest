package com.reactionrecorder;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioDeviceInfo;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Surface;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.hardware.display.VirtualDisplay;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Locale;
import java.util.ArrayList;
import java.util.List;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;

/** Production-oriented recorder engine used by the foreground recording service. */
public final class AudioVideoRecorder {
    private static final int SAMPLE_RATE = 48_000;
    private static final int CHANNELS = 2;
    private static final int BYTES_PER_SAMPLE = 2;
    private static final int CHUNK_BYTES = 3840; // 20 ms @ 48 kHz stereo PCM16.

    private final Context ctx;
    private final Integer preferredInputDeviceId;
    private final int micLatencyMs;
    private final RecordingSettings settings;

    private MediaCodec videoEncoder;
    private MediaCodec audioEncoder;
    private Surface inputSurface;
    private MediaMuxer muxer;
    private File tempFile;
    private int videoTrack = -1;
    private int audioTrack = -1;
    private boolean muxerStarted;
    private final Object muxLock = new Object();
    private volatile boolean running;
    private volatile boolean stopRequested;
    private Thread videoThread;
    private Thread audioThread;
    private Thread micThread;
    private Thread playbackThread;
    private Thread compositorThread;
    private long recordingStartNs;
    private final Object pauseLock = new Object();
    private volatile boolean paused;
    private long pauseStartedNs;
    private long pausedDurationNs;
    private final List<long[]> pauseIntervalsNs = new ArrayList<>();
    private long videoPtsBaseUs = Long.MIN_VALUE;
    private volatile boolean awaitResumeKeyframe = false;
    private volatile long composedFrameCount = 0L;

    public AudioVideoRecorder(Context context, Integer preferredInputDeviceId, int micLatencyMs, RecordingSettings requested) throws Exception {
        ctx = context.getApplicationContext();
        this.preferredInputDeviceId = preferredInputDeviceId;
        this.micLatencyMs = Math.max(0, Math.min(500, micLatencyMs));
        settings = (requested == null ? new RecordingSettings() : requested.copy());
        normalizeSettings(settings);
        setupVideo();
        setupAudioEncoder();
    }

    public RecordingSettings getEffectiveSettings() { return settings.copy(); }

    public static boolean isCodecAvailable(String codec) {
        String mime = "HEVC".equalsIgnoreCase(codec) ? "video/hevc" : "video/avc";
        for (MediaCodecInfo info : new MediaCodecList(MediaCodecList.ALL_CODECS).getCodecInfos()) {
            if (!info.isEncoder()) continue;
            for (String type : info.getSupportedTypes()) if (mime.equalsIgnoreCase(type)) return true;
        }
        return false;
    }

    private static MediaCodecInfo findVideoEncoder(String mime) {
        for (MediaCodecInfo info : new MediaCodecList(MediaCodecList.ALL_CODECS).getCodecInfos()) {
            if (!info.isEncoder()) continue;
            for (String type : info.getSupportedTypes()) {
                if (mime.equalsIgnoreCase(type)) return info;
            }
        }
        return null;
    }

    private static void normalizeSettings(RecordingSettings s) throws Exception {
        s.width = Math.max(2, s.width & ~1);
        s.height = Math.max(2, s.height & ~1);
        s.fps = Math.max(15, Math.min(60, s.fps));
        s.bitrate = Math.max(500_000, Math.min(50_000_000, s.bitrate));

        String mime = "HEVC".equalsIgnoreCase(s.codec) ? "video/hevc" : "video/avc";
        MediaCodecInfo info = findVideoEncoder(mime);
        if (info == null && "video/hevc".equals(mime)) {
            mime = "video/avc";
            s.codec = "H.264";
            info = findVideoEncoder(mime);
        }
        if (info == null) throw new IllegalStateException("No hardware/software video encoder is available for H.264/HEVC");

        MediaCodecInfo.VideoCapabilities vc = info.getCapabilitiesForType(mime).getVideoCapabilities();
        int w = s.width, h = s.height;
        if (!vc.areSizeAndRateSupported(w, h, s.fps)) {
            if (vc.areSizeAndRateSupported(h, w, s.fps)) { int t=w; w=h; h=t; }
            else {
                double targetArea = (double) w * h;
                int bestW = 0, bestH = 0;
                for (int[] size : new int[][]{{1920,1080},{1080,1920},{1280,720},{720,1280},{854,480},{480,854}}) {
                    if (vc.areSizeAndRateSupported(size[0], size[1], Math.min(s.fps, 30))) {
                        double area = (double) size[0] * size[1];
                        if (area <= targetArea && area > (double) bestW * bestH) { bestW=size[0]; bestH=size[1]; }
                    }
                }
                if (bestW == 0) {
                    bestW = Math.min(w, vc.getSupportedWidths().getUpper());
                    bestH = Math.min(h, vc.getSupportedHeights().getUpper());
                    bestW &= ~1; bestH &= ~1;
                }
                w = bestW; h = bestH;
            }
        }
        // If the requested frame rate is unsupported, step down to a rate the encoder accepts.
        int[] fpsCandidates = {s.fps, 60, 50, 30, 25, 24, 20, 15};
        int chosenFps = 15;
        for (int f : fpsCandidates) {
            if (f <= s.fps && vc.areSizeAndRateSupported(w, h, f)) { chosenFps=f; break; }
        }
        s.width=w; s.height=h; s.fps=chosenFps;
        int minBitrate = vc.getBitrateRange().getLower();
        int maxBitrate = vc.getBitrateRange().getUpper();
        s.bitrate = Math.max(minBitrate, Math.min(maxBitrate, s.bitrate));
    }

    private void setupVideo() throws Exception {
        String mime = "HEVC".equalsIgnoreCase(settings.codec) ? "video/hevc" : "video/avc";
        videoEncoder = MediaCodec.createEncoderByType(mime);
        MediaFormat format = MediaFormat.createVideoFormat(mime, settings.width, settings.height);
        format.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
        format.setInteger(MediaFormat.KEY_BIT_RATE, settings.bitrate);
        format.setInteger(MediaFormat.KEY_FRAME_RATE, settings.fps);
        format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2);
        videoEncoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
        inputSurface = videoEncoder.createInputSurface();
    }

    private void setupAudioEncoder() throws Exception {
        audioEncoder = MediaCodec.createEncoderByType("audio/mp4a-latm");
        MediaFormat format = MediaFormat.createAudioFormat("audio/mp4a-latm", SAMPLE_RATE, CHANNELS);
        format.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
        format.setInteger(MediaFormat.KEY_BIT_RATE, 192_000);
        audioEncoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
    }

    public void start() throws Exception {
        tempFile = new File(ctx.getCacheDir(), "reaction_" + System.currentTimeMillis() + ".mp4");
        muxer = new MediaMuxer(tempFile.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
        videoEncoder.start(); audioEncoder.start();

        recordingStartNs = System.nanoTime();

        // IMPORTANT: this recorder never captures the Android display. The encoder
        // receives only the camera + source scene produced by RecordingSceneController.
        // App chrome remains a completely separate UI layer.
        running = true; stopRequested = false;
        videoThread = new Thread(this::videoDrainLoop, "reaction-video-drain");
        compositorThread = new Thread(this::compositorLoop, "reaction-scene-compositor");
        compositorThread.start();
        audioThread = new Thread(this::audioLoop, "reaction-audio-mixer");
        videoThread.start(); audioThread.start();
    }

    private void addVideoTrack(MediaFormat format) {
        synchronized (muxLock) {
            if (videoTrack < 0) videoTrack = muxer.addTrack(format);
            maybeStartMuxerLocked();
        }
    }

    private void addAudioTrack(MediaFormat format) {
        synchronized (muxLock) {
            if (audioTrack < 0) audioTrack = muxer.addTrack(format);
            maybeStartMuxerLocked();
        }
    }

    private void maybeStartMuxerLocked() {
        if (!muxerStarted && videoTrack >= 0 && audioTrack >= 0) {
            muxer.start(); muxerStarted = true;
        }
    }

    private void compositorLoop() {
        Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        long frameNs=1_000_000_000L/Math.max(15,settings.fps);
        long next=System.nanoTime();
        while(running && !stopRequested){
            try {
                if(paused){ Thread.sleep(8); continue; }
                RecordingSceneController.Frame f=RecordingSceneController.consumeLatestFrame();
                if(f==null){ Thread.sleep(5); continue; }
                Canvas c=inputSurface.lockCanvas(null);
                try {
                    c.drawColor(android.graphics.Color.BLACK);
                    c.drawBitmap(f.camera,null,new RectF(0,0,settings.width,settings.height),paint);
                    float x=f.pipX*settings.width, y=f.pipY*settings.height;
                    float w=f.pipW*settings.width, h=f.pipH*settings.height;
                    c.drawBitmap(f.pip,null,new RectF(x,y,x+w,y+h),paint);
                } finally { inputSurface.unlockCanvasAndPost(c); }
                composedFrameCount++;
                try { if(f.camera!=null&&!f.camera.isRecycled())f.camera.recycle(); } catch(Throwable ignored){}
                try { if(f.pip!=null&&!f.pip.isRecycled())f.pip.recycle(); } catch(Throwable ignored){}
                next += frameNs;
                long sleep=next-System.nanoTime();
                if(sleep>0) Thread.sleep(sleep/1_000_000L,(int)(sleep%1_000_000L));
                else next=System.nanoTime();
            } catch(Throwable e){ if(!stopRequested) { try{Thread.sleep(10);}catch(Exception ignored){} } }
        }
    }

    private void videoDrainLoop() {
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        boolean eos=false;
        while (!eos) {
            int out;
            try { out=videoEncoder.dequeueOutputBuffer(info, 10_000); } catch (Exception e) { return; }
            if (out == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) addVideoTrack(videoEncoder.getOutputFormat());
            else if (out >= 0) {
                ByteBuffer data=videoEncoder.getOutputBuffer(out);
                if (data != null && info.size>0 && (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG)==0) {
                    data.position(info.offset); data.limit(info.offset+info.size);
                    if (videoPtsBaseUs == Long.MIN_VALUE) videoPtsBaseUs = info.presentationTimeUs;
                    long originalUs = Math.max(0L, info.presentationTimeUs - videoPtsBaseUs);
                    long adjustedUs = adjustedTimestampUs(originalUs);
                    if (adjustedUs >= 0) {
                        // Frames produced while paused are intentionally omitted.
                        // Because H.264/HEVC inter-frames reference earlier frames,
                        // the first frame after a pause must be a fresh keyframe.
                        // setPaused(false) requests one and we discard output until
                        // the encoder gives us that sync frame.
                        if (awaitResumeKeyframe && (info.flags & MediaCodec.BUFFER_FLAG_KEY_FRAME) == 0) {
                            // Keep draining, but do not put a dependent frame into
                            // the MP4 before the new GOP begins.
                        } else {
                            if ((info.flags & MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0) awaitResumeKeyframe = false;
                            MediaCodec.BufferInfo adjusted = new MediaCodec.BufferInfo();
                            adjusted.set(info.offset, info.size, adjustedUs, info.flags);
                            writeSample(videoTrack,data,adjusted);
                        }
                    }
                }
                eos=(info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0;
                videoEncoder.releaseOutputBuffer(out,false);
            }
        }
    }

    private static final class TimedPcm {
        final byte[] data;
        final long startNs;
        TimedPcm(byte[] data, long startNs) { this.data = data; this.startNs = startNs; }
    }

    private void audioLoop() {
        AudioRecord mic=null, playback=null;
        ArrayBlockingQueue<TimedPcm> micQ=new ArrayBlockingQueue<>(32);
        ArrayBlockingQueue<TimedPcm> playQ=new ArrayBlockingQueue<>(32);
        try {
            mic=createMic();
            // Do not use AudioPlaybackCapture here: Android requires a MediaProjection
            // user-consent flow for cross-app playback capture. The recorder therefore
            // never requests screen-capture permission. Source audio can be supplied
            // by an app-local audio bus in a later renderer integration; microphone
            // audio remains fully independent and timestamped here.
            playback=null;
            startReaderThreads(mic, null, micQ, playQ);
            final long chunkNs = 20_000_000L;
            long targetNs = 0L;
            TimedPcm mc = null, pc = null;
            while (running && !stopRequested) {
                if (paused) {
                    drainAudio(false);
                    Thread.sleep(5);
                    mc = null; pc = null;
                    continue;
                }
                long targetAbsNs = recordingStartNs + targetNs;
                mc = advanceChunk(mc, micQ, targetAbsNs + micLatencyMs * 1_000_000L, chunkNs);
                pc = advanceChunk(pc, playQ, targetAbsNs, chunkNs);

                byte[] m = sampleForTarget(mc, targetAbsNs + micLatencyMs * 1_000_000L, chunkNs);
                byte[] p = sampleForTarget(pc, targetAbsNs, chunkNs);
                feedAudioBlocking(mix(m, p), targetNs / 1000L);
                targetNs += chunkNs;
            }
            stopRequested=true;
            queueAudioEos(targetNs / 1000L);
            drainAudioUntilEos();
        } catch (Throwable e) {
            try { queueAudioEos(0); drainAudioUntilEos(); } catch (Exception ignored) {}
        } finally {
            stopRecord(mic); stopRecord(playback);
        }
    }

    private TimedPcm advanceChunk(TimedPcm current, ArrayBlockingQueue<TimedPcm> q, long targetNs, long chunkNs) throws InterruptedException {
        TimedPcm c=current;
        while (c != null && c.startNs + chunkNs <= targetNs) c=q.poll();
        if (c == null) c=q.poll(100, TimeUnit.MILLISECONDS);
        // Drop chunks that are already too old. This is the key long-recording
        // drift protection: the timeline follows AudioRecord's monotonic clock
        // instead of blindly pairing the Nth mic chunk with the Nth playback chunk.
        while (c != null && c.startNs + chunkNs <= targetNs) c=q.poll();
        return c;
    }

    private byte[] sampleForTarget(TimedPcm c, long targetNs, long chunkNs) {
        if (c == null) return new byte[CHUNK_BYTES];
        long delta=c.startNs-targetNs;
        if (delta > chunkNs || c.startNs + chunkNs <= targetNs) return new byte[CHUNK_BYTES];
        // Chunks are captured at exactly 20 ms. For the normal case, use the
        // complete chunk. If the device clock slips by a small amount, choose
        // the nearest chunk rather than accumulating an ever-growing offset.
        return c.data;
    }

    private AudioRecord createMic() {
        int min=AudioRecord.getMinBufferSize(SAMPLE_RATE,AudioFormat.CHANNEL_IN_STEREO,AudioFormat.ENCODING_PCM_16BIT);
        if(min<CHUNK_BYTES) min=CHUNK_BYTES*4;
        try {
            AudioRecord r=new AudioRecord.Builder().setAudioSource(MediaRecorder.AudioSource.MIC)
                    .setAudioFormat(new AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(SAMPLE_RATE).setChannelMask(AudioFormat.CHANNEL_IN_STEREO).build())
                    .setBufferSizeInBytes(Math.max(min*2, CHUNK_BYTES*8)).build();
            if(preferredInputDeviceId!=null && Build.VERSION.SDK_INT>=23) {
                AudioManager am=(AudioManager)ctx.getSystemService(Context.AUDIO_SERVICE);
                for(AudioDeviceInfo d:am.getDevices(AudioManager.GET_DEVICES_INPUTS)) if(d.getId()==preferredInputDeviceId) { r.setPreferredDevice(d); break; }
            }
            r.startRecording();
            return r;
        } catch(Throwable e) { return null; }
    }

    private AudioRecord createPlayback() {
        // Intentionally disabled. AudioPlaybackCapture requires MediaProjection
        // authorization on Android 10+, which would reintroduce the screen-capture
        // permission this recorder is explicitly designed to avoid.
        return null;
    }

    private void startReaderThreads(AudioRecord mic, AudioRecord playback, ArrayBlockingQueue<TimedPcm> mq, ArrayBlockingQueue<TimedPcm> pq) {
        micThread=new Thread(()->readTimedLoop(mic,mq),"reaction-mic-reader");
        playbackThread=new Thread(()->readTimedLoop(playback,pq),"reaction-playback-reader");
        micThread.start(); playbackThread.start();
    }

    private void readTimedLoop(AudioRecord r, ArrayBlockingQueue<TimedPcm> q) {
        final long chunkNs=20_000_000L;
        while(running && !stopRequested) {
            byte[] b=new byte[CHUNK_BYTES];
            int n=0;
            long readEnd=System.nanoTime();
            if(r!=null) {
                try {
                    n=r.read(b,0,b.length,AudioRecord.READ_BLOCKING);
                    readEnd=System.nanoTime();
                } catch(Throwable ignored) { }
            }
            if(n<CHUNK_BYTES) java.util.Arrays.fill(b,Math.max(0,n),CHUNK_BYTES,(byte)0);
            // Prefer AudioRecord's hardware timestamp on the monotonic clock.
            // Falling back to readEnd keeps the recorder functional on devices
            // that do not expose a timestamp for the particular input.
            long start=readEnd-chunkNs;
            if(r!=null && n>0) {
                try {
                    android.media.AudioTimestamp ts=new android.media.AudioTimestamp();
                    if(r.getTimestamp(ts, android.media.AudioTimestamp.TIMEBASE_MONOTONIC)==AudioRecord.SUCCESS) {
                        long framesRead=Math.max(1L,n/(CHANNELS*BYTES_PER_SAMPLE));
                        start=ts.nanoTime-Math.round(framesRead*1_000_000_000.0/SAMPLE_RATE);
                    }
                } catch(Throwable ignored) {}
            }
            TimedPcm chunk=new TimedPcm(b,start);
            if(!q.offer(chunk)) { q.poll(); q.offer(chunk); }
        }
    }

    private byte[] mix(byte[] m, byte[] p) {
        byte[] out=new byte[CHUNK_BYTES];
        for(int i=0;i<CHUNK_BYTES;i+=2) {
            short ms=ByteBuffer.wrap(m,i,2).order(ByteOrder.LITTLE_ENDIAN).getShort();
            short ps=ByteBuffer.wrap(p,i,2).order(ByteOrder.LITTLE_ENDIAN).getShort();
            int v=Math.round(ms*0.85f + ps*0.75f);
            if(v>32767)v=32767; if(v<-32768)v=-32768;
            out[i]=(byte)v; out[i+1]=(byte)(v>>8);
        }
        return out;
    }

    private long adjustedTimestampUs(long originalUs) {
        synchronized (pauseLock) {
            long removed = 0L;
            for (long[] interval : pauseIntervalsNs) {
                long startUs = Math.max(0L, (interval[0] - recordingStartNs) / 1000L);
                long endUs = Math.max(startUs, (interval[1] - recordingStartNs) / 1000L);
                if (originalUs >= endUs) removed += endUs - startUs;
                else if (originalUs >= startUs) return -1L;
            }
            if (paused && pauseStartedNs > 0 && System.nanoTime() >= pauseStartedNs) {
                long startUs = Math.max(0L, (pauseStartedNs - recordingStartNs) / 1000L);
                if (originalUs >= startUs) return -1L;
            }
            return Math.max(0L, originalUs - removed);
        }
    }

    public boolean setPaused(boolean value) {
        synchronized (pauseLock) {
            if (value == paused || stopRequested) return false;
            if (value) {
                paused = true;
                pauseStartedNs = System.nanoTime();
            } else {
                long now = System.nanoTime();
                if (pauseStartedNs > 0) {
                    long elapsed = Math.max(0L, now - pauseStartedNs);
                    pausedDurationNs += elapsed;
                    pauseIntervalsNs.add(new long[]{pauseStartedNs, now});
                }
                pauseStartedNs = 0L;
                paused = false;
                awaitResumeKeyframe = true;
                try {
                    Bundle params = new Bundle();
                    params.putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0);
                    if (videoEncoder != null) videoEncoder.setParameters(params);
                } catch (Throwable ignored) {
                    // Some encoders do not expose runtime sync-frame requests.
                    // The normal encoder cadence will still eventually produce a keyframe.
                }
            }
            return true;
        }
    }

    private long getPausedDurationUs() {
        synchronized (pauseLock) {
            long total = pausedDurationNs;
            if (paused && pauseStartedNs > 0) total += Math.max(0L, System.nanoTime() - pauseStartedNs);
            return total / 1000L;
        }
    }

    private void feedAudioBlocking(byte[] bytes,long ptsUs) throws Exception {
        while(running && !stopRequested) {
            int in=audioEncoder.dequeueInputBuffer(10_000);
            drainAudio(false);
            if(in>=0) {
                ByteBuffer b=audioEncoder.getInputBuffer(in); if(b==null) continue;
                b.clear(); b.put(bytes); audioEncoder.queueInputBuffer(in,0,bytes.length,ptsUs,0); break;
            }
        }
        while(drainAudio(false)) {}
    }

    private void queueAudioEos(long ptsUs) throws Exception {
        int in; do { in=audioEncoder.dequeueInputBuffer(10_000); drainAudio(false); } while(in<0);
        audioEncoder.queueInputBuffer(in,0,0,ptsUs,MediaCodec.BUFFER_FLAG_END_OF_STREAM);
    }

    private void drainAudioUntilEos() throws Exception { boolean eos=false; while(!eos) eos=drainAudio(true); }

    private boolean drainAudio(boolean wait) throws Exception {
        MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();
        int out=audioEncoder.dequeueOutputBuffer(info,wait?10_000:0);
        if(out==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) { addAudioTrack(audioEncoder.getOutputFormat()); return false; }
        if(out>=0) {
            ByteBuffer data=audioEncoder.getOutputBuffer(out);
            if(data!=null && info.size>0 && (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG)==0) { data.position(info.offset); data.limit(info.offset+info.size); writeSample(audioTrack,data,info); }
            boolean eos=(info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0; audioEncoder.releaseOutputBuffer(out,false); return eos;
        }
        return false;
    }

    private void writeSample(int track,ByteBuffer data,MediaCodec.BufferInfo info) {
        synchronized(muxLock) { if(!muxerStarted||track<0)return; try{muxer.writeSampleData(track,data,info);}catch(Exception ignored){} }
    }

    public File stopAndGetTempFile() {
        synchronized (pauseLock) {
            if (paused && pauseStartedNs > 0) {
                long now = System.nanoTime();
                pausedDurationNs += Math.max(0L, now - pauseStartedNs);
                pauseIntervalsNs.add(new long[]{pauseStartedNs, now});
                pauseStartedNs = 0L;
                paused = false;
            }
        }
        // Give the surface compositor and MediaCodec a short grace period to
        // deliver the initial format/frame. This prevents a fast stop from
        // producing an empty MP4.
        long waitEnd=System.currentTimeMillis()+1500;
        while(composedFrameCount==0 && System.currentTimeMillis()<waitEnd){
            try{Thread.sleep(10);}catch(InterruptedException e){Thread.currentThread().interrupt();break;}
        }
        stopRequested=true; running=false;
        try{if(videoEncoder!=null)videoEncoder.signalEndOfInputStream();}catch(Exception ignored){}
        join(audioThread,5000); join(videoThread,5000); join(compositorThread,3000); join(micThread,1000); join(playbackThread,1000);
        try{videoEncoder.stop();}catch(Exception ignored){} try{audioEncoder.stop();}catch(Exception ignored){}
        try{videoEncoder.release();}catch(Exception ignored){} try{audioEncoder.release();}catch(Exception ignored){}
        synchronized(muxLock){try{if(muxerStarted)muxer.stop();}catch(Exception ignored){} try{if(muxer!=null)muxer.release();}catch(Exception ignored){} muxer=null;}
        if(!muxerStarted || videoTrack<0) throw new IllegalStateException("Recording did not produce a valid video track");
        return tempFile;
    }

    private static void join(Thread t,long ms){if(t!=null)try{t.join(ms);}catch(InterruptedException ignored){Thread.currentThread().interrupt();}}
    private static void stopRecord(AudioRecord r){if(r!=null)try{r.stop();}catch(Exception ignored){} if(r!=null)try{r.release();}catch(Exception ignored){}}

    public static android.net.Uri publishToGallery(Context context,File temp)throws Exception{
        ContentResolver resolver=context.getContentResolver(); ContentValues v=new ContentValues();
        v.put(MediaStore.Video.Media.DISPLAY_NAME,"Reaction_"+new SimpleDateFormat("yyyy-MM-dd_HH-mm",Locale.US).format(new Date())+".mp4"); v.put(MediaStore.Video.Media.MIME_TYPE,"video/mp4");
        if(Build.VERSION.SDK_INT>=29){v.put(MediaStore.Video.Media.RELATIVE_PATH,Environment.DIRECTORY_MOVIES+"/Reaction Recorder");v.put(MediaStore.Video.Media.IS_PENDING,1);}
        android.net.Uri uri=resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,v); if(uri==null)throw new IllegalStateException("Could not create gallery item");
        try(FileInputStream in=new FileInputStream(temp);OutputStream out=resolver.openOutputStream(uri)){byte[] b=new byte[64*1024];int n;while((n=in.read(b))!=-1)out.write(b,0,n);}
        if(Build.VERSION.SDK_INT>=29){ContentValues done=new ContentValues();done.put(MediaStore.Video.Media.IS_PENDING,0);resolver.update(uri,done,null,null);} temp.delete(); return uri;
    }

    public static final class RecordingSettings{
        public int width=1080,height=1920,fps=30,bitrate=5_000_000; public String codec="HEVC";
        public RecordingSettings copy(){RecordingSettings r=new RecordingSettings();r.width=width;r.height=height;r.fps=fps;r.bitrate=bitrate;r.codec=codec;return r;}
        public String summary(){return width+"×"+height+" • "+fps+" FPS • "+codec+" • "+String.format(Locale.US,"%.1f Mbps",bitrate/1_000_000f);}
    }
}
