package com.reactionrecorder;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioDeviceInfo;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTimestamp;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Surface;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Locale;
import java.util.ArrayList;
import java.util.List;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/** Production-oriented recorder engine used by the foreground recording service. */
public final class AudioVideoRecorder {
    private static final int SAMPLE_RATE = 48_000;
    private static final int CHANNELS = 2;
    private static final int BYTES_PER_SAMPLE = 2;
    private static final int CHUNK_BYTES = 3840; // 20 ms @ 48 kHz stereo PCM16.

    private final Context ctx;
    private final MediaProjection projection;
    private final Integer preferredInputDeviceId;
    private final int micLatencyMs;
    private final RecordingSettings settings;

    private MediaCodec videoEncoder;
    private MediaCodec audioEncoder;
    private Surface inputSurface;
    private VirtualDisplay virtualDisplay;
    private MediaMuxer muxer;
    private MediaProjection.Callback projectionCallback;
    private boolean projectionCallbackRegistered;
    private File tempFile;
    private int videoTrack = -1;
    private int audioTrack = -1;
    private boolean muxerStarted;
    private final Object muxLock = new Object();
    private volatile boolean running;
    private volatile boolean stopRequested;
    private Thread videoThread;
    private Thread audioThread;
    private Thread micThread;
    private Thread playbackThread;
    private long recordingStartNs;
    private final Object pauseLock = new Object();
    private volatile boolean paused;
    private long pauseStartedNs;
    private long pausedDurationNs;
    private final List<long[]> pauseIntervalsNs = new ArrayList<>();
    private long videoPtsBaseUs = Long.MIN_VALUE;
    private volatile boolean awaitResumeKeyframe = false;
    private volatile long resumeGeneration = 0L;
    private volatile AudioRecord micRecord;
    private volatile AudioRecord playbackRecord;
    private volatile Runnable projectionStoppedListener;
    private volatile Runnable failureListener;
    private final AtomicBoolean failurePosted = new AtomicBoolean(false);
    private volatile boolean projectionStopped;
    private volatile boolean startCompleted;
    private volatile Throwable recorderError;
    private volatile boolean audioEosQueued;
    private volatile boolean audioEosReached;

    public AudioVideoRecorder(Context context, android.content.Intent projectionData,
                              Integer preferredInputDeviceId, int micLatencyMs, RecordingSettings requested) throws Exception {
        ctx = context.getApplicationContext();
        this.preferredInputDeviceId = preferredInputDeviceId;
        this.micLatencyMs = Math.max(0, Math.min(500, micLatencyMs));
        settings = (requested == null ? new RecordingSettings() : requested.copy());
        MediaProjectionManager pm = (MediaProjectionManager) ctx.getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        projection = pm.getMediaProjection(android.app.Activity.RESULT_OK, projectionData);
        if (projection == null) throw new IllegalStateException("Media projection was not granted");
        try {
            normalizeSettings(settings);
            setupVideo();
            setupAudioEncoder();
        } catch (Exception e) {
            releaseSetupFailure();
            throw e;
        }
    }

    public RecordingSettings getEffectiveSettings() { return settings.copy(); }

    private void releaseSetupFailure() {
        try { if (inputSurface != null) inputSurface.release(); } catch (Throwable ignored) {}
        try { if (videoEncoder != null) videoEncoder.release(); } catch (Throwable ignored) {}
        try { if (audioEncoder != null) audioEncoder.release(); } catch (Throwable ignored) {}
        try { projection.stop(); } catch (Throwable ignored) {}
    }

    public void setProjectionStoppedListener(Runnable listener) { projectionStoppedListener = listener; }
    public void setFailureListener(Runnable listener) { failureListener = listener; }

    public static boolean isCodecAvailable(String codec) {
        String mime = "HEVC".equalsIgnoreCase(codec) ? "video/hevc" : "video/avc";
        for (MediaCodecInfo info : new MediaCodecList(MediaCodecList.ALL_CODECS).getCodecInfos()) {
            if (!info.isEncoder()) continue;
            for (String type : info.getSupportedTypes()) if (mime.equalsIgnoreCase(type)) return true;
        }
        return false;
    }

    private static MediaCodecInfo findVideoEncoder(String mime) {
        for (MediaCodecInfo info : new MediaCodecList(MediaCodecList.ALL_CODECS).getCodecInfos()) {
            if (!info.isEncoder()) continue;
            for (String type : info.getSupportedTypes()) {
                if (mime.equalsIgnoreCase(type)) return info;
            }
        }
        return null;
    }

    private static void normalizeSettings(RecordingSettings s) throws Exception {
        s.width = Math.max(2, s.width & ~1);
        s.height = Math.max(2, s.height & ~1);
        s.fps = Math.max(15, Math.min(60, s.fps));
        s.bitrate = Math.max(500_000, Math.min(50_000_000, s.bitrate));
        if(!"HEVC".equalsIgnoreCase(s.codec) && !"H.264".equalsIgnoreCase(s.codec)) s.codec="HEVC";

        String mime = "HEVC".equalsIgnoreCase(s.codec) ? "video/hevc" : "video/avc";
        MediaCodecInfo info = findVideoEncoder(mime);
        if (info == null && "video/hevc".equals(mime)) {
            mime = "video/avc";
            s.codec = "H.264";
            info = findVideoEncoder(mime);
        }
        if (info == null) throw new IllegalStateException("No hardware/software video encoder is available for H.264/HEVC");

        MediaCodecInfo.VideoCapabilities vc = info.getCapabilitiesForType(mime).getVideoCapabilities();
        int w=s.width,h=s.height;
        double targetRatio=(double)w/Math.max(1,h);
        if(!vc.areSizeAndRateSupported(w,h,s.fps)){
            int bestW=0,bestH=0,bestF=0;
            int[] longSides={Math.max(w,h),1440,1080,960,854,720,640,480,360};
            for(int longSide:longSides){
                if(longSide<=0) continue;
                int cw=targetRatio>=1.0?longSide:Math.max(2,Math.round(longSide*(float)targetRatio));
                int ch=targetRatio>=1.0?Math.max(2,Math.round(longSide/(float)targetRatio)):longSide;
                cw&=~1; ch&=~1;
                if(cw<2||ch<2) continue;
                int[] fs={s.fps,60,50,30,25,24,20,15};
                for(int f:fs){
                    if(f<=s.fps && f>=15 && vc.areSizeAndRateSupported(cw,ch,f)){
                        double area=(double)cw*ch; double targetArea=(double)s.width*s.height;
                        if(bestW==0 || Math.abs(area-targetArea) < Math.abs((double)bestW*bestH-targetArea)){bestW=cw;bestH=ch;bestF=f;}
                        break;
                    }
                }
                if(bestW!=0 && bestW*bestH>=(double)s.width*s.height*0.95) break;
            }
            if(bestW==0){
                // Last-resort capability-constrained size. Keep the requested orientation.
                android.util.Range<Integer> wr=vc.getSupportedWidths();
                android.util.Range<Integer> hr=vc.getSupportedHeights();
                bestW=Math.max(2,Math.min(s.width,wr.getUpper()))&~1;
                bestH=Math.max(2,Math.min(s.height,hr.getUpper()))&~1;
                int[] fs={s.fps,30,24,20,15};
                bestF=15;
                for(int f:fs) if(f>=15 && f<=s.fps && vc.areSizeAndRateSupported(bestW,bestH,f)){bestF=f;break;}
            }
            w=bestW;h=bestH;s.fps=bestF==0?15:bestF;
        } else {
            w=s.width;h=s.height;
            android.util.Range<Double> fr=vc.getSupportedFrameRatesFor(w,h);
            int chosen=(int)Math.floor(Math.min((double)s.fps,fr.getUpper()));
            if(chosen<15) chosen=(int)Math.ceil(fr.getLower());
            if(chosen<15 || !vc.areSizeAndRateSupported(w,h,chosen)){
                int[] fs={30,24,20,15}; chosen=15;
                for(int f:fs) if(f<=s.fps && vc.areSizeAndRateSupported(w,h,f)){chosen=f;break;}
            }
            s.fps=chosen;
        }
        s.width=w&~1;s.height=h&~1;
        int minBitrate=vc.getBitrateRange().getLower(),maxBitrate=vc.getBitrateRange().getUpper();
        s.bitrate=Math.max(minBitrate,Math.min(maxBitrate,s.bitrate));
    }

    private void setupVideo() throws Exception {
        String mime = "HEVC".equalsIgnoreCase(settings.codec) ? "video/hevc" : "video/avc";
        videoEncoder = MediaCodec.createEncoderByType(mime);
        MediaFormat format = MediaFormat.createVideoFormat(mime, settings.width, settings.height);
        format.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
        format.setInteger(MediaFormat.KEY_BIT_RATE, settings.bitrate);
        format.setInteger(MediaFormat.KEY_FRAME_RATE, settings.fps);
        format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2);
        videoEncoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
        inputSurface = videoEncoder.createInputSurface();
    }

    private void setupAudioEncoder() throws Exception {
        audioEncoder = MediaCodec.createEncoderByType("audio/mp4a-latm");
        MediaFormat format = MediaFormat.createAudioFormat("audio/mp4a-latm", SAMPLE_RATE, CHANNELS);
        format.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
        format.setInteger(MediaFormat.KEY_BIT_RATE, 192_000);
        audioEncoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
    }

    public void start() throws Exception {
        tempFile = new File(ctx.getCacheDir(), "reaction_" + System.currentTimeMillis() + ".mp4");
        muxer = new MediaMuxer(tempFile.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
        recorderError = null; failurePosted.set(false); projectionStopped = false; startCompleted = false;
        running = false; stopRequested = false; audioEosQueued = false; audioEosReached = false;
        videoPtsBaseUs = Long.MIN_VALUE; awaitResumeKeyframe = false; resumeGeneration = 0L;
        synchronized (pauseLock) { paused = false; pauseStartedNs = 0L; pausedDurationNs = 0L; pauseIntervalsNs.clear(); }
        videoEncoder.start(); audioEncoder.start();

        projectionCallback = new MediaProjection.Callback() {
            @Override public void onStop() {
                boolean wasActive = startCompleted || running;
                projectionStopped = true;
                stopRequested = true;
                running = false;
                Runnable listener = projectionStoppedListener;
                if (wasActive && listener != null) {
                    new android.os.Handler(android.os.Looper.getMainLooper()).post(listener);
                }
            }
        };
        projection.registerCallback(projectionCallback, new android.os.Handler(android.os.Looper.getMainLooper()));
        projectionCallbackRegistered = true;
        recordingStartNs = System.nanoTime();

        android.util.DisplayMetrics dm = ctx.getResources().getDisplayMetrics();
        int densityDpi = Math.max(1, dm.densityDpi);
        running = true;
        virtualDisplay = projection.createVirtualDisplay("ReactionRecorder", settings.width, settings.height, densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, inputSurface, null, null);
        if (projectionStopped) throw new IllegalStateException("Screen capture ended before recording could start");
        if (virtualDisplay == null) throw new IllegalStateException("Could not create recording display");
        stopRequested = false;
        videoThread = new Thread(this::videoDrainLoop, "reaction-video-drain");
        audioThread = new Thread(this::audioLoop, "reaction-audio-mixer");
        videoThread.start(); audioThread.start();
        startCompleted = true;
    }

    private void addVideoTrack(MediaFormat format) {
        synchronized (muxLock) {
            if (videoTrack < 0) videoTrack = muxer.addTrack(format);
            maybeStartMuxerLocked();
        }
    }

    private void addAudioTrack(MediaFormat format) {
        synchronized (muxLock) {
            if (audioTrack < 0) audioTrack = muxer.addTrack(format);
            maybeStartMuxerLocked();
        }
    }

    private void maybeStartMuxerLocked() {
        if (!muxerStarted && videoTrack >= 0 && audioTrack >= 0) {
            muxer.start();
            muxerStarted = true;
            // Ensure the first video sample accepted by the MP4 begins a decodable GOP.
            try {
                if (videoEncoder != null) {
                    Bundle params = new Bundle();
                    params.putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0);
                    videoEncoder.setParameters(params);
                }
            } catch (Throwable ignored) {}
        }
    }

    private void videoDrainLoop() {
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        boolean eos=false;
        while (!eos) {
            int out;
            try { out=videoEncoder.dequeueOutputBuffer(info, 10_000); } catch (Exception e) { recordError(e); running=false; break; }
            if (out == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) addVideoTrack(videoEncoder.getOutputFormat());
            else if (out >= 0) {
                ByteBuffer data=videoEncoder.getOutputBuffer(out);
                if (data != null && info.size>0 && (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG)==0) {
                    data.position(info.offset); data.limit(info.offset+info.size);
                    if (videoPtsBaseUs == Long.MIN_VALUE) videoPtsBaseUs = info.presentationTimeUs;
                    long originalUs = Math.max(0L, info.presentationTimeUs - videoPtsBaseUs);
                    long adjustedUs = adjustedTimestampUs(originalUs);
                    if (adjustedUs >= 0) {
                        // Frames produced while paused are intentionally omitted.
                        // Because H.264/HEVC inter-frames reference earlier frames,
                        // the first frame after a pause must be a fresh keyframe.
                        // setPaused(false) requests one and we discard output until
                        // the encoder gives us that sync frame.
                        if (awaitResumeKeyframe && (info.flags & MediaCodec.BUFFER_FLAG_KEY_FRAME) == 0) {
                            // Keep draining, but do not put a dependent frame into
                            // the MP4 before the new GOP begins.
                        } else {
                            if ((info.flags & MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0) awaitResumeKeyframe = false;
                            MediaCodec.BufferInfo adjusted = new MediaCodec.BufferInfo();
                            adjusted.set(info.offset, info.size, adjustedUs, info.flags);
                            writeSample(videoTrack,data,adjusted);
                        }
                    }
                }
                eos=(info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0;
                videoEncoder.releaseOutputBuffer(out,false);
            }
        }
    }

    private static final class TimedPcm {
        final byte[] data;
        final long startNs;
        TimedPcm(byte[] data, long startNs) { this.data = data; this.startNs = startNs; }
    }

    private void audioLoop() {
        ArrayBlockingQueue<TimedPcm> micQ=new ArrayBlockingQueue<>(32);
        ArrayBlockingQueue<TimedPcm> playQ=new ArrayBlockingQueue<>(32);
        try {
            micRecord=createMic();
            if(micRecord==null) throw new IllegalStateException("Microphone is unavailable or could not be started");
            playbackRecord=createPlayback();
            if(playbackRecord==null) throw new IllegalStateException("Source audio capture is unavailable on this device or for this source. Recording was stopped to avoid creating a video without source audio.");
            startReaderThreads(micRecord, playbackRecord, micQ, playQ);
            final long chunkNs = 20_000_000L;
            long targetNs = 0L;
            long seenResumeGeneration = resumeGeneration;
            TimedPcm mc = null, pc = null;
            while (running && !stopRequested) {
                if (paused) {
                    drainAudio(false);
                    Thread.sleep(5);
                    mc = null; pc = null;
                    continue;
                }
                if (seenResumeGeneration != resumeGeneration) {
                    // Anything captured while recording was paused belongs to the discarded interval.
                    micQ.clear();
                    playQ.clear();
                    mc = null;
                    pc = null;
                    seenResumeGeneration = resumeGeneration;
                }
                long totalPausedNs;
                synchronized (pauseLock) { totalPausedNs = pausedDurationNs; }
                // Re-anchor the compressed recording timeline to the real capture clock after pauses.
                long targetAbsNs = recordingStartNs + targetNs + totalPausedNs;
                mc = advanceChunk(mc, micQ, targetAbsNs + micLatencyMs * 1_000_000L, chunkNs);
                pc = advanceChunk(pc, playQ, targetAbsNs, chunkNs);

                byte[] m = sampleForTarget(mc, targetAbsNs + micLatencyMs * 1_000_000L, chunkNs);
                byte[] p = sampleForTarget(pc, targetAbsNs, chunkNs);
                feedAudioBlocking(mix(m, p), targetNs / 1000L);
                targetNs += chunkNs;
            }
            stopRequested=true;
            if (queueAudioEos(targetNs / 1000L)) drainAudioUntilEos(5000);
        } catch (Throwable e) {
            if (!stopRequested) recordError(e);
            try { if (queueAudioEos(0)) drainAudioUntilEos(3000); } catch (Exception ignored) {}
        } finally {
            stopRecord(micRecord);
            stopRecord(playbackRecord);
            micRecord=null; playbackRecord=null;
        }
    }

    private TimedPcm advanceChunk(TimedPcm current, ArrayBlockingQueue<TimedPcm> q, long targetNs, long chunkNs) throws InterruptedException {
        TimedPcm c=current;
        while (c != null && c.startNs + chunkNs <= targetNs) c=q.poll();
        if (c == null) c=q.poll(100, TimeUnit.MILLISECONDS);
        // Drop chunks that are already too old. This is the key long-recording
        // drift protection: the timeline follows AudioRecord's monotonic clock
        // instead of blindly pairing the Nth mic chunk with the Nth playback chunk.
        while (c != null && c.startNs + chunkNs <= targetNs) c=q.poll();
        return c;
    }

    private byte[] sampleForTarget(TimedPcm c, long targetNs, long chunkNs) {
        if (c == null) return new byte[CHUNK_BYTES];
        long delta=c.startNs-targetNs;
        if (delta > chunkNs || c.startNs + chunkNs <= targetNs) return new byte[CHUNK_BYTES];
        // Chunks are captured at exactly 20 ms. For the normal case, use the
        // complete chunk. If the device clock slips by a small amount, choose
        // the nearest chunk rather than accumulating an ever-growing offset.
        return c.data;
    }

    private AudioRecord createMic() {
        int monoBytes=CHUNK_BYTES/2;
        int min=AudioRecord.getMinBufferSize(SAMPLE_RATE,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT);
        if(min<monoBytes) min=monoBytes*4;
        try {
            AudioRecord r=new AudioRecord.Builder().setAudioSource(MediaRecorder.AudioSource.MIC)
                    .setAudioFormat(new AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(SAMPLE_RATE).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build())
                    .setBufferSizeInBytes(Math.max(min*2, monoBytes*8)).build();
            if(preferredInputDeviceId!=null && Build.VERSION.SDK_INT>=23) {
                AudioManager am=(AudioManager)ctx.getSystemService(Context.AUDIO_SERVICE);
                for(AudioDeviceInfo d:am.getDevices(AudioManager.GET_DEVICES_INPUTS)) if(d.getId()==preferredInputDeviceId) { r.setPreferredDevice(d); break; }
            }
            r.startRecording();
            if(r.getRecordingState()!=AudioRecord.RECORDSTATE_RECORDING) { r.release(); return null; }
            return r;
        } catch(Throwable e) { return null; }
    }

    private AudioRecord createPlayback() {
        try {
            AudioPlaybackCaptureConfiguration cfg=new AudioPlaybackCaptureConfiguration.Builder(projection)
                    .addMatchingUid(android.os.Process.myUid())
                    .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                    .build();
            int min=AudioRecord.getMinBufferSize(SAMPLE_RATE,AudioFormat.CHANNEL_IN_STEREO,AudioFormat.ENCODING_PCM_16BIT);
            if(min<CHUNK_BYTES) min=CHUNK_BYTES*4;
            AudioRecord r=new AudioRecord.Builder().setAudioFormat(new AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(SAMPLE_RATE).setChannelMask(AudioFormat.CHANNEL_IN_STEREO).build())
                    .setBufferSizeInBytes(Math.max(min*2,CHUNK_BYTES*8)).setAudioPlaybackCaptureConfig(cfg).build();
            r.startRecording(); if(r.getRecordingState()!=AudioRecord.RECORDSTATE_RECORDING){r.release();return null;} return r;
        } catch(Throwable e) { return null; }
    }

    private void startReaderThreads(AudioRecord mic, AudioRecord playback, ArrayBlockingQueue<TimedPcm> mq, ArrayBlockingQueue<TimedPcm> pq) {
        micThread=new Thread(()->readTimedLoop(mic,mq,true),"reaction-mic-reader");
        playbackThread=new Thread(()->readTimedLoop(playback,pq,false),"reaction-playback-reader");
        micThread.start(); playbackThread.start();
    }

    private void readTimedLoop(AudioRecord r, ArrayBlockingQueue<TimedPcm> q, boolean mono) {
        final long chunkNs=20_000_000L;
        final int readBytes=mono?CHUNK_BYTES/2:CHUNK_BYTES;
        while(running && !stopRequested) {
            byte[] raw=new byte[readBytes];
            int n=0;
            long readEnd=System.nanoTime();
            if(r!=null) {
                try {
                    n=r.read(raw,0,raw.length,AudioRecord.READ_BLOCKING);
                    readEnd=System.nanoTime();
                    if(n<0){ recordError(new IllegalStateException((r==micRecord?"Microphone":"Source audio")+" capture stopped")); break; }
                } catch(Throwable e) { recordError(e); break; }
            }
            if(n<readBytes) java.util.Arrays.fill(raw,Math.max(0,n),readBytes,(byte)0);
            byte[] b = mono ? monoToStereo(raw) : raw;
            long start=readEnd-chunkNs;
            if(r!=null && Build.VERSION.SDK_INT>=24){
                try {
                    AudioTimestamp ts=new AudioTimestamp();
                    if(r.getTimestamp(ts,AudioTimestamp.TIMEBASE_MONOTONIC)==AudioRecord.SUCCESS && ts.nanoTime>0) start=ts.nanoTime-chunkNs;
                } catch(Throwable ignored) {}
            }
            TimedPcm chunk=new TimedPcm(b,start);
            if(!q.offer(chunk)) { q.poll(); q.offer(chunk); }
        }
    }

    private byte[] monoToStereo(byte[] mono) {
        byte[] stereo=new byte[CHUNK_BYTES];
        int frames=Math.min(mono.length/2, CHUNK_BYTES/4);
        for(int i=0;i<frames;i++){ int si=i*4, mi=i*2; stereo[si]=mono[mi]; stereo[si+1]=mono[mi+1]; stereo[si+2]=mono[mi]; stereo[si+3]=mono[mi+1]; }
        return stereo;
    }

    private byte[] mix(byte[] m, byte[] p) {
        byte[] out=new byte[CHUNK_BYTES];
        for(int i=0;i<CHUNK_BYTES;i+=2) {
            int m0=m[i] & 0xff, m1=m[i+1] & 0xff;
            int p0=p[i] & 0xff, p1=p[i+1] & 0xff;
            short ms=(short)(m0 | (m1 << 8));
            short ps=(short)(p0 | (p1 << 8));
            int v=Math.round(ms*0.85f + ps*0.75f);
            if(v>32767)v=32767; if(v<-32768)v=-32768;
            out[i]=(byte)v; out[i+1]=(byte)(v>>8);
        }
        return out;
    }

    private long adjustedTimestampUs(long originalUs) {
        synchronized (pauseLock) {
            long removed = 0L;
            for (long[] interval : pauseIntervalsNs) {
                long startUs = Math.max(0L, (interval[0] - recordingStartNs) / 1000L);
                long endUs = Math.max(startUs, (interval[1] - recordingStartNs) / 1000L);
                if (originalUs >= endUs) removed += endUs - startUs;
                else if (originalUs >= startUs) return -1L;
            }
            if (paused && pauseStartedNs > 0 && System.nanoTime() >= pauseStartedNs) {
                long startUs = Math.max(0L, (pauseStartedNs - recordingStartNs) / 1000L);
                if (originalUs >= startUs) return -1L;
            }
            return Math.max(0L, originalUs - removed);
        }
    }

    public boolean setPaused(boolean value) {
        synchronized (pauseLock) {
            if (value == paused || stopRequested) return false;
            if (value) {
                paused = true;
                pauseStartedNs = System.nanoTime();
            } else {
                long now = System.nanoTime();
                if (pauseStartedNs > 0) {
                    long elapsed = Math.max(0L, now - pauseStartedNs);
                    pausedDurationNs += elapsed;
                    pauseIntervalsNs.add(new long[]{pauseStartedNs, now});
                }
                pauseStartedNs = 0L;
                paused = false;
                resumeGeneration++;
                awaitResumeKeyframe = true;
                try {
                    Bundle params = new Bundle();
                    params.putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0);
                    if (videoEncoder != null) videoEncoder.setParameters(params);
                } catch (Throwable ignored) {
                    // Some encoders do not expose runtime sync-frame requests.
                    // The normal encoder cadence will still eventually produce a keyframe.
                }
            }
            return true;
        }
    }

    private long getPausedDurationUs() {
        synchronized (pauseLock) {
            long total = pausedDurationNs;
            if (paused && pauseStartedNs > 0) total += Math.max(0L, System.nanoTime() - pauseStartedNs);
            return total / 1000L;
        }
    }

    private void feedAudioBlocking(byte[] bytes,long ptsUs) throws Exception {
        while(running && !stopRequested) {
            int in=audioEncoder.dequeueInputBuffer(10_000);
            drainAudio(false);
            if(in>=0) {
                ByteBuffer b=audioEncoder.getInputBuffer(in); if(b==null) continue;
                b.clear(); b.put(bytes); audioEncoder.queueInputBuffer(in,0,bytes.length,ptsUs,0); break;
            }
        }
        while(drainAudio(false)) {}
    }

    private boolean queueAudioEos(long ptsUs) throws Exception {
        if(audioEosQueued) return !audioEosReached;
        long deadline=System.nanoTime()+2_000_000_000L;
        int in;
        do {
            in=audioEncoder.dequeueInputBuffer(10_000);
            drainAudio(false);
            if(in<0 && System.nanoTime()>=deadline) throw new IllegalStateException("Audio encoder did not accept end-of-stream");
        } while(in<0);
        audioEncoder.queueInputBuffer(in,0,0,ptsUs,MediaCodec.BUFFER_FLAG_END_OF_STREAM);
        audioEosQueued=true;
        return true;
    }

    private void drainAudioUntilEos(long timeoutMs) throws Exception {
        long deadline=System.nanoTime()+timeoutMs*1_000_000L;
        while(!audioEosReached && System.nanoTime()<deadline) drainAudio(true);
    }

    private boolean drainAudio(boolean wait) throws Exception {
        MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();
        int out=audioEncoder.dequeueOutputBuffer(info,wait?10_000:0);
        if(out==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) { addAudioTrack(audioEncoder.getOutputFormat()); return false; }
        if(out>=0) {
            ByteBuffer data=audioEncoder.getOutputBuffer(out);
            if(data!=null && info.size>0 && (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG)==0) { data.position(info.offset); data.limit(info.offset+info.size); writeSample(audioTrack,data,info); }
            boolean eos=(info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0; if(eos) audioEosReached=true; audioEncoder.releaseOutputBuffer(out,false); return eos;
        }
        return false;
    }

    private void writeSample(int track,ByteBuffer data,MediaCodec.BufferInfo info) {
        synchronized(muxLock) {
            if(!muxerStarted||track<0)return;
            try{muxer.writeSampleData(track,data,info);}catch(Exception e){recordError(e);}
        }
    }

    private void recordError(Throwable t) {
        if (t == null || recorderError != null) return;
        recorderError = t; running = false; stopRequested = true;
        Runnable listener = failureListener;
        if (startCompleted && listener != null && failurePosted.compareAndSet(false,true)) {
            new android.os.Handler(android.os.Looper.getMainLooper()).post(listener);
        }
    }

    public File stopAndGetTempFile() {
        synchronized (pauseLock) {
            if (paused && pauseStartedNs > 0) {
                long now = System.nanoTime();
                pausedDurationNs += Math.max(0L, now - pauseStartedNs);
                pauseIntervalsNs.add(new long[]{pauseStartedNs, now});
                pauseStartedNs = 0L;
                paused = false;
            }
        }
        stopRequested=true; running=false;
        stopRecord(micRecord);
        stopRecord(playbackRecord);
        try{if(audioThread!=null)audioThread.interrupt();}catch(Exception ignored){}
        try{if(micThread!=null)micThread.interrupt();}catch(Exception ignored){}
        try{if(playbackThread!=null)playbackThread.interrupt();}catch(Exception ignored){}
        try{if(virtualDisplay!=null)virtualDisplay.release();}catch(Exception ignored){}
        try{if(videoEncoder!=null)videoEncoder.signalEndOfInputStream();}catch(Exception ignored){}
        join(audioThread,5000); join(videoThread,5000); join(micThread,1500); join(playbackThread,1500);
        boolean validMuxer;
        synchronized(muxLock){ validMuxer = muxerStarted && videoTrack >= 0 && audioTrack >= 0; }
        try{videoEncoder.stop();}catch(Exception ignored){} try{audioEncoder.stop();}catch(Exception ignored){}
        try{videoEncoder.release();}catch(Exception ignored){} try{audioEncoder.release();}catch(Exception ignored){}
        try{if(inputSurface!=null)inputSurface.release();}catch(Exception ignored){}
        if(projectionCallbackRegistered && projectionCallback!=null){
            try{projection.unregisterCallback(projectionCallback);}catch(Exception ignored){}
            projectionCallbackRegistered=false;
            projectionCallback=null;
        }
        try{projection.stop();}catch(Exception ignored){}
        synchronized(muxLock){try{if(muxerStarted)muxer.stop();}catch(Exception ignored){} try{if(muxer!=null)muxer.release();}catch(Exception ignored){} muxer=null;}
        startCompleted=false;
        if(!validMuxer){
            if(tempFile!=null)try{tempFile.delete();}catch(Exception ignored){}
            throw new IllegalStateException("Recording did not produce both video and audio tracks");
        }
        if (recorderError != null) {
            if(tempFile!=null) try{tempFile.delete();}catch(Exception ignored){}
            String msg=recorderError.getMessage();
            throw new IllegalStateException(msg==null||msg.isEmpty()?"The recorder stopped unexpectedly":msg,recorderError);
        }
        return tempFile;
    }

    private static void join(Thread t,long ms){if(t!=null)try{t.join(ms);}catch(InterruptedException ignored){Thread.currentThread().interrupt();}}
    private static void stopRecord(AudioRecord r){if(r!=null)try{r.stop();}catch(Exception ignored){} if(r!=null)try{r.release();}catch(Exception ignored){}}

    public static android.net.Uri publishToGallery(Context context,File temp)throws Exception{
        return publishToStorage(context,temp,null);
    }

    public static android.net.Uri publishToStorage(Context context,File temp,android.net.Uri treeUri)throws Exception{
        if(temp==null || !temp.exists() || temp.length()==0) throw new IllegalArgumentException("Temporary recording is missing");
        String name="Reaction_"+new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss_SSS",Locale.US).format(new Date())+".mp4";
        if(treeUri!=null){
            return copyIntoTree(context,temp,treeUri,name);
        }
        ContentResolver resolver=context.getContentResolver(); ContentValues v=new ContentValues();
        v.put(MediaStore.Video.Media.DISPLAY_NAME,name);
        v.put(MediaStore.Video.Media.MIME_TYPE,"video/mp4");
        if(Build.VERSION.SDK_INT>=29){v.put(MediaStore.Video.Media.RELATIVE_PATH,Environment.DIRECTORY_MOVIES+"/Reaction Recorder");v.put(MediaStore.Video.Media.IS_PENDING,1);}
        android.net.Uri uri=resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,v);
        if(uri==null)throw new IllegalStateException("Could not create gallery item");
        boolean success=false;
        try{
            OutputStream out=resolver.openOutputStream(uri);
            if(out==null) throw new IllegalStateException("Could not open gallery output");
            try(FileInputStream in=new FileInputStream(temp)){
                byte[] b=new byte[64*1024]; int n;
                while((n=in.read(b))!=-1) out.write(b,0,n);
                out.flush();
            } finally { try{out.close();}catch(Exception ignored){} }
            if(Build.VERSION.SDK_INT>=29){ContentValues done=new ContentValues();done.put(MediaStore.Video.Media.IS_PENDING,0);if(resolver.update(uri,done,null,null)<=0)throw new IllegalStateException("Could not finalize gallery item");}
            success=true; temp.delete(); return uri;
        } finally { if(!success){try{resolver.delete(uri,null,null);}catch(Exception ignored){}} }
    }

    private static android.net.Uri copyIntoTree(Context context,File temp,android.net.Uri treeUri,String name)throws Exception{
        ContentResolver resolver=context.getContentResolver();
        try{ android.provider.DocumentsContract.getTreeDocumentId(treeUri); }catch(Exception e){ throw new IllegalArgumentException("The selected save folder is invalid or no longer accessible",e); }
        android.net.Uri uri=android.provider.DocumentsContract.createDocument(resolver,treeUri,"video/mp4",name);
        if(uri==null) throw new IllegalStateException("Could not create the recording in the selected folder");
        boolean success=false;
        try(OutputStream out=resolver.openOutputStream(uri);FileInputStream in=new FileInputStream(temp)){
            if(out==null) throw new IllegalStateException("Could not open the selected folder for writing");
            byte[] b=new byte[64*1024];int n;while((n=in.read(b))!=-1)out.write(b,0,n);out.flush();success=true;temp.delete();return uri;
        } finally { if(!success){try{resolver.delete(uri,null,null);}catch(Exception ignored){}} }
    }

    public static final class RecordingSettings{
        public int width=1080,height=1920,fps=30,bitrate=5_000_000; public String codec="HEVC";
        public RecordingSettings copy(){RecordingSettings r=new RecordingSettings();r.width=width;r.height=height;r.fps=fps;r.bitrate=bitrate;r.codec=codec;return r;}
        public String summary(){return width+"×"+height+" • "+fps+" FPS • "+codec+" • "+String.format(Locale.US,"%.1f Mbps",bitrate/1_000_000f);}
    }
}
